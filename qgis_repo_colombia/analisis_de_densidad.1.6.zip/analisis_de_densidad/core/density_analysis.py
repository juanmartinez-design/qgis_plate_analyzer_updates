﻿"""
density_analysis.py
===================

Modulo de analisis geoespacial adaptado al complemento Analisis de densidad.

Flujo principal de Alternativa2
-------------------------------
1. Las placas se toman desde la capa vectorial de puntos confirmada en QGIS.
2. La mascara de estudio se obtiene desde PostGIS con los niveles
   administrativos seleccionados.
3. Dentro de la mascara se construye una superficie hexagonal de evaluacion KDE.
4. En cada celda de superficie se calcula:
   - KDE de placas;
   - KDE de construcciones, ponderado por area construida;
   - ratio KDE_placas / KDE_construcciones_ponderado_area;
   - normalizacion Min-Max del ratio;
   - score inverso para ausencia relativa de placas.
5. La superficie se clasifica en cobertura No cubierto/Cubierto con umbral direccional:
   mediana(ratio) - desviacion_estandar(ratio).
6. Las celdas se vectorizan y se disuelven por prioridad dentro de la mascara.

La evaluacion KDE de los hexagonos se procesa por parches en hilos para reducir
el tiempo de corrida sin cambiar la metodologia estadistica.

La funcion principal de este flujo es:

    run_point_voronoi_kde_analysis(...)

TambiÃ©n se incluye la clase `DensityAnalysis`, compatible con el patrÃ³n del
plugin QGIS, para que la interfaz pueda ejecutar el flujo desde una capa activa.

MetodologÃ­a KDE
---------------
Se conserva el Kernel Epanechnikov:

    u = distancia / bandwidth_m
    peso = 1 - uÂ², si u <= 1
    peso = 0,      si u > 1

Para construcciones:

    KDE_construcciones = SUM(area_m2 * peso)

Para planchas:

    KDE_planchas = SUM(peso)

La idoneidad es inversa al ratio:

    ratio = KDE_planchas_norm / KDE_construcciones_norm

Por tanto, una relaciÃ³n baja representa una menor presencia relativa de
planchas frente a la intensidad construida y, bajo este enfoque, una mayor
idoneidad prospectiva.
"""

from __future__ import annotations

import json
import hashlib
import math
import os
import re
import tempfile
import time
import uuid
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple, Union

# Dependencias cientÃ­ficas. Se importan de forma segura para evitar que el
# complemento QGIS falle al cargarse antes de que el usuario ejecute el anÃ¡lisis.
_GEOPANDAS_IMPORT_ERROR = None
_NUMPY_IMPORT_ERROR = None
_PANDAS_IMPORT_ERROR = None
_PSYCOPG2_IMPORT_ERROR = None

try:
    import geopandas as gpd
except Exception as exc:  # pragma: no cover - depende del Python de QGIS
    gpd = None
    _GEOPANDAS_IMPORT_ERROR = exc

try:
    import numpy as np
except Exception as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc

try:
    import pandas as pd
except Exception as exc:  # pragma: no cover
    pd = None
    _PANDAS_IMPORT_ERROR = exc

try:
    from psycopg2 import Binary, sql
    from psycopg2.extras import execute_values
except Exception as exc:  # pragma: no cover
    Binary = None
    sql = None
    execute_values = None
    _PSYCOPG2_IMPORT_ERROR = exc

# QGIS es opcional a nivel de importaciÃ³n. Las funciones que reciben capas
# activas validan su disponibilidad en tiempo de ejecuciÃ³n.
_QGIS_IMPORT_ERROR = None
try:
    from qgis.core import (
        QgsCoordinateReferenceSystem,
        QgsCoordinateTransform,
        QgsFeature,
        QgsFeatureRequest,
        QgsField,
        QgsFields,
        QgsGeometry,
        QgsProject,
        QgsRectangle,
        QgsVectorLayer,
        QgsWkbTypes,
    )
    from qgis.PyQt.QtCore import QVariant
except Exception as exc:  # pragma: no cover - fuera de QGIS
    QgsCoordinateReferenceSystem = QgsCoordinateTransform = None
    QgsFeature = QgsFeatureRequest = QgsField = QgsFields = QgsGeometry = None
    QgsProject = QgsRectangle = QgsVectorLayer = QgsWkbTypes = None
    QVariant = None
    _QGIS_IMPORT_ERROR = exc


# ============================================================
# RUTAS BASE
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parents[1]

DEFAULT_MAPPING_PATH = BASE_DIR / "json" / "column_mapping - DEF.json"
_CONSTRUCTION_POINTS_CACHE: "OrderedDict[Tuple[object, ...], object]" = OrderedDict()
_CONSTRUCTION_POINTS_CACHE_MAX_ITEMS = 6


def _require_runtime_dependencies(require_qgis=False, require_db=False):
    """Valida las dependencias necesarias justo antes de ejecutar el anÃ¡lisis."""
    missing = []

    if gpd is None:
        missing.append(f"geopandas ({_GEOPANDAS_IMPORT_ERROR})")
    if np is None:
        missing.append(f"numpy ({_NUMPY_IMPORT_ERROR})")
    if pd is None:
        missing.append(f"pandas ({_PANDAS_IMPORT_ERROR})")
    if require_db and (sql is None or Binary is None or execute_values is None):
        missing.append(f"psycopg2 ({_PSYCOPG2_IMPORT_ERROR})")
    if require_qgis and QgsVectorLayer is None:
        missing.append(f"QGIS Python API ({_QGIS_IMPORT_ERROR})")

    if missing:
        raise RuntimeError(
            "Faltan dependencias para ejecutar el anÃ¡lisis:\n- "
            + "\n- ".join(missing)
        )


# ============================================================
# UTILIDADES GENERALES
# ============================================================

def resolve_path(path):
    """
    Resuelve una ruta relativa o absoluta.

    Si la ruta es absoluta, se retorna directamente. Si es relativa,
    se busca en ubicaciones comunes del proyecto:

    1. Directorio actual de ejecuciÃ³n.
    2. Carpeta del mÃ³dulo actual.
    3. Carpeta json dentro del mÃ³dulo actual.
    4. RaÃ­z del proyecto.
    5. Carpeta json en la raÃ­z del proyecto.

    ParÃ¡metros
    ----------
    path : str | Path
        Ruta del archivo que se quiere localizar.

    Retorna
    -------
    Path
        Ruta existente localizada.
    """

    path = Path(path)

    if path.is_absolute():
        return path

    candidate_paths = [
        Path.cwd() / path,
        BASE_DIR / path,
        BASE_DIR / "json" / path.name,
        PROJECT_ROOT / path,
        PROJECT_ROOT / "json" / path.name,
    ]

    for candidate in candidate_paths:
        if candidate.exists():
            return candidate

    checked = "\n".join(str(p) for p in candidate_paths)

    raise FileNotFoundError(
        f"No se encontrÃ³ el archivo: {path}\n\n"
        f"Rutas revisadas:\n{checked}"
    )


def _cache_enabled(env_name="QGIS_PLATE_ANALYZER_ENABLE_CACHE"):
    return os.environ.get(env_name, "1").strip().lower() not in {"0", "false", "no", "off"}


def _file_signature(path):
    try:
        resolved = resolve_path(path)
        stat = resolved.stat()
        return (str(resolved), int(stat.st_mtime), int(stat.st_size))
    except Exception:
        return (str(path), 0, 0)


def _geometry_cache_digest(geometry):
    try:
        return hashlib.sha1(bytes(geometry.wkb)).hexdigest()
    except Exception:
        try:
            return hashlib.sha1(str(geometry.bounds).encode("utf-8")).hexdigest()
        except Exception:
            return "sin_geometria"


def _get_construction_cache(key):
    if not _cache_enabled():
        return None
    cached = _CONSTRUCTION_POINTS_CACHE.get(key)
    if cached is None:
        return None
    _CONSTRUCTION_POINTS_CACHE.move_to_end(key)
    try:
        return cached.copy(deep=True)
    except Exception:
        return cached.copy()


def _set_construction_cache(key, value):
    if not _cache_enabled() or value is None:
        return
    try:
        cached = value.copy(deep=True)
    except Exception:
        cached = value.copy()
    _CONSTRUCTION_POINTS_CACHE[key] = cached
    _CONSTRUCTION_POINTS_CACHE.move_to_end(key)
    while len(_CONSTRUCTION_POINTS_CACHE) > _CONSTRUCTION_POINTS_CACHE_MAX_ITEMS:
        _CONSTRUCTION_POINTS_CACHE.popitem(last=False)


def load_column_mapping(mapping_path=DEFAULT_MAPPING_PATH):
    """
    Carga el archivo JSON de mapeo de columnas y tablas.

    El archivo debe contener, por cada base de datos, los bloques:

    - administrativo
    - capas_puntos (opcional, solo para flujos con tablas PostGIS de puntos)

    Retorna
    -------
    dict
        ConfiguraciÃ³n completa leÃ­da desde el JSON.
    """

    mapping_path = resolve_path(mapping_path)

    with open(mapping_path, "r", encoding="utf-8") as f:
        return json.load(f)


def normalize_key(value):
    """
    Normaliza una cadena para usarla como clave interna.

    Aplica:
    - strip
    - lower
    - reemplazo de tildes
    - reemplazo de Ã± por n
    """

    if value is None:
        return ""

    value = str(value).strip().lower()

    replacements = {
        "Ã¡": "a",
        "Ã©": "e",
        "Ã­": "i",
        "Ã³": "o",
        "Ãº": "u",
        "Ã±": "n",
    }

    for old, new in replacements.items():
        value = value.replace(old, new)

    return value


def safe_column_name(value):
    """
    Convierte un nombre de capa en un nombre seguro de columna.

    Ejemplo:
        "Comercial" -> "comercial"
        "Banca PÃºblica" -> "banca_publica"
    """

    value = normalize_key(value)
    value = re.sub(r"[^a-z0-9_]+", "_", value)
    value = value.strip("_")

    if not value:
        raise ValueError("Nombre de columna invÃ¡lido.")

    return value


def _geometry_union(geometry_series):
    """
    Une una serie GeoPandas de geometrÃ­as con compatibilidad Shapely 1.x/2.x.
    """

    def _make_valid(geom):
        if geom is None or geom.is_empty:
            return geom
        try:
            if geom.is_valid:
                return geom
        except Exception:
            return geom
        try:
            from shapely.validation import make_valid
            fixed = make_valid(geom)
        except Exception:
            try:
                fixed = geom.buffer(0)
            except Exception:
                fixed = geom
        return fixed if fixed is not None and not fixed.is_empty else geom

    if hasattr(geometry_series, "apply"):
        try:
            geometry_series = geometry_series.apply(_make_valid)
        except Exception:
            pass

    if hasattr(geometry_series, "union_all"):
        try:
            return geometry_series.union_all()
        except TypeError:
            pass

    geometries = [
        _make_valid(geom) for geom in geometry_series
        if geom is not None and not geom.is_empty
    ]

    if not geometries:
        return None

    union_geom = geometries[0]
    for geom in geometries[1:]:
        union_geom = union_geom.union(geom)

    return union_geom


def _spatial_prefilter_by_geometry(gdf, geometry):
    """Reduce un GeoDataFrame a geometrias que intersectan el bbox/geometria objetivo."""
    if gdf is None or getattr(gdf, "empty", True):
        return gdf
    if geometry is None or getattr(geometry, "is_empty", True):
        return gdf.iloc[0:0].copy()

    try:
        candidate_idx = list(gdf.sindex.intersection(geometry.bounds))
        if candidate_idx:
            subset = gdf.iloc[candidate_idx].copy()
        else:
            return gdf.iloc[0:0].copy()
    except Exception:
        subset = gdf

    try:
        mask = subset.geometry.intersects(geometry)
        return subset.loc[mask].copy()
    except Exception:
        return subset.copy()


def _quote_debug_identifier(value):
    """Cita identificadores para renderizar SQL en pruebas sin conexiÃ³n real."""

    return '"' + str(value).replace('"', '""') + '"'


def _quote_debug_literal(value):
    """Cita literales bÃ¡sicos para renderizar SQL en pruebas sin conexiÃ³n real."""

    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    return "'" + str(value).replace("'", "''") + "'"


def composable_sql_to_debug_string(query):
    """
    Renderiza un objeto psycopg2.sql.Composable para pruebas/diagnÃ³stico.

    No reemplaza `query.as_string(conn)` en ejecuciÃ³n real. Su objetivo es
    inspeccionar consultas compuestas cuando no hay una conexiÃ³n PostgreSQL.
    """

    if sql is None:
        return str(query)

    if isinstance(query, sql.Composed):
        return "".join(composable_sql_to_debug_string(part) for part in query._wrapped)

    if isinstance(query, sql.SQL):
        return query._wrapped

    if isinstance(query, sql.Identifier):
        return ".".join(_quote_debug_identifier(part) for part in query._wrapped)

    if isinstance(query, sql.Literal):
        return _quote_debug_literal(query._wrapped)

    if isinstance(query, sql.Placeholder):
        if query._wrapped:
            return f"%({query._wrapped})s"
        return "%s"

    return str(query)


def normalize_wkb(value):
    """
    Normaliza geometrÃ­as WKB recibidas desde PostgreSQL.

    psycopg2 puede devolver bytea como:
    - memoryview
    - bytes
    - bytearray
    - str hexadecimal con prefijo \\x
    """

    if value is None:
        return None

    if isinstance(value, memoryview):
        return value.tobytes()

    if isinstance(value, bytearray):
        return bytes(value)

    if isinstance(value, bytes):
        return value

    if isinstance(value, str):
        text = value.strip()

        if text.startswith("\\x"):
            text = text[2:]

        if text.startswith("0x"):
            text = text[2:]

        return bytes.fromhex(text)

    try:
        return bytes(value)
    except Exception as exc:
        raise TypeError(
            f"No se pudo convertir WKB. Tipo recibido: {type(value)}"
        ) from exc


def get_db_mapping(dbname, mapping_path=DEFAULT_MAPPING_PATH):
    """
    Obtiene la configuraciÃ³n de una base de datos dentro del mapping.
    """

    mapping = load_column_mapping(mapping_path)

    if dbname not in mapping:
        raise KeyError(
            f"No existe configuraciÃ³n para la base '{dbname}' "
            f"en column_mapping."
        )

    return mapping[dbname]


# ============================================================================================================================================
# CONFIGURACIÃ“N DE TABLAS
# ========================================================================================================================

def resolve_administrativo_config(db_cfg):
    """
    Resuelve la configuraciÃ³n del bloque administrativo.

    Estructura esperada:

        "administrativo": {
            "schema": "administrativo",
            "construcciones": {
                "table": "construcciones",
                "geom_column": "geom"
            }
        }

    Retorna
    -------
    dict
        Diccionario con:
        - schema
        - construcciones_table
        - construcciones_geom
    """

    if "administrativo" not in db_cfg:
        raise KeyError("Falta el bloque 'administrativo' en column_mapping.")

    admin = db_cfg["administrativo"]

    admin_schema = admin.get("schema", "administrativo")
    construcciones_cfg = admin.get("construcciones", {})

    construcciones_schema = construcciones_cfg.get("schema", "produccion")
    construcciones_table = construcciones_cfg.get("table", "construcciones")
    construcciones_geom = construcciones_cfg.get("geom_column", "geom")

    return {
        "schema": admin_schema,
        "construcciones_schema": construcciones_schema,
        "construcciones_table": construcciones_table,
        "construcciones_geom": construcciones_geom,
    }


def resolve_point_layer_config(db_cfg, selected_layers):
    """
    Resuelve capas de puntos configuradas en column_mapping.

    Ejemplo de entrada:
        selected_layers = ["sitios", "bancario", "empresarial", "comercial"]

    Regla especial:
        Si llega "comercial", se busca "comercial" y luego "comercio".
    """

    point_cfg = (
        db_cfg.get("capas_puntos")
        or db_cfg.get("point_layers")
    )

    if not point_cfg:
        raise KeyError("Falta el bloque 'capas_puntos' en column_mapping.")

    schema = point_cfg.get("schema", "public")
    default_geom_column = point_cfg.get("default_geom_column", "geom")
    tables = point_cfg.get("tables", {})

    if not selected_layers:
        raise ValueError("Debe seleccionarse al menos una capa de puntos.")

    resolved_layers = []
    used_aliases = set()

    for raw_layer in selected_layers:
        layer_key = normalize_key(raw_layer)

        if layer_key == "comercial":
            possible_keys = ["comercial", "comercio"]
        else:
            possible_keys = [layer_key]

        table_cfg = None
        final_key = None

        for key in possible_keys:
            if key in tables:
                table_cfg = tables[key]
                final_key = key
                break

        if table_cfg is None:
            raise KeyError(
                f"La capa '{raw_layer}' no existe en capas_puntos.tables. "
                f"Capas disponibles: {list(tables.keys())}"
            )

        table_name = table_cfg.get("table")
        geom_column = table_cfg.get("geom_column", default_geom_column)

        if not table_name:
            raise KeyError(
                f"La capa '{final_key}' no tiene campo 'table' configurado."
            )

        alias = safe_column_name(layer_key)

        if alias in used_aliases:
            continue

        used_aliases.add(alias)

        resolved_layers.append({
            "frontend_key": raw_layer,
            "key": final_key,
            "alias": alias,
            "schema": schema,
            "table": table_name,
            "geom_column": geom_column,
        })

    return resolved_layers


# ============================================================================================================================================
# VALIDACIONES POSTGIS
# ============================================================================================================================================

def table_exists(conn, schema_name, table_name):
    """
    Verifica si una tabla existe.
    """

    query = """
        SELECT EXISTS (
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = %s
              AND table_name = %s
        );
    """

    with conn.cursor() as cur:
        cur.execute(query, (schema_name, table_name))
        return bool(cur.fetchone()[0])


def column_exists(conn, schema_name, table_name, column_name):
    """
    Verifica si una columna existe en una tabla.
    """

    query = """
        SELECT EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = %s
              AND table_name = %s
              AND column_name = %s
        );
    """

    with conn.cursor() as cur:
        cur.execute(query, (schema_name, table_name, column_name))
        return bool(cur.fetchone()[0])


def column_has_non_null(conn, schema_name, table_name, column_name):
    """
    Verifica si una columna tiene al menos un registro no nulo.
    """

    query = sql.SQL("""
        SELECT EXISTS (
            SELECT 1
            FROM {schema_name}.{table_name}
            WHERE {column_name} IS NOT NULL
            LIMIT 1
        );
    """).format(
        schema_name=sql.Identifier(schema_name),
        table_name=sql.Identifier(table_name),
        column_name=sql.Identifier(column_name),
    )

    with conn.cursor() as cur:
        cur.execute(query)
        return bool(cur.fetchone()[0])


def get_geometry_srid(conn, schema_name, table_name, geom_column):
    """
    Obtiene el SRID real de una columna geomÃ©trica.

    Si la tabla no tiene geometrÃ­as no nulas, retorna None.
    """

    query = sql.SQL("""
        SELECT ST_SRID({geom_column})
        FROM {schema_name}.{table_name}
        WHERE {geom_column} IS NOT NULL
        LIMIT 1;
    """).format(
        schema_name=sql.Identifier(schema_name),
        table_name=sql.Identifier(table_name),
        geom_column=sql.Identifier(geom_column),
    )

    with conn.cursor() as cur:
        cur.execute(query)
        row = cur.fetchone()

    if row is None:
        return None

    return row[0]


def sanitize_index_name(*parts):
    """
    Construye un nombre de Ã­ndice seguro y corto para PostgreSQL.
    """

    raw = "_".join(str(p) for p in parts)
    raw = re.sub(r"[^a-zA-Z0-9_]+", "_", raw)
    raw = raw.lower()

    if len(raw) > 55:
        raw = raw[:55]

    return raw


def ensure_spatial_index(conn, schema_name, table_name, geom_column):
    """
    Crea un Ã­ndice GIST si no existe y ejecuta ANALYZE.

    Requiere permisos de escritura sobre la base.
    """

    index_name = sanitize_index_name(
        "idx",
        schema_name,
        table_name,
        geom_column,
        "gist"
    )

    query = sql.SQL("""
        CREATE INDEX IF NOT EXISTS {index_name}
        ON {schema_name}.{table_name}
        USING GIST ({geom_column});
    """).format(
        index_name=sql.Identifier(index_name),
        schema_name=sql.Identifier(schema_name),
        table_name=sql.Identifier(table_name),
        geom_column=sql.Identifier(geom_column),
    )

    analyze_query = sql.SQL("""
        ANALYZE {schema_name}.{table_name};
    """).format(
        schema_name=sql.Identifier(schema_name),
        table_name=sql.Identifier(table_name),
    )

    with conn.cursor() as cur:
        cur.execute(query)
        cur.execute(analyze_query)


def ensure_needed_indexes(
    conn,
    admin_cfg,
    point_layers,
    construction_point_column="geom_punto"
):
    """
    Crea Ã­ndices espaciales bÃ¡sicos sobre las tablas utilizadas.

    Ãšsalo con create_indexes=True solo cuando tengas permisos y, en lo
    posible, solo una vez por base de datos.
    """

    construcciones_schema = admin_cfg.get("construcciones_schema", admin_cfg["schema"])
    construcciones_table = admin_cfg["construcciones_table"]
    construcciones_geom = admin_cfg["construcciones_geom"]

    if table_exists(conn, construcciones_schema, construcciones_table):
        ensure_spatial_index(
            conn,
            construcciones_schema,
            construcciones_table,
            construcciones_geom
        )

        if column_exists(
            conn,
            construcciones_schema,
            construcciones_table,
            construction_point_column
        ):
            ensure_spatial_index(
                conn,
                construcciones_schema,
                construcciones_table,
                construction_point_column
            )

    for layer in point_layers:
        if table_exists(conn, layer["schema"], layer["table"]):
            ensure_spatial_index(
                conn,
                layer["schema"],
                layer["table"],
                layer["geom_column"]
            )


# ============================================================
# CRS DE ANÃLISIS
# ============================================================

def estimate_metric_srid(grid_gdf):
    """
    Estima un CRS mÃ©trico para hacer distancias en metros.

    Si la grilla ya estÃ¡ proyectada, usa su EPSG. Si estÃ¡ en EPSG:4326
    u otro CRS geogrÃ¡fico, estima UTM con GeoPandas.
    """

    if grid_gdf.crs is None:
        raise ValueError("grid_gdf no tiene CRS definido.")

    if not grid_gdf.crs.is_geographic:
        epsg = grid_gdf.crs.to_epsg()
        if epsg is None:
            raise RuntimeError(
                "La grilla tiene un CRS proyectado, pero no se pudo obtener EPSG."
            )
        return epsg

    estimated_crs = grid_gdf.estimate_utm_crs()

    if estimated_crs is None:
        raise RuntimeError(
            "No fue posible estimar CRS mÃ©trico. "
            "Define analysis_srid manualmente."
        )

    epsg = estimated_crs.to_epsg()

    if epsg is None:
        raise RuntimeError(
            "Se estimÃ³ un CRS mÃ©trico, pero no se pudo obtener EPSG."
        )

    return epsg


# ============================================================
# PREPARACIÃ“N DE GRILLA TEMPORAL
# ============================================================

def prepare_grid_gdf(grid_gdf, analysis_srid):
    """
    Limpia y reproyecta la grilla al CRS mÃ©trico de anÃ¡lisis.

    Retorna Ãºnicamente:
    - cell_id
    - geometry
    """

    if grid_gdf is None or grid_gdf.empty:
        raise ValueError("grid_gdf estÃ¡ vacÃ­o o es None.")

    if grid_gdf.crs is None:
        raise ValueError("grid_gdf no tiene CRS definido.")

    grid = grid_gdf.copy()

    if grid.crs.to_epsg() != analysis_srid:
        grid = grid.to_crs(epsg=analysis_srid)

    if "cell_id" not in grid.columns:
        grid = grid.reset_index(drop=True)
        grid["cell_id"] = grid.index + 1

    grid = grid[["cell_id", "geometry"]].copy()
    grid["cell_id"] = grid["cell_id"].astype(int)

    grid = grid[grid.geometry.notnull()].copy()
    grid = grid[~grid.geometry.is_empty].copy()

    if grid.empty:
        raise ValueError("La grilla quedÃ³ vacÃ­a despuÃ©s de limpiar geometrÃ­as.")

    return grid


def create_temp_grid_table(conn, grid_gdf, analysis_srid):
    """
    Sube la grilla a PostgreSQL como tabla temporal.

    Usa WKB + execute_values para que la carga sea mÃ¡s rÃ¡pida que WKT.
    """

    temp_table = f"tmp_density_grid_{uuid.uuid4().hex[:10]}"

    create_query = sql.SQL("""
        CREATE TEMP TABLE {temp_table} (
            cell_id INTEGER PRIMARY KEY,
            geom geometry(Geometry, {analysis_srid})
        );
    """).format(
        temp_table=sql.Identifier(temp_table),
        analysis_srid=sql.Literal(int(analysis_srid)),
    )

    insert_query = sql.SQL("""
        INSERT INTO {temp_table} (cell_id, geom)
        VALUES %s;
    """).format(
        temp_table=sql.Identifier(temp_table)
    )

    index_query = sql.SQL("""
        CREATE INDEX {index_name}
        ON {temp_table}
        USING GIST (geom);
    """).format(
        index_name=sql.Identifier(f"{temp_table}_geom_idx"),
        temp_table=sql.Identifier(temp_table),
    )

    analyze_query = sql.SQL("""
        ANALYZE {temp_table};
    """).format(
        temp_table=sql.Identifier(temp_table),
    )

    values = [
        (
            int(row.cell_id),
            Binary(row.geometry.wkb)
        )
        for row in grid_gdf.itertuples()
    ]

    with conn.cursor() as cur:
        cur.execute(create_query)

        execute_values(
            cur,
            insert_query.as_string(conn),
            values,
            template=f"(%s, ST_Force2D(ST_SetSRID(ST_GeomFromWKB(%s), {int(analysis_srid)})))"
        )

        cur.execute(index_query)
        cur.execute(analyze_query)

    return temp_table


def create_temp_extent_table(conn, temp_grid_table, analysis_srid, search_radius_m):
    """
    Crea una tabla temporal con el bbox de la grilla expandido.

    Se usa ST_Extent en vez de ST_Union porque es mucho mÃ¡s rÃ¡pido y
    suficiente para filtrar candidatos antes del KDE.
    """

    temp_extent = f"tmp_density_extent_{uuid.uuid4().hex[:10]}"

    query = sql.SQL("""
        CREATE TEMP TABLE {temp_extent} AS
        SELECT
            ST_Expand(
                ST_SetSRID(ST_Extent(geom)::geometry, {analysis_srid}),
                {search_radius_m}
            )::geometry(Polygon, {analysis_srid}) AS geom
        FROM {temp_grid_table};

        CREATE INDEX {idx_name}
        ON {temp_extent}
        USING GIST (geom);

        ANALYZE {temp_extent};
    """).format(
        temp_extent=sql.Identifier(temp_extent),
        temp_grid_table=sql.Identifier(temp_grid_table),
        idx_name=sql.Identifier(f"{temp_extent}_geom_idx"),
        search_radius_m=sql.Literal(float(search_radius_m)),
        analysis_srid=sql.Literal(int(analysis_srid)),
    )

    with conn.cursor() as cur:
        cur.execute(query)

    return temp_extent


def create_empty_temp_point_table(conn, analysis_srid, temp_prefix="tmp_points"):
    """
    Crea una tabla temporal vacÃ­a con la estructura estÃ¡ndar usada por
    el anÃ¡lisis.

    La tabla incluye:
        - id: identificador entero interno.
        - geom: geometrÃ­a puntual o representativa en el CRS mÃ©trico.
        - area_m2: Ã¡rea asociada al punto. Para puntos de entrada es
          NULL; para construcciones almacena el Ã¡rea del polÃ­gono de la
          construcciÃ³n en mÂ².

    Esta estructura comÃºn permite usar la misma funciÃ³n KDE para capas de
    puntos y para construcciones ponderadas por Ã¡rea.
    """

    temp_points = f"{temp_prefix}_{uuid.uuid4().hex[:10]}"

    query = sql.SQL("""
        CREATE TEMP TABLE {temp_points} (
            id INTEGER,
            geom geometry(Geometry, {analysis_srid}),
            area_m2 DOUBLE PRECISION
        );

        CREATE INDEX {idx_name}
        ON {temp_points}
        USING GIST (geom);

        ANALYZE {temp_points};
    """).format(
        temp_points=sql.Identifier(temp_points),
        idx_name=sql.Identifier(f"{temp_points}_geom_idx"),
        analysis_srid=sql.Literal(int(analysis_srid)),
    )

    with conn.cursor() as cur:
        cur.execute(query)

    return temp_points


def create_temp_point_table_fast(
    conn,
    source_schema,
    source_table,
    source_geom_column,
    temp_extent_table,
    analysis_srid,
    temp_prefix="tmp_points",
    fallback_source_srid=4326
):
    """
    Crea una tabla temporal optimizada de puntos de entrada.

    La funciÃ³n no calcula KDE; solo prepara los puntos para que el KDE sea
    rÃ¡pido y comparable:

    1. Valida que la tabla y columna de geometrÃ­a existan.
    2. Obtiene el SRID original de la fuente.
    3. Transforma el extent de anÃ¡lisis al SRID original.
    4. Filtra primero con ese extent para aprovechar el Ã­ndice espacial
       original de la tabla fuente.
    5. Transforma Ãºnicamente los puntos filtrados al CRS mÃ©trico.
    6. Fuerza geometrÃ­as 2D con ST_Force2D para evitar errores por Z.
    7. Agrega una columna `area_m2` como NULL, porque estas capas son puntos
       y no tienen ponderaciÃ³n por Ã¡rea.

    Retorna
    -------
    str
        Nombre de la tabla temporal creada.
    """

    if not table_exists(conn, source_schema, source_table):
        raise RuntimeError(f"No existe la tabla {source_schema}.{source_table}.")

    if not column_exists(conn, source_schema, source_table, source_geom_column):
        raise RuntimeError(
            f"No existe la columna {source_geom_column} en "
            f"{source_schema}.{source_table}."
        )

    if not column_has_non_null(conn, source_schema, source_table, source_geom_column):
        return create_empty_temp_point_table(
            conn=conn,
            analysis_srid=analysis_srid,
            temp_prefix=temp_prefix
        )

    temp_points = f"{temp_prefix}_{uuid.uuid4().hex[:10]}"

    source_srid = get_geometry_srid(
        conn,
        source_schema,
        source_table,
        source_geom_column
    )

    if source_srid is None or source_srid == 0:
        source_srid = fallback_source_srid

    source_geom_norm = sql.SQL("""
        CASE
            WHEN ST_SRID(p.{source_geom_column}) = 0
                THEN ST_SetSRID(p.{source_geom_column}, {source_srid})
            ELSE p.{source_geom_column}
        END
    """).format(
        source_geom_column=sql.Identifier(source_geom_column),
        source_srid=sql.Literal(int(source_srid)),
    )

    query = sql.SQL("""
        CREATE TEMP TABLE {temp_points} AS
        WITH extent_source AS (
            SELECT
                ST_Transform(geom, {source_srid}) AS geom
            FROM {temp_extent_table}
        )
        SELECT
            ROW_NUMBER() OVER ()::integer AS id,
            ST_Force2D(
                ST_Transform(
                    {source_geom_norm},
                    {analysis_srid}
                )
            )::geometry(Geometry, {analysis_srid}) AS geom,
            NULL::double precision AS area_m2
        FROM {source_schema}.{source_table} p
        JOIN extent_source e
          ON p.{source_geom_column} IS NOT NULL
         AND {source_geom_norm} && e.geom
         AND ST_Intersects({source_geom_norm}, e.geom);

        CREATE INDEX {idx_name}
        ON {temp_points}
        USING GIST (geom);

        ANALYZE {temp_points};
    """).format(
        temp_points=sql.Identifier(temp_points),
        temp_extent_table=sql.Identifier(temp_extent_table),
        source_schema=sql.Identifier(source_schema),
        source_table=sql.Identifier(source_table),
        source_geom_column=sql.Identifier(source_geom_column),
        source_geom_norm=source_geom_norm,
        idx_name=sql.Identifier(f"{temp_points}_geom_idx"),
        analysis_srid=sql.Literal(int(analysis_srid)),
        source_srid=sql.Literal(int(source_srid)),
    )

    with conn.cursor() as cur:
        cur.execute(query)

    return temp_points


def create_temp_construction_point_table_fast(
    conn,
    admin_cfg,
    temp_extent_table,
    analysis_srid,
    construction_point_column="geom_punto",
    use_construction_point_column=True,
    fallback_source_srid=4326
):
    """
    Crea una tabla temporal optimizada de construcciones con ponderaciÃ³n
    por Ã¡rea.

    Cada construcciÃ³n queda representada por un punto y un peso de Ã¡rea:

        id
        geom     -> punto representativo en CRS mÃ©trico
        area_m2  -> Ã¡rea del polÃ­gono de construcciÃ³n en mÂ²

    Punto representativo
    --------------------
    1. Si existe `geom_punto` y tiene datos, se usa esa columna.
    2. Si no, se usa `ST_PointOnSurface(geom)`.

    Ãrea de construcciÃ³n
    --------------------
    El Ã¡rea siempre se calcula a partir del polÃ­gono `geom` de la tabla de
    construcciones, transformado al CRS mÃ©trico de anÃ¡lisis:

        area_m2 = ST_Area(ST_Transform(geom, analysis_srid))

    Esa Ã¡rea se usa despuÃ©s como factor multiplicativo en el KDE:

        kde_construcciones_raw = SUM(area_m2 * peso_kernel)

    Por tanto, el KDE de construcciones representa concentraciÃ³n de Ã¡rea
    construida, no simple conteo de edificios.
    """

    schema_name = admin_cfg.get("construcciones_schema", admin_cfg["schema"])
    table_name = admin_cfg["construcciones_table"]
    geom_column = admin_cfg["construcciones_geom"]

    if not table_exists(conn, schema_name, table_name):
        raise RuntimeError(f"No existe la tabla {schema_name}.{table_name}.")

    if not column_exists(conn, schema_name, table_name, geom_column):
        raise RuntimeError(
            f"No existe la columna poligonal {geom_column} en "
            f"{schema_name}.{table_name}."
        )

    use_point_column = (
        use_construction_point_column
        and column_exists(conn, schema_name, table_name, construction_point_column)
        and column_has_non_null(conn, schema_name, table_name, construction_point_column)
    )

    if use_point_column:
        source_geom_column = construction_point_column
    else:
        source_geom_column = geom_column

    if not column_exists(conn, schema_name, table_name, source_geom_column):
        raise RuntimeError(
            f"No existe la columna {source_geom_column} en "
            f"{schema_name}.{table_name}."
        )

    if not column_has_non_null(conn, schema_name, table_name, source_geom_column):
        return create_empty_temp_point_table(
            conn=conn,
            analysis_srid=analysis_srid,
            temp_prefix="tmp_const_points"
        )

    if not column_has_non_null(conn, schema_name, table_name, geom_column):
        return create_empty_temp_point_table(
            conn=conn,
            analysis_srid=analysis_srid,
            temp_prefix="tmp_const_points"
        )

    source_srid = get_geometry_srid(
        conn,
        schema_name,
        table_name,
        source_geom_column
    )

    if source_srid is None or source_srid == 0:
        source_srid = fallback_source_srid

    polygon_srid = get_geometry_srid(
        conn,
        schema_name,
        table_name,
        geom_column
    )

    if polygon_srid is None or polygon_srid == 0:
        polygon_srid = fallback_source_srid

    temp_points = f"tmp_const_points_{uuid.uuid4().hex[:10]}"

    base_geom_norm = sql.SQL("""
        CASE
            WHEN ST_SRID(c.{source_geom_column}) = 0
                THEN ST_SetSRID(c.{source_geom_column}, {source_srid})
            ELSE c.{source_geom_column}
        END
    """).format(
        source_geom_column=sql.Identifier(source_geom_column),
        source_srid=sql.Literal(int(source_srid)),
    )

    polygon_geom_norm = sql.SQL("""
        CASE
            WHEN ST_SRID(c.{geom_column}) = 0
                THEN ST_SetSRID(c.{geom_column}, {polygon_srid})
            ELSE c.{geom_column}
        END
    """).format(
        geom_column=sql.Identifier(geom_column),
        polygon_srid=sql.Literal(int(polygon_srid)),
    )

    if use_point_column:
        point_expr_source = base_geom_norm
    else:
        point_expr_source = sql.SQL("ST_PointOnSurface({base_geom})").format(
            base_geom=base_geom_norm
        )

    area_expr = sql.SQL("""
        GREATEST(
            ST_Area(
                ST_Force2D(
                    ST_Transform(
                        {polygon_geom_norm},
                        {analysis_srid}
                    )
                )
            ),
            0
        )
    """).format(
        polygon_geom_norm=polygon_geom_norm,
        analysis_srid=sql.Literal(int(analysis_srid)),
    )

    query = sql.SQL("""
        CREATE TEMP TABLE {temp_points} AS
        WITH extent_source AS (
            SELECT
                ST_Transform(geom, {source_srid}) AS geom
            FROM {temp_extent_table}
        )
        SELECT
            ROW_NUMBER() OVER ()::integer AS id,
            ST_Force2D(
                ST_Transform(
                    {point_expr_source},
                    {analysis_srid}
                )
            )::geometry(Geometry, {analysis_srid}) AS geom,
            {area_expr}::double precision AS area_m2
        FROM {schema_name}.{table_name} c
        JOIN extent_source e
          ON c.{source_geom_column} IS NOT NULL
         AND c.{geom_column} IS NOT NULL
         AND {base_geom_norm} && e.geom
         AND ST_Intersects({base_geom_norm}, e.geom);

        CREATE INDEX {idx_name}
        ON {temp_points}
        USING GIST (geom);

        ANALYZE {temp_points};
    """).format(
        temp_points=sql.Identifier(temp_points),
        temp_extent_table=sql.Identifier(temp_extent_table),
        schema_name=sql.Identifier(schema_name),
        table_name=sql.Identifier(table_name),
        source_geom_column=sql.Identifier(source_geom_column),
        geom_column=sql.Identifier(geom_column),
        base_geom_norm=base_geom_norm,
        point_expr_source=point_expr_source,
        area_expr=area_expr,
        idx_name=sql.Identifier(f"{temp_points}_geom_idx"),
        analysis_srid=sql.Literal(int(analysis_srid)),
        source_srid=sql.Literal(int(source_srid)),
    )

    with conn.cursor() as cur:
        cur.execute(query)

    return temp_points


def count_table(conn, table_name):
    """
    Cuenta registros de una tabla temporal.
    """

    query = sql.SQL("""
        SELECT COUNT(*) FROM {table_name};
    """).format(
        table_name=sql.Identifier(table_name)
    )

    with conn.cursor() as cur:
        cur.execute(query)
        return int(cur.fetchone()[0])


def _analysis_progress(progress_callback, verbose, message):
    if progress_callback is not None:
        try:
            progress_callback(str(message))
        except Exception:
            pass
    elif verbose:
        print(message)


def _timed_step(progress_callback, verbose, label, start_time):
    elapsed = time.perf_counter() - start_time
    _analysis_progress(
        progress_callback,
        verbose,
        f"[perfil] {label}: {elapsed:.2f} s",
    )


def drop_temp_tables(conn, table_names):
    """
    Elimina varias tablas temporales si existen.
    """

    if not table_names:
        return

    with conn.cursor() as cur:
        for table_name in table_names:
            if table_name:
                cur.execute(
                    sql.SQL("DROP TABLE IF EXISTS {table_name};").format(
                        table_name=sql.Identifier(table_name)
                    )
                )


# ============================================================
# CTEs SOBRE TABLAS TEMPORALES OPTIMIZADAS
# ============================================================

def build_temp_point_count_cte(temp_point_table, alias):
    """
    Construye un CTE de conteo directo por celda.

    Usa una tabla temporal de puntos ya filtrada y reproyectada.
    """

    cte_name = f"{alias}_counts"
    count_col = f"n_{alias}"

    return sql.SQL("""
        {cte_name} AS (
            SELECT
                g.cell_id,
                COUNT(p.id)::integer AS {count_col}
            FROM grid_base g
            JOIN {temp_point_table} p
              ON p.geom && g.geom
             AND ST_Intersects(p.geom, g.geom)
            GROUP BY g.cell_id
        )
    """).format(
        cte_name=sql.Identifier(cte_name),
        count_col=sql.Identifier(count_col),
        temp_point_table=sql.Identifier(temp_point_table),
    )


def build_kernel_weight_sql(distance_sql, bandwidth_m, kernel_type="epanechnikov"):
    """
    Construye la expresiÃ³n SQL del peso kernel.

    ParÃ¡metros
    ----------
    distance_sql : psycopg2.sql.Composable
        ExpresiÃ³n SQL que calcula la distancia entre el centroide de la
        celda y el punto evaluado.
    bandwidth_m : float
        Ancho de banda en metros.
    kernel_type : str
        Tipo de kernel. Para este flujo se recomienda "epanechnikov".

    Retorna
    -------
    psycopg2.sql.Composable
        ExpresiÃ³n SQL del peso.

    Notas
    -----
    Epanechnikov:
        peso = 1 - (distancia / bandwidth)^2, si distancia <= bandwidth
        peso = 0, en caso contrario

    Gaussiano se conserva como alternativa, pero el flujo recomendado usa
    Epanechnikov para caracterizar localmente cada celda.
    """

    kernel_type = normalize_key(kernel_type)

    if kernel_type in ["epanechnikov", "epanechikov", "epanovich", "epa"]:
        return sql.SQL("""
            GREATEST(
                0,
                1 - POWER(({distance}) / {bandwidth_m}, 2)
            )
        """).format(
            distance=distance_sql,
            bandwidth_m=sql.Literal(float(bandwidth_m)),
        )

    if kernel_type in ["gaussian", "gaussiano", "normal"]:
        return sql.SQL("""
            EXP(
                -0.5 * POWER(({distance}) / {bandwidth_m}, 2)
            )
        """).format(
            distance=distance_sql,
            bandwidth_m=sql.Literal(float(bandwidth_m)),
        )

    if kernel_type in ["triangular"]:
        return sql.SQL("""
            GREATEST(
                0,
                1 - (({distance}) / {bandwidth_m})
            )
        """).format(
            distance=distance_sql,
            bandwidth_m=sql.Literal(float(bandwidth_m)),
        )

    if kernel_type in ["quartic", "biweight"]:
        return sql.SQL("""
            POWER(
                GREATEST(
                    0,
                    1 - POWER(({distance}) / {bandwidth_m}, 2)
                ),
                2
            )
        """).format(
            distance=distance_sql,
            bandwidth_m=sql.Literal(float(bandwidth_m)),
        )

    raise ValueError(
        "kernel_type debe ser 'epanechnikov', 'gaussian', 'triangular' o 'quartic'."
    )


def build_temp_point_kde_cte(
    temp_point_table,
    alias,
    bandwidth_m,
    search_radius_m,
    kde_max_neighbors=80,
    kernel_type="epanechnikov",
    weight_column=None
):
    """
    Construye un CTE KDE optimizado usando tablas temporales.

    Para capas de puntos, el KDE crudo es:

        kde_layer_raw = SUM(peso_kernel)

    Para construcciones, si `weight_column="area_m2"`, el KDE crudo es:

        kde_construcciones_raw = SUM(area_m2 * peso_kernel)

    La funciÃ³n kernel recomendada es Epanechnikov:

        peso = 1 - (distancia / bandwidth_m)^2, si distancia <= bandwidth_m
        peso = 0, si distancia > bandwidth_m

    Esto permite caracterizar la celda por su entorno local. Con
    Epanechnikov se recomienda `search_radius_m = bandwidth_m`, porque
    fuera del bandwidth el peso es cero.

    ParÃ¡metros
    ----------
    temp_point_table : str
        Tabla temporal de puntos ya filtrados y reproyectados.
    alias : str
        Alias usado para nombrar el CTE y la columna de salida.
    bandwidth_m : float
        Ancho de banda del kernel en metros.
    search_radius_m : float
        Radio mÃ¡ximo de bÃºsqueda. Para Epanechnikov conviene igualarlo
        a `bandwidth_m`.
    kde_max_neighbors : int | None
        LÃ­mite de vecinos evaluados por celda. Si es None o <= 0, evalÃºa
        todos los puntos dentro del radio.
    kernel_type : str
        Tipo de kernel. Por defecto "epanechnikov".
    weight_column : str | None
        Columna de peso. Para construcciones usar "area_m2". Para capas
        de puntos dejar None.
    """

    cte_name = f"{alias}_kde"
    kde_col = f"kde_{alias}_raw"

    distance_sql = sql.SQL("ST_Distance(g.centroid_geom, p.geom)")
    kernel_weight = build_kernel_weight_sql(
        distance_sql=distance_sql,
        bandwidth_m=bandwidth_m,
        kernel_type=kernel_type
    )

    if weight_column:
        contribution_sql = sql.SQL("COALESCE(p.{weight_column}, 0) * ({kernel_weight})").format(
            weight_column=sql.Identifier(weight_column),
            kernel_weight=kernel_weight,
        )
    else:
        contribution_sql = kernel_weight

    if kde_max_neighbors is not None and int(kde_max_neighbors) > 0:
        return sql.SQL("""
            {cte_name} AS (
                SELECT
                    g.cell_id,
                    COALESCE(
                        SUM({contribution_sql}),
                        0
                    )::double precision AS {kde_col}
                FROM grid_base g
                JOIN LATERAL (
                    SELECT p.geom, p.area_m2
                    FROM {temp_point_table} p
                    WHERE p.geom && ST_Expand(g.centroid_geom, {search_radius_m})
                      AND ST_DWithin(
                            g.centroid_geom,
                            p.geom,
                            {search_radius_m}
                          )
                    ORDER BY p.geom <-> g.centroid_geom
                    LIMIT {kde_max_neighbors}
                ) p ON TRUE
                GROUP BY g.cell_id
            )
        """).format(
            cte_name=sql.Identifier(cte_name),
            kde_col=sql.Identifier(kde_col),
            temp_point_table=sql.Identifier(temp_point_table),
            contribution_sql=contribution_sql,
            search_radius_m=sql.Literal(float(search_radius_m)),
            kde_max_neighbors=sql.Literal(int(kde_max_neighbors)),
        )

    return sql.SQL("""
        {cte_name} AS (
            SELECT
                g.cell_id,
                COALESCE(
                    SUM({contribution_sql}),
                    0
                )::double precision AS {kde_col}
            FROM grid_base g
            JOIN {temp_point_table} p
              ON p.geom && ST_Expand(g.centroid_geom, {search_radius_m})
             AND ST_DWithin(
                    g.centroid_geom,
                    p.geom,
                    {search_radius_m}
                 )
            GROUP BY g.cell_id
        )
    """).format(
        cte_name=sql.Identifier(cte_name),
        kde_col=sql.Identifier(kde_col),
        temp_point_table=sql.Identifier(temp_point_table),
        contribution_sql=contribution_sql,
        search_radius_m=sql.Literal(float(search_radius_m)),
    )


def build_density_query_hybrid_fast(
    temp_grid_table,
    temp_construction_points,
    temp_layer_tables,
    point_layers=None,
    density_mode="hybrid",
    bandwidth_m=300,
    search_radius_m=300,
    kde_max_neighbors=100,
    construction_kde_max_neighbors=None,
    kernel_type="epanechnikov",
):
    """
    Construye la consulta principal optimizada.

    La consulta trabaja Ãºnicamente con tablas temporales:
    - grilla temporal;
    - puntos temporales de construcciones;
    - puntos temporales de la capa activa o capas de entrada.

    Para el KDE usa `kernel_type`, por defecto Epanechnikov. En las
    construcciones se usa `area_m2` como peso:

        kde_construcciones_raw = SUM(area_m2 * peso_kernel)

    En las capas de puntos de entrada se usa:

        kde_layer_raw = SUM(peso_kernel)

    ParÃ¡metros clave
    ----------------
    construction_kde_max_neighbors:
        LÃ­mite de vecinos para construcciones. Por defecto None para no
        perder Ã¡rea construida dentro del radio. Si el volumen es muy alto,
        puede usarse 200 o 300.
    kde_max_neighbors:
        LÃ­mite de vecinos para capas de puntos.
    """

    if point_layers is None:
        point_layers = []

    density_mode = normalize_key(density_mode)

    if density_mode not in ["count", "kde", "hybrid"]:
        raise ValueError("density_mode debe ser 'count', 'kde' o 'hybrid'.")

    use_counts = density_mode in ["count", "hybrid"]
    use_kde = density_mode in ["kde", "hybrid"]

    ctes = []

    grid_base_cte = sql.SQL("""
        grid_base AS (
            SELECT
                cell_id,
                geom,
                ST_Centroid(geom) AS centroid_geom,
                ST_Area(geom) AS area_m2
            FROM {temp_grid_table}
        )
    """).format(
        temp_grid_table=sql.Identifier(temp_grid_table)
    )

    ctes.append(grid_base_cte)

    if use_counts:
        ctes.append(
            build_temp_point_count_cte(
                temp_point_table=temp_construction_points,
                alias="construcciones"
            )
        )

        for layer in point_layers:
            alias = layer["alias"]
            ctes.append(
                build_temp_point_count_cte(
                    temp_point_table=temp_layer_tables[alias],
                    alias=alias
                )
            )

    if use_kde:
        ctes.append(
            build_temp_point_kde_cte(
                temp_point_table=temp_construction_points,
                alias="construcciones",
                bandwidth_m=bandwidth_m,
                search_radius_m=search_radius_m,
                kde_max_neighbors=construction_kde_max_neighbors,
                kernel_type=kernel_type,
                weight_column="area_m2"
            )
        )

        for layer in point_layers:
            alias = layer["alias"]
            ctes.append(
                build_temp_point_kde_cte(
                    temp_point_table=temp_layer_tables[alias],
                    alias=alias,
                    bandwidth_m=bandwidth_m,
                    search_radius_m=search_radius_m,
                    kde_max_neighbors=kde_max_neighbors,
                    kernel_type=kernel_type,
                    weight_column=None
                )
            )

    select_parts = [
        sql.SQL("g.cell_id"),
        sql.SQL("ST_AsBinary(g.geom) AS geom_wkb"),
        sql.SQL("g.area_m2")
    ]

    joins = []

    if use_counts:
        select_parts.append(
            sql.SQL(
                "COALESCE(construcciones_c.n_construcciones, 0)::integer "
                "AS n_construcciones"
            )
        )

        joins.append(
            sql.SQL("""
                LEFT JOIN construcciones_counts construcciones_c
                  ON construcciones_c.cell_id = g.cell_id
            """)
        )

        for layer in point_layers:
            alias = layer["alias"]
            count_col = f"n_{alias}"
            table_alias = f"{alias}_c"
            cte_name = f"{alias}_counts"

            select_parts.append(
                sql.SQL(
                    "COALESCE({table_alias}.{count_col}, 0)::integer "
                    "AS {count_col}"
                ).format(
                    table_alias=sql.Identifier(table_alias),
                    count_col=sql.Identifier(count_col)
                )
            )

            joins.append(
                sql.SQL("""
                    LEFT JOIN {cte_name} {table_alias}
                      ON {table_alias}.cell_id = g.cell_id
                """).format(
                    cte_name=sql.Identifier(cte_name),
                    table_alias=sql.Identifier(table_alias)
                )
            )

    if use_kde:
        select_parts.append(
            sql.SQL(
                "COALESCE(construcciones_k.kde_construcciones_raw, 0)::double precision "
                "AS kde_construcciones_raw"
            )
        )

        joins.append(
            sql.SQL("""
                LEFT JOIN construcciones_kde construcciones_k
                  ON construcciones_k.cell_id = g.cell_id
            """)
        )

        for layer in point_layers:
            alias = layer["alias"]
            kde_col = f"kde_{alias}_raw"
            table_alias = f"{alias}_k"
            cte_name = f"{alias}_kde"

            select_parts.append(
                sql.SQL(
                    "COALESCE({table_alias}.{kde_col}, 0)::double precision "
                    "AS {kde_col}"
                ).format(
                    table_alias=sql.Identifier(table_alias),
                    kde_col=sql.Identifier(kde_col)
                )
            )

            joins.append(
                sql.SQL("""
                    LEFT JOIN {cte_name} {table_alias}
                      ON {table_alias}.cell_id = g.cell_id
                """).format(
                    cte_name=sql.Identifier(cte_name),
                    table_alias=sql.Identifier(table_alias)
                )
            )

    query = sql.SQL("""
        WITH
            {ctes}

        SELECT
            {select_parts}
        FROM grid_base g
            {joins}
        ORDER BY g.cell_id;
    """).format(
        ctes=sql.SQL(",\n            ").join(ctes),
        select_parts=sql.SQL(",\n            ").join(select_parts),
        joins=sql.SQL("\n            ").join(joins),
    )

    return query


def fetch_density_dataframe(conn, query):
    """
    Ejecuta una consulta SQL y retorna un DataFrame.
    """

    with conn.cursor() as cur:
        cur.execute(query)
        rows = cur.fetchall()
        columns = [desc[0] for desc in cur.description]

    return pd.DataFrame(rows, columns=columns)


def minmax_normalize(series):
    """
    NormalizaciÃ³n min-max robusta a rango 0-1.

    Si todos los valores son iguales y mayores a cero, retorna 1.
    Si todos son cero o no hay valores vÃ¡lidos, retorna 0.
    """

    s = pd.to_numeric(series, errors="coerce").astype(float)
    valid = s[np.isfinite(s)]

    if valid.empty:
        return pd.Series(np.zeros(len(s)), index=s.index)

    min_val = valid.min()
    max_val = valid.max()

    if max_val == min_val:
        if max_val > 0:
            return pd.Series(np.ones(len(s)), index=s.index)
        return pd.Series(np.zeros(len(s)), index=s.index)

    return (s - min_val) / (max_val - min_val)


def build_density_metrics(df, selected_layers, density_mode="hybrid"):
    """
    Calcula mÃ©tricas derivadas a partir del resultado SQL.

    El DataFrame SQL trae mÃ©tricas crudas por celda. Esta funciÃ³n agrega:

    1. Ãrea de celda:
       - area_km2 = area_m2 / 1_000_000

       Esta Ã¡rea se usa para densidades simples por kmÂ². Si todas las
       celdas son del mismo tamaÃ±o, la densidad por kmÂ² conserva el mismo
       orden relativo que el conteo, pero permite comparar resultados si
       en algÃºn momento se usan celdas no uniformes.

    2. Densidades simples:
       - densidad_construcciones_km2
       - densidad_{layer}_km2

    3. KDE normalizado por Min-Max:
       - kde_*_norm en rango 0 a 1
       - kde_*_pct en rango 0 a 100

    4. Ratio KDE capa / KDE construcciones:
       - ratio_kde_{layer}_construcciones

       Este ratio es la variable central para idoneidad. Su interpretaciÃ³n
       es inversa:

           ratio bajo = mayor potencial prospectivo
           ratio alto = menor potencial prospectivo

    5. Score por relacion inversa:
       - ratio_kde_{layer}_construcciones = kde_layer_norm / kde_construcciones_norm
       - score_oportunidad_{layer} = normalizacion de
         kde_construcciones_norm / kde_layer_norm

       La idoneidad aumenta cuando hay alta intensidad constructiva y baja
       presencia relativa de puntos evaluados.
    """

    if df.empty:
        return df

    result = df.copy()
    result["area_km2"] = result["area_m2"] / 1_000_000

    density_mode = normalize_key(density_mode)

    point_count_columns = []

    if "n_construcciones" in result.columns:
        result["densidad_construcciones_km2"] = np.where(
            result["area_km2"] > 0,
            result["n_construcciones"] / result["area_km2"],
            np.nan
        )

    for layer in selected_layers:
        alias = safe_column_name(layer)
        count_col = f"n_{alias}"

        if count_col not in result.columns:
            continue

        point_count_columns.append(count_col)

        density_col = f"densidad_{alias}_km2"
        ratio_col = f"relacion_{alias}_construcciones"

        result[density_col] = np.where(
            result["area_km2"] > 0,
            result[count_col] / result["area_km2"],
            np.nan
        )

        if "n_construcciones" in result.columns:
            result[ratio_col] = np.where(
                result["n_construcciones"] > 0,
                result[count_col] / result["n_construcciones"],
                np.nan
            )

    if point_count_columns:
        result["n_puntos_total"] = result[point_count_columns].sum(axis=1)
        result["densidad_total_puntos_km2"] = np.where(
            result["area_km2"] > 0,
            result["n_puntos_total"] / result["area_km2"],
            np.nan
        )

        if "n_construcciones" in result.columns:
            result["relacion_total_puntos_construcciones"] = np.where(
                result["n_construcciones"] > 0,
                result["n_puntos_total"] / result["n_construcciones"],
                np.nan
            )

    if "kde_construcciones_raw" in result.columns:
        result["kde_construcciones_norm"] = minmax_normalize(
            result["kde_construcciones_raw"]
        )
        result["kde_construcciones_pct"] = (
            result["kde_construcciones_norm"] * 100
        )

    kde_layer_raw_columns = []

    for layer in selected_layers:
        alias = safe_column_name(layer)
        kde_raw_col = f"kde_{alias}_raw"

        if kde_raw_col not in result.columns:
            continue

        kde_layer_raw_columns.append(kde_raw_col)

        kde_norm_col = f"kde_{alias}_norm"
        kde_pct_col = f"kde_{alias}_pct"

        result[kde_norm_col] = minmax_normalize(result[kde_raw_col])
        result[kde_pct_col] = result[kde_norm_col] * 100

        if "kde_construcciones_norm" in result.columns:
            ratio_kde_col = f"ratio_kde_{alias}_construcciones"
            score_col = f"score_oportunidad_{alias}"
            score_pct_col = f"score_oportunidad_{alias}_pct"

            result[ratio_kde_col] = np.where(
                result["kde_construcciones_norm"] > 0,
                result[kde_norm_col] / result["kde_construcciones_norm"],
                np.nan
            )

            inverse_ratio = np.where(
                result["kde_construcciones_norm"] > 0,
                result["kde_construcciones_norm"] / np.maximum(result[kde_norm_col], 1e-9),
                np.nan,
            )
            result[score_col] = minmax_normalize(pd.Series(inverse_ratio, index=result.index))

            result[score_pct_col] = result[score_col] * 100

    if kde_layer_raw_columns:
        result["kde_puntos_total_raw"] = result[kde_layer_raw_columns].sum(axis=1)
        result["kde_puntos_total_norm"] = minmax_normalize(
            result["kde_puntos_total_raw"]
        )
        result["kde_puntos_total_pct"] = result["kde_puntos_total_norm"] * 100

        if "kde_construcciones_norm" in result.columns:
            result["ratio_kde_total_construcciones"] = np.where(
                result["kde_construcciones_norm"] > 0,
                result["kde_puntos_total_norm"] / result["kde_construcciones_norm"],
                np.nan
            )

            inverse_total_ratio = np.where(
                result["kde_construcciones_norm"] > 0,
                result["kde_construcciones_norm"] / np.maximum(result["kde_puntos_total_norm"], 1e-9),
                np.nan,
            )
            result["score_oportunidad_total"] = minmax_normalize(
                pd.Series(inverse_total_ratio, index=result.index)
            )
            result["score_oportunidad_total_pct"] = (
                result["score_oportunidad_total"] * 100
            )

    return result


def percentile_0_100(series, ascending=True):
    """
    Convierte una serie numÃ©rica en percentiles de 0 a 100.

    ParÃ¡metros
    ----------
    series : pandas.Series
        Serie numÃ©rica.
    ascending : bool
        Si True, los valores mÃ¡s bajos reciben percentiles mÃ¡s bajos.
        Si False, los valores mÃ¡s altos reciben percentiles mÃ¡s bajos.

    Retorna
    -------
    pandas.Series
        Percentil 0 a 100. Los valores no vÃ¡lidos quedan como NaN.

    Uso metodolÃ³gico
    ----------------
    Para el ratio KDE capa / KDE construcciones interesa que los valores
    mÃ¡s bajos sean los mÃ¡s prospectivos. Por eso se usa ascending=True y
    luego se clasifican las celdas en:

        0-30  -> prioridad primaria
        30-60 -> prioridad secundaria
    """

    s = pd.to_numeric(series, errors="coerce").replace([np.inf, -np.inf], np.nan)
    result = pd.Series(np.nan, index=s.index, dtype="float64")
    valid = s.dropna()

    if valid.empty:
        return result

    if len(valid) == 1:
        result.loc[valid.index] = 0.0
        return result

    ranks = valid.rank(method="average", ascending=ascending)
    pct = (ranks - 1) / (len(valid) - 1) * 100
    result.loc[valid.index] = pct
    return result


def add_suitability_percentiles(
    gdf,
    ratio_col,
    kde_layer_col,
    min_construction_norm=1e-9,
):
    """
    Agrega percentiles robustos de idoneidad.

    El ratio de saturacion se calcula como:

        ratio = KDE_puntos_norm / KDE_construcciones_norm

    La idoneidad usa la relacion inversa:

        idoneidad_ratio_inverso_raw = KDE_construcciones_norm / KDE_puntos_norm

    Se usa un epsilon en el denominador para que, si KDE_puntos_norm es 0,
    la intensidad constructiva siga diferenciando las celdas.
    """
    valid_context = gdf["kde_construcciones_norm"] > min_construction_norm

    gdf["construcciones_percentil_0_100"] = percentile_0_100(
        gdf["kde_construcciones_norm"],
        ascending=True,
    )

    gdf["ratio_percentil_0_100"] = percentile_0_100(
        gdf[ratio_col],
        ascending=True,
    )

    if kde_layer_col not in gdf.columns:
        gdf["idoneidad_ratio_inverso_raw"] = np.nan
    else:
        layer_kde = pd.to_numeric(gdf[kde_layer_col], errors="coerce")
        construction_kde = pd.to_numeric(gdf["kde_construcciones_norm"], errors="coerce")
        gdf["idoneidad_ratio_inverso_raw"] = np.where(
            valid_context,
            construction_kde / np.maximum(layer_kde, 1e-9),
            np.nan,
        )

    gdf["idoneidad_percentil_0_100"] = percentile_0_100(
        gdf["idoneidad_ratio_inverso_raw"],
        ascending=False,
    )
    gdf["idoneidad_score_source"] = "ratio_inverso"
    gdf["idoneidad_score_0_100"] = 100 - gdf["idoneidad_percentil_0_100"]
    return gdf


def classify_suitability_cells(
    density_gdf,
    target_layer="total",
    primary_ratio_percentile_max=50,
    secondary_ratio_percentile_max=90,
    high_construction_percentile=70,
    keep_low_construction_as_secondary=True,
    min_construction_norm=1e-9
):
    """
    Clasifica celdas de idoneidad prospectiva a partir del ratio:

        ratio = KDE_capa_norm / KDE_construcciones_norm

    La relaciÃ³n es inversa:

        ratio bajo = mayor idoneidad prospectiva
        ratio alto = menor idoneidad prospectiva

    ClasificaciÃ³n base por percentil del ratio
    ------------------------------------------
    - Percentil 0 a 30  -> prioridad primaria.
    - Percentil 30 a 60 -> prioridad secundaria.

    ConsideraciÃ³n de robustez por construcciones
    --------------------------------------------
    TambiÃ©n se calcula `construcciones_percentil_0_100`, derivado de
    `kde_construcciones_norm`. Esto permite identificar si la celda estÃ¡
    en una zona de alta intensidad construida.

    Por defecto:
    - Una celda con ratio 0-30 y construcciones altas queda como primaria.
    - Una celda con ratio 0-30 pero construcciones no altas pasa a secundaria,
      porque puede ser una zona emergente o poco construida.
    - Una celda con ratio 30-60 queda como secundaria.

    Si quieres que TODO el percentil 0-30 sea primario sin exigir alta
    construcciÃ³n, usa `high_construction_percentile=0`.

    ParÃ¡metros
    ----------
    density_gdf : geopandas.GeoDataFrame
        Resultado de `run_density_analysis`.
    target_layer : str
        Capa evaluada: "comercial", "sitios", "bancario", "empresarial"
        o "total".
    primary_ratio_percentile_max : float
        LÃ­mite superior de percentil para prioridad primaria.
    secondary_ratio_percentile_max : float
        LÃ­mite superior de percentil para prioridad secundaria.
    high_construction_percentile : float
        Percentil mÃ­nimo de construcciones para considerar alta intensidad
        construida en prioridad primaria.
    keep_low_construction_as_secondary : bool
        Si True, las celdas con bajo ratio pero sin alta construcciÃ³n no se
        descartan: se degradan a prioridad secundaria.
    min_construction_norm : float
        MÃ­nimo de KDE de construcciones normalizado para que el ratio sea
        interpretable.

    Retorna
    -------
    geopandas.GeoDataFrame
        Celdas con prioridad "primaria" o "secundaria".
    """

    if density_gdf is None or density_gdf.empty:
        raise ValueError("density_gdf estÃ¡ vacÃ­o o es None.")

    gdf = density_gdf.copy()
    target_layer = safe_column_name(target_layer)

    if "kde_construcciones_norm" not in gdf.columns:
        raise KeyError("Falta la columna kde_construcciones_norm.")

    if target_layer == "total":
        ratio_col = "ratio_kde_total_construcciones"
        kde_layer_col = "kde_puntos_total_norm"
        n_layer_col = "n_puntos_total"
    else:
        ratio_col = f"ratio_kde_{target_layer}_construcciones"
        kde_layer_col = f"kde_{target_layer}_norm"
        n_layer_col = f"n_{target_layer}"

    if ratio_col not in gdf.columns:
        if kde_layer_col not in gdf.columns:
            raise KeyError(
                f"No existe {ratio_col} ni {kde_layer_col}. "
                f"Revisa target_layer='{target_layer}'."
            )

        gdf[ratio_col] = np.where(
            gdf["kde_construcciones_norm"] > min_construction_norm,
            gdf[kde_layer_col] / gdf["kde_construcciones_norm"],
            np.nan
        )

    gdf.loc[
        gdf["kde_construcciones_norm"] <= min_construction_norm,
        ratio_col
    ] = np.nan

    gdf = add_suitability_percentiles(
        gdf=gdf,
        ratio_col=ratio_col,
        kde_layer_col=kde_layer_col,
        min_construction_norm=min_construction_norm,
    )

    gdf["target_layer"] = target_layer
    gdf["target_ratio_col"] = ratio_col
    gdf["target_priority"] = "no_prioritaria"

    primary_ratio_mask = (
        gdf["idoneidad_percentil_0_100"] <= primary_ratio_percentile_max
    )

    secondary_ratio_mask = (
        (gdf["idoneidad_percentil_0_100"] > primary_ratio_percentile_max)
        &
        (gdf["idoneidad_percentil_0_100"] <= secondary_ratio_percentile_max)
    )

    high_construction_mask = (
        gdf["construcciones_percentil_0_100"] >= high_construction_percentile
    )

    primary_mask = primary_ratio_mask & high_construction_mask
    secondary_mask = secondary_ratio_mask.copy()

    if keep_low_construction_as_secondary:
        secondary_mask = secondary_mask | (primary_ratio_mask & ~high_construction_mask)

    if n_layer_col in gdf.columns:
        gdf["target_n_layer"] = gdf[n_layer_col].fillna(0)
    else:
        gdf["target_n_layer"] = np.nan

    gdf.loc[secondary_mask, "target_priority"] = "secundaria"
    gdf.loc[primary_mask, "target_priority"] = "primaria"

    gdf["is_suitability_cell"] = gdf["target_priority"].isin(
        ["primaria", "secundaria"]
    )

    result = gdf[gdf["is_suitability_cell"]].copy()

    priority_order = {
        "primaria": 1,
        "secundaria": 2,
    }

    result["priority_order"] = result["target_priority"].map(priority_order)
    result = result.sort_values(
        by=["priority_order", "idoneidad_percentil_0_100", "construcciones_percentil_0_100"],
        ascending=[True, True, False]
    ).reset_index(drop=True)

    result["target_rank"] = result.index + 1
    return result


def export_suitability_cells(
    suitability_gdf,
    output_path,
    layer_name="celdas_idoneidad"
):
    """
    Exporta las celdas de idoneidad a archivo.

    Si `output_path` termina en `.gpkg`, se escribe un GeoPackage. Para otros
    formatos soportados por GeoPandas, se usa `to_file` directamente.

    ParÃ¡metros
    ----------
    suitability_gdf : geopandas.GeoDataFrame
        Celdas clasificadas por `classify_suitability_cells`.
    output_path : str | Path
        Ruta de salida.
    layer_name : str
        Nombre de capa dentro del GeoPackage.
    """

    if suitability_gdf is None:
        raise ValueError("suitability_gdf es None.")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if output_path.suffix.lower() == ".gpkg":
        suitability_gdf.to_file(output_path, layer=layer_name, driver="GPKG")
    else:
        suitability_gdf.to_file(output_path)

    return output_path




def resolve_suitability_target_layers(
    selected_layers,
    suitability_target_layer="selected",
    suitability_target_layers=None,
    include_total_suitability=False
):
    """
    Resuelve quÃ© capas deben tener salida de idoneidad.

    Esta funciÃ³n conecta directamente el anÃ¡lisis de idoneidad con la lista
    de capas que llega desde el frontend. Es decir, si desde el frontend llega:

        selected_layers = ["sitios", "bancario", "empresarial", "comercial"]

    y `suitability_target_layer="selected"`, entonces el mÃ³dulo genera una
    clasificaciÃ³n de idoneidad para cada una de esas capas.

    ParÃ¡metros
    ----------
    selected_layers : list[str]
        Capas de puntos seleccionadas desde el frontend. Estas claves
        deben existir en `column_mapping - DEF.json`.
    suitability_target_layer : str
        Control principal de salida. Valores recomendados:

        - "selected" o "front": genera idoneidad para cada capa seleccionada.
        - "all": genera idoneidad para cada capa seleccionada y ademÃ¡s "total".
        - "total": genera solo idoneidad total.
        - "comercial", "sitios", etc.: genera solo esa capa.

    suitability_target_layers : list[str] | None
        Lista explÃ­cita de capas objetivo. Si se define, tiene prioridad sobre
        `suitability_target_layer`.
    include_total_suitability : bool
        Si True, agrega "total" a la lista de capas de salida, ademÃ¡s de las
        capas seleccionadas.

    Retorna
    -------
    list[str]
        Lista de capas objetivo normalizadas y sin duplicados.
    """

    if not selected_layers:
        raise ValueError("selected_layers estÃ¡ vacÃ­o.")

    selected_aliases = [safe_column_name(layer) for layer in selected_layers]

    if suitability_target_layers is not None:
        raw_targets = suitability_target_layers
    else:
        target_key = normalize_key(suitability_target_layer)

        if target_key in ["selected", "front", "frontend", "capas", "layers", "all_selected"]:
            raw_targets = selected_aliases
        elif target_key in ["all", "todas", "selected_plus_total", "all_plus_total"]:
            raw_targets = selected_aliases + ["total"]
        elif target_key in ["total"]:
            raw_targets = ["total"]
        else:
            raw_targets = [target_key]

    targets = []
    seen = set()

    for raw_target in raw_targets:
        target = safe_column_name(raw_target)

        if target in seen:
            continue

        seen.add(target)
        targets.append(target)

    if include_total_suitability and "total" not in seen:
        targets.append("total")

    return targets


def classify_suitability_cells_for_targets(
    density_gdf,
    target_layers,
    primary_ratio_percentile_max=30,
    secondary_ratio_percentile_max=60,
    high_construction_percentile=60,
    keep_low_construction_as_secondary=True,
    min_construction_norm=1e-9,
    verbose=True
):
    """
    Clasifica celdas de idoneidad para varias capas objetivo.

    Esta funciÃ³n evita tener que ejecutar manualmente la clasificaciÃ³n capa
    por capa. Recibe una lista de objetivos, por ejemplo:

        ["sitios", "bancario", "empresarial", "comercial"]

    y aplica `classify_suitability_cells` a cada uno. El resultado combinado
    conserva una columna `target_layer`, por lo que una misma celda puede
    aparecer varias veces si es idÃ³nea para mÃ¡s de una capa.

    ParÃ¡metros
    ----------
    density_gdf : geopandas.GeoDataFrame
        Resultado completo de `run_density_analysis`.
    target_layers : list[str]
        Capas objetivo para generar idoneidad.
    primary_ratio_percentile_max : float
        Percentil mÃ¡ximo del ratio para prioridad primaria.
    secondary_ratio_percentile_max : float
        Percentil mÃ¡ximo del ratio para prioridad secundaria.
    high_construction_percentile : float
        Percentil mÃ­nimo de intensidad construida para que una celda pueda
        quedar como prioridad primaria.
    keep_low_construction_as_secondary : bool
        Si True, las celdas con bajo ratio pero baja intensidad construida
        pasan a prioridad secundaria.
    min_construction_norm : float
        MÃ­nimo de KDE de construcciones normalizado para que el ratio sea
        interpretable.
    verbose : bool
        Si True, imprime conteos por capa.

    Retorna
    -------
    tuple[geopandas.GeoDataFrame, dict]
        - GeoDataFrame combinado con todas las celdas de idoneidad.
        - Diccionario {target_layer: GeoDataFrame} para exportar por capa.
    """

    if density_gdf is None or density_gdf.empty:
        raise ValueError("density_gdf estÃ¡ vacÃ­o o es None.")

    if not target_layers:
        raise ValueError("target_layers estÃ¡ vacÃ­o.")

    suitability_by_layer = {}
    parts = []

    for target_layer in target_layers:
        target_layer = safe_column_name(target_layer)

        if verbose:
            print(f"Clasificando idoneidad para capa evaluada: {target_layer}")

        suitability_gdf = classify_suitability_cells(
            density_gdf=density_gdf,
            target_layer=target_layer,
            primary_ratio_percentile_max=primary_ratio_percentile_max,
            secondary_ratio_percentile_max=secondary_ratio_percentile_max,
            high_construction_percentile=high_construction_percentile,
            keep_low_construction_as_secondary=keep_low_construction_as_secondary,
            min_construction_norm=min_construction_norm
        )

        suitability_by_layer[target_layer] = suitability_gdf

        if suitability_gdf is not None and not suitability_gdf.empty:
            parts.append(suitability_gdf)

        if verbose:
            n_rows = 0 if suitability_gdf is None else len(suitability_gdf)
            print(f"  Celdas seleccionadas {target_layer}: {n_rows:,}")

    if parts:
        combined = pd.concat(parts, ignore_index=True)
        combined = gpd.GeoDataFrame(
            combined,
            geometry="geometry",
            crs=density_gdf.crs
        )
    else:
        combined = gpd.GeoDataFrame(
            columns=list(density_gdf.columns) + [
                "construcciones_percentil_0_100",
                "ratio_percentil_0_100",
                "idoneidad_score_0_100",
                "target_layer",
                "target_ratio_col",
                "target_priority",
                "is_suitability_cell",
                "priority_order",
                "target_rank",
            ],
            geometry=[],
            crs=density_gdf.crs
        )

    return combined, suitability_by_layer


def export_suitability_cells_by_layer(
    suitability_by_layer,
    output_path,
    base_layer_name="celdas_idoneidad"
):
    """
    Exporta varias salidas de idoneidad.

    Si `output_path` termina en `.gpkg`, se escribe un solo GeoPackage con
    una capa por objetivo, por ejemplo:

        celdas_idoneidad_sitios
        celdas_idoneidad_bancario
        celdas_idoneidad_empresarial
        celdas_idoneidad_comercial

    Si `output_path` no es GeoPackage y hay varias capas, se crea una carpeta
    y se guarda un archivo por cada objetivo.

    ParÃ¡metros
    ----------
    suitability_by_layer : dict[str, geopandas.GeoDataFrame]
        Diccionario generado por `classify_suitability_cells_for_targets`.
    output_path : str | Path
        Ruta de salida. Para varias capas se recomienda `.gpkg`.
    base_layer_name : str
        Prefijo del nombre de capa dentro del GeoPackage.

    Retorna
    -------
    Path
        Ruta de salida principal.
    """

    if not suitability_by_layer:
        raise ValueError("suitability_by_layer estÃ¡ vacÃ­o.")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    valid_items = [
        (target_layer, gdf)
        for target_layer, gdf in suitability_by_layer.items()
        if gdf is not None
    ]

    if not valid_items:
        raise ValueError("No hay GeoDataFrames de idoneidad para exportar.")

    if output_path.suffix.lower() == ".gpkg":
        for target_layer, gdf in valid_items:
            layer_name = safe_column_name(f"{base_layer_name}_{target_layer}")
            gdf.to_file(output_path, layer=layer_name, driver="GPKG")
        return output_path

    if len(valid_items) == 1:
        _, gdf = valid_items[0]
        gdf.to_file(output_path)
        return output_path

    output_dir = output_path
    output_dir.mkdir(parents=True, exist_ok=True)

    for target_layer, gdf in valid_items:
        out_file = output_dir / f"{safe_column_name(base_layer_name)}_{target_layer}.gpkg"
        gdf.to_file(out_file, layer=safe_column_name(f"{base_layer_name}_{target_layer}"), driver="GPKG")

    return output_dir

def dataframe_to_geodataframe(df, analysis_crs, output_crs="EPSG:4326"):
    """
    Convierte un DataFrame con geom_wkb a GeoDataFrame.

    La geometrÃ­a viene en analysis_crs y se reproyecta a output_crs.
    """

    if df.empty:
        return gpd.GeoDataFrame(df, geometry=[], crs=output_crs)

    result = df.copy()

    wkb_values = [
        normalize_wkb(value)
        for value in result["geom_wkb"]
    ]

    result["geometry"] = gpd.GeoSeries.from_wkb(
        wkb_values,
        crs=analysis_crs
    )

    result = result.drop(columns=["geom_wkb"])

    gdf = gpd.GeoDataFrame(
        result,
        geometry="geometry",
        crs=analysis_crs
    )

    if output_crs is not None and str(gdf.crs) != str(output_crs):
        gdf = gdf.to_crs(output_crs)

    bounds = gdf.geometry.bounds
    gdf["minx"] = bounds["minx"]
    gdf["miny"] = bounds["miny"]
    gdf["maxx"] = bounds["maxx"]
    gdf["maxy"] = bounds["maxy"]

    return gdf


# ============================================================
# FUNCIÃ“N PRINCIPAL
# ============================================================

def run_density_analysis(
    conn,
    dbname,
    grid_gdf,
    selected_layers,
    mapping_path=DEFAULT_MAPPING_PATH,
    target_srid=4326,
    analysis_srid=None,
    density_mode="hybrid",
    bandwidth_m=300,
    search_radius_m=None,
    kde_max_neighbors=100,
    construction_kde_max_neighbors=None,
    kernel_type="epanechnikov",
    create_indexes=False,
    use_construction_point_column=True,
    construction_point_column="geom_punto",
    fallback_source_srid=4326,
    generate_suitability=False,
    suitability_target_layer="selected",
    suitability_target_layers=None,
    include_total_suitability=False,
    suitability_output_path=None,
    suitability_layer_name="celdas_idoneidad",
    primary_ratio_percentile_max=30,
    secondary_ratio_percentile_max=60,
    high_construction_percentile=60,
    keep_low_construction_as_secondary=True,
    return_suitability=False,
    verbose=True
):
    """
    Ejecuta el anÃ¡lisis optimizado de densidad por celda.

    Flujo principal
    ---------------
    1. Prepara la grilla en CRS mÃ©trico.
    2. Crea tabla temporal de grilla.
    3. Crea bbox temporal expandido.
    4. Crea tabla temporal de construcciones con:
       - punto representativo;
       - Ã¡rea de construcciÃ³n en mÂ².
    5. Crea tabla temporal por capa de puntos.
    6. Calcula conteos, densidades simples y KDE Epanechnikov.
    7. Normaliza KDE por Min-Max.
    8. Calcula ratios KDE capa / KDE construcciones.
    9. Opcionalmente genera y exporta archivo de celdas de idoneidad.

    ParÃ¡metros KDE
    --------------
    kernel_type : str
        Por defecto "epanechnikov". Es la funciÃ³n recomendada para
        caracterizar localmente cada celda.
    bandwidth_m : float
        Ancho de banda del kernel en metros. Para Epanechnikov es el radio
        donde el peso cae a cero.
    search_radius_m : float | None
        Radio de bÃºsqueda. Si es None, se iguala a `bandwidth_m`. Para
        Epanechnikov se recomienda que ambos sean iguales.
    kde_max_neighbors : int | None
        MÃ¡ximo de puntos por celda para capas de entrada.
    construction_kde_max_neighbors : int | None
        MÃ¡ximo de construcciones por celda. Por defecto None para incluir
        toda el Ã¡rea construida dentro del radio.

    PonderaciÃ³n por Ã¡rea de construcciones
    --------------------------------------
    El KDE de construcciones se calcula como:

        SUM(area_m2 * peso_epanechnikov)

    donde `area_m2` se calcula desde el polÃ­gono de construcciÃ³n en el CRS
    mÃ©trico de anÃ¡lisis. Esto convierte el KDE de construcciones en una
    intensidad local de Ã¡rea construida.

    Ãrea de celda
    -------------
    `area_m2` de la celda se usa para densidades simples por kmÂ². No divide
    el KDE porque el KDE se evalÃºa en el centroide y, si las celdas son
    iguales, el Ã¡rea no altera la comparaciÃ³n relativa.

    Celdas de idoneidad
    -------------------
    Si `generate_suitability=True`, se clasifican celdas usando:

        ratio = KDE_capa_norm / KDE_construcciones_norm

    Como el potencial es inversamente proporcional al ratio:

        percentil 0-30  -> prioridad primaria
        percentil 30-60 -> prioridad secundaria

    Por defecto `suitability_target_layer="selected"`, por lo que la salida
    de idoneidad se genera automÃ¡ticamente para cada capa que llega desde
    el frontend en `selected_layers`. Si `selected_layers` es:

        ["sitios", "bancario", "empresarial", "comercial"]

    el GeoPackage de salida tendrÃ¡ una capa por objetivo:

        celdas_idoneidad_sitios
        celdas_idoneidad_bancario
        celdas_idoneidad_empresarial
        celdas_idoneidad_comercial

    Si ademÃ¡s se quiere una capa general, usar
    `include_total_suitability=True` o `suitability_target_layer="all"`.

    Si una celda tiene ratio muy bajo pero no tiene alta intensidad de
    construcciones, por defecto se degrada a prioridad secundaria para no
    confundir zonas poco construidas con oportunidad principal.

    Retorna
    -------
    geopandas.GeoDataFrame | tuple[geopandas.GeoDataFrame, geopandas.GeoDataFrame]
        Por defecto retorna el GeoDataFrame completo de densidad. Si
        `return_suitability=True`, retorna `(density_gdf, suitability_gdf)`.
    """

    t0 = time.perf_counter()

    if not selected_layers:
        raise ValueError("selected_layers estÃ¡ vacÃ­o.")

    density_mode = normalize_key(density_mode)
    kernel_type = normalize_key(kernel_type)

    if density_mode not in ["count", "kde", "hybrid"]:
        raise ValueError("density_mode debe ser 'count', 'kde' o 'hybrid'.")

    if bandwidth_m <= 0:
        raise ValueError("bandwidth_m debe ser mayor que 0.")

    if search_radius_m is None:
        search_radius_m = bandwidth_m

    if search_radius_m <= 0:
        raise ValueError("search_radius_m debe ser mayor que 0.")

    if (
        density_mode == "count"
        and (
            generate_suitability
            or suitability_output_path is not None
            or return_suitability
        )
    ):
        raise ValueError(
            "No se puede generar idoneidad con density_mode='count'. "
            "Use density_mode='kde' o 'hybrid'."
        )

    if analysis_srid is None:
        analysis_srid = estimate_metric_srid(grid_gdf)

    output_crs = f"EPSG:{target_srid}"
    analysis_crs = f"EPSG:{analysis_srid}"

    if verbose:
        print("==============================================")
        print("Iniciando density_analysis optimizado")
        print(f"DB: {dbname}")
        print(f"Capas: {selected_layers}")
        print(f"Modo: {density_mode}")
        print(f"analysis_srid: {analysis_srid}")
        print(f"kernel_type: {kernel_type}")
        print(f"bandwidth_m: {bandwidth_m}")
        print(f"search_radius_m: {search_radius_m}")
        print(f"kde_max_neighbors: {kde_max_neighbors}")
        print(f"construction_kde_max_neighbors: {construction_kde_max_neighbors}")
        print("==============================================")

    db_cfg = get_db_mapping(
        dbname=dbname,
        mapping_path=mapping_path
    )

    admin_cfg = resolve_administrativo_config(db_cfg)

    point_layers = resolve_point_layer_config(
        db_cfg=db_cfg,
        selected_layers=selected_layers
    )

    if create_indexes:
        if verbose:
            print("Creando/verificando Ã­ndices permanentes...")

        ensure_needed_indexes(
            conn=conn,
            admin_cfg=admin_cfg,
            point_layers=point_layers,
            construction_point_column=construction_point_column
        )

    prepared_grid = prepare_grid_gdf(
        grid_gdf=grid_gdf,
        analysis_srid=analysis_srid
    )

    if verbose:
        print(f"Celdas de grilla: {len(prepared_grid):,}")

    temp_tables = []
    temp_grid_table = None
    temp_extent_table = None
    temp_construction_points = None
    temp_layer_tables = {}

    try:
        if verbose:
            print("Creando grilla temporal...")

        temp_grid_table = create_temp_grid_table(
            conn=conn,
            grid_gdf=prepared_grid,
            analysis_srid=analysis_srid
        )
        temp_tables.append(temp_grid_table)

        if verbose:
            print("Creando bbox temporal expandido...")

        temp_extent_table = create_temp_extent_table(
            conn=conn,
            temp_grid_table=temp_grid_table,
            analysis_srid=analysis_srid,
            search_radius_m=search_radius_m
        )
        temp_tables.append(temp_extent_table)

        if verbose:
            print("Creando tabla temporal de construcciones con Ã¡rea ponderante...")

        temp_construction_points = create_temp_construction_point_table_fast(
            conn=conn,
            admin_cfg=admin_cfg,
            temp_extent_table=temp_extent_table,
            analysis_srid=analysis_srid,
            construction_point_column=construction_point_column,
            use_construction_point_column=use_construction_point_column,
            fallback_source_srid=fallback_source_srid
        )
        temp_tables.append(temp_construction_points)

        if verbose:
            print(
                "Construcciones temporales:",
                f"{count_table(conn, temp_construction_points):,}"
            )

        for layer in point_layers:
            alias = layer["alias"]

            if verbose:
                print(f"Creando tabla temporal para capa: {alias}")

            temp_layer_table = create_temp_point_table_fast(
                conn=conn,
                source_schema=layer["schema"],
                source_table=layer["table"],
                source_geom_column=layer["geom_column"],
                temp_extent_table=temp_extent_table,
                analysis_srid=analysis_srid,
                temp_prefix=f"tmp_{alias}",
                fallback_source_srid=fallback_source_srid
            )

            temp_layer_tables[alias] = temp_layer_table
            temp_tables.append(temp_layer_table)

            if verbose:
                print(
                    f"Puntos temporales {alias}:",
                    f"{count_table(conn, temp_layer_table):,}"
                )

        if verbose:
            print("Construyendo query final optimizada...")

        query = build_density_query_hybrid_fast(
            temp_grid_table=temp_grid_table,
            temp_construction_points=temp_construction_points,
            temp_layer_tables=temp_layer_tables,
            point_layers=point_layers,
            density_mode=density_mode,
            bandwidth_m=bandwidth_m,
            search_radius_m=search_radius_m,
            kde_max_neighbors=kde_max_neighbors,
            construction_kde_max_neighbors=construction_kde_max_neighbors,
            kernel_type=kernel_type
        )

        if verbose:
            print("Ejecutando conteos/KDE Epanechnikov...")

        df = fetch_density_dataframe(
            conn=conn,
            query=query
        )

        if verbose:
            print("Calculando mÃ©tricas derivadas...")

        df = build_density_metrics(
            df=df,
            selected_layers=selected_layers,
            density_mode=density_mode
        )

        gdf = dataframe_to_geodataframe(
            df=df,
            analysis_crs=analysis_crs,
            output_crs=output_crs
        )

        gdf["analysis_srid"] = int(analysis_srid)
        gdf["bandwidth_m"] = float(bandwidth_m)
        gdf["search_radius_m"] = float(search_radius_m)
        gdf["density_mode"] = density_mode
        gdf["kernel_type"] = kernel_type

        if kde_max_neighbors is None:
            gdf["kde_max_neighbors"] = -1
        else:
            gdf["kde_max_neighbors"] = int(kde_max_neighbors)

        if construction_kde_max_neighbors is None:
            gdf["construction_kde_max_neighbors"] = -1
        else:
            gdf["construction_kde_max_neighbors"] = int(construction_kde_max_neighbors)

        suitability_gdf = None
        suitability_by_layer = None

        if generate_suitability or suitability_output_path is not None or return_suitability:
            suitability_target_layers_resolved = resolve_suitability_target_layers(
                selected_layers=selected_layers,
                suitability_target_layer=suitability_target_layer,
                suitability_target_layers=suitability_target_layers,
                include_total_suitability=include_total_suitability
            )

            if verbose:
                print("Clasificando celdas de idoneidad...")
                print(f"Capas de idoneidad: {suitability_target_layers_resolved}")

            suitability_gdf, suitability_by_layer = classify_suitability_cells_for_targets(
                density_gdf=gdf,
                target_layers=suitability_target_layers_resolved,
                primary_ratio_percentile_max=primary_ratio_percentile_max,
                secondary_ratio_percentile_max=secondary_ratio_percentile_max,
                high_construction_percentile=high_construction_percentile,
                keep_low_construction_as_secondary=keep_low_construction_as_secondary,
                verbose=verbose
            )

            if suitability_output_path is not None:
                if verbose:
                    print(f"Exportando celdas de idoneidad: {suitability_output_path}")

                export_suitability_cells_by_layer(
                    suitability_by_layer=suitability_by_layer,
                    output_path=suitability_output_path,
                    base_layer_name=suitability_layer_name
                )

        elapsed = time.perf_counter() - t0

        if verbose:
            print(f"Density analysis terminado en {elapsed:.2f} segundos.")

        if return_suitability:
            return gdf, suitability_gdf

        return gdf

    finally:
        try:
            drop_temp_tables(conn, reversed(temp_tables))
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass

# =============================================================================
# EXTENSIÃ“N QGIS: PLANCHAS + MÃSCARA + GRILLA HEXAGONAL + VORONOI
# =============================================================================

def _safe_alias_from_layer_name(name, used=None):
    """Genera un alias de columna Ãºnico a partir del nombre de una capa QGIS."""
    used = used if used is not None else set()
    base = safe_column_name(name or "planchas")
    alias = base
    counter = 2

    while alias in used:
        alias = f"{base}_{counter}"
        counter += 1

    used.add(alias)
    return alias


def qgis_layer_to_geodataframe(layer, target_srid=None, force_points=True, filter_gdf=None, keep_attributes=False):
    """
    Convierte una QgsVectorLayer activa a GeoDataFrame.

    Para el flujo de planchas se recomienda una capa puntual. Si se recibe una
    geometria poligonal o lineal y `force_points=True`, se usa el centroide
    geometrico de cada entidad antes de entrar al analisis KDE.
    """
    _require_runtime_dependencies(require_qgis=True)

    if layer is None or not isinstance(layer, QgsVectorLayer) or not layer.isValid():
        raise ValueError("La capa QGIS de planchas no es vÃ¡lida.")

    if layer.featureCount() == 0:
        raise ValueError(f"La capa '{layer.name()}' no contiene entidades.")

    if not layer.crs().isValid():
        raise ValueError(f"La capa '{layer.name()}' no tiene un CRS vÃ¡lido.")

    request = QgsFeatureRequest() if QgsFeatureRequest is not None else None
    if request is not None and not keep_attributes:
        try:
            request.setNoAttributes()
        except Exception:
            pass
    filter_union = None
    if filter_gdf is not None and not getattr(filter_gdf, "empty", True):
        try:
            filter_metric = filter_gdf.to_crs(layer.crs().authid())
            filter_union = _geometry_union(filter_metric.geometry)
            if filter_union is not None and not filter_union.is_empty and request is not None and QgsRectangle is not None:
                minx, miny, maxx, maxy = filter_union.bounds
                request.setFilterRect(QgsRectangle(float(minx), float(miny), float(maxx), float(maxy)))
        except Exception:
            request = QgsFeatureRequest() if QgsFeatureRequest is not None else None
            if request is not None and not keep_attributes:
                try:
                    request.setNoAttributes()
                except Exception:
                    pass
            filter_union = None

    records = []
    geometries = []
    try:
        from shapely import wkb as shapely_wkb
    except Exception:
        shapely_wkb = None

    features = layer.getFeatures(request) if request is not None else layer.getFeatures()
    for feature in features:
        qgeom = feature.geometry()
        if qgeom is None or qgeom.isEmpty():
            continue

        if force_points and QgsWkbTypes.geometryType(qgeom.wkbType()) != QgsWkbTypes.PointGeometry:
            try:
                qgeom = qgeom.centroid()
            except Exception:
                qgeom = qgeom.pointOnSurface()
            if qgeom is None or qgeom.isEmpty():
                qgeom = feature.geometry().pointOnSurface()

        wkb = bytes(qgeom.asWkb())
        geom = shapely_wkb.loads(wkb) if shapely_wkb is not None else None
        if filter_union is not None:
            try:
                if geom is None:
                    geom = gpd.GeoSeries.from_wkb([wkb], crs=layer.crs().authid()).iloc[0]
                if geom is None or geom.is_empty or not geom.intersects(filter_union):
                    continue
            except Exception:
                pass

        record = {
            "source_fid": int(feature.id()),
            "source_layer": layer.name(),
        }
        if keep_attributes:
            try:
                for field in layer.fields():
                    name = str(field.name())
                    record[name] = feature[name]
            except Exception:
                pass
        records.append(record)
        if geom is None:
            geom = gpd.GeoSeries.from_wkb([wkb], crs=layer.crs().authid()).iloc[0]
        geometries.append(geom)

    if not records:
        raise ValueError(
            f"La capa '{layer.name()}' no contiene geometrÃ­as vÃ¡lidas."
        )

    crs_authid = layer.crs().authid()
    geometry_series = gpd.GeoSeries(geometries, crs=crs_authid)
    result = gpd.GeoDataFrame(records, geometry=geometry_series, crs=crs_authid)

    if target_srid is not None:
        result = result.to_crs(epsg=int(target_srid))

    return result


def _coerce_plate_layers_to_gdfs(plate_layers, analysis_srid, filter_gdf=None):
    """
    Normaliza las entradas de planchas.

    Acepta:
    - una QgsVectorLayer;
    - una lista/tupla de QgsVectorLayer;
    - un GeoDataFrame;
    - un diccionario {nombre: QgsVectorLayer|GeoDataFrame}.
    """
    _require_runtime_dependencies(require_qgis=False)

    if plate_layers is None:
        raise ValueError("plate_layers es None.")

    if isinstance(plate_layers, dict):
        raw_items = list(plate_layers.items())
    elif gpd is not None and isinstance(plate_layers, gpd.GeoDataFrame):
        raw_items = [("planchas", plate_layers)]
    elif QgsVectorLayer is not None and isinstance(plate_layers, QgsVectorLayer):
        raw_items = [(plate_layers.name(), plate_layers)]
    else:
        try:
            raw_list = list(plate_layers)
        except TypeError as exc:
            raise TypeError(
                "plate_layers debe ser una capa QGIS, GeoDataFrame, lista o diccionario."
            ) from exc

        raw_items = []
        for i, item in enumerate(raw_list, start=1):
            if QgsVectorLayer is not None and isinstance(item, QgsVectorLayer):
                raw_items.append((item.name(), item))
            elif gpd is not None and isinstance(item, gpd.GeoDataFrame):
                raw_items.append((f"planchas_{i}", item))
            else:
                raise TypeError(
                    f"Elemento no soportado en plate_layers: {type(item)}"
                )

    used_aliases = set()
    resolved = []

    for raw_name, source in raw_items:
        alias = _safe_alias_from_layer_name(raw_name, used_aliases)

        if QgsVectorLayer is not None and isinstance(source, QgsVectorLayer):
            gdf = qgis_layer_to_geodataframe(
                source,
                target_srid=analysis_srid,
                force_points=True,
                filter_gdf=filter_gdf,
            )
        elif isinstance(source, gpd.GeoDataFrame):
            if source.crs is None:
                raise ValueError(f"GeoDataFrame '{raw_name}' no tiene CRS.")
            gdf = source.copy().to_crs(epsg=int(analysis_srid))
            if not gdf.empty:
                non_points = ~gdf.geometry.geom_type.isin(["Point", "MultiPoint"])
                if non_points.any():
                    gdf.loc[non_points, "geometry"] = (
                        gdf.loc[non_points, "geometry"].centroid
                    )
        else:
            raise TypeError(f"Fuente de planchas no soportada: {type(source)}")

        gdf = gdf[gdf.geometry.notnull() & ~gdf.geometry.is_empty].copy()

        # Convierte MultiPoint en puntos individuales.
        if not gdf.empty and gdf.geometry.geom_type.eq("MultiPoint").any():
            try:
                gdf = gdf.explode(index_parts=False, ignore_index=True)
            except TypeError:
                gdf = gdf.explode().reset_index(drop=True)

        if gdf.empty:
            raise ValueError(f"La capa de planchas '{raw_name}' quedÃ³ vacÃ­a.")

        resolved.append({
            "name": str(raw_name),
            "alias": alias,
            "gdf": gdf,
        })

    return resolved


def _regular_hexagon(center_x, center_y, side_m):
    """Crea un hexÃ¡gono flat-top de lado `side_m`."""
    from shapely.geometry import Polygon

    coords = []
    for i in range(6):
        angle = math.radians(60 * i)
        coords.append((
            center_x + side_m * math.cos(angle),
            center_y + side_m * math.sin(angle),
        ))
    return Polygon(coords)


def create_hexagonal_grid_from_mask(
    mask_gdf,
    hex_size_m=100.0,
    analysis_srid=None,
    selection_mode="intersects",
    clip_to_mask=False,
):
    """
    Genera una grilla hexagonal regular sobre la mÃ¡scara.

    `hex_size_m` se interpreta como la longitud del lado del hexÃ¡gono.

    selection_mode:
    - "intersects": conserva todo hexÃ¡gono que intersecte la mÃ¡scara.
    - "centroid": conserva solo hexÃ¡gonos cuyo centro cae dentro de la mÃ¡scara.

    Para conservar Ã¡reas comparables en el KDE se recomienda
    `clip_to_mask=False`. En ese caso los hexÃ¡gonos de borde mantienen su forma
    completa aunque una parte quede fuera de la mÃ¡scara.
    """
    _require_runtime_dependencies()

    if mask_gdf is None or mask_gdf.empty:
        raise ValueError("mask_gdf estÃ¡ vacÃ­o o es None.")

    if mask_gdf.crs is None:
        raise ValueError("mask_gdf no tiene CRS.")

    if float(hex_size_m) <= 0:
        raise ValueError("hex_size_m debe ser mayor que 0.")

    if analysis_srid is None:
        analysis_srid = estimate_metric_srid(mask_gdf)

    mask_metric = mask_gdf.to_crs(epsg=int(analysis_srid)).copy()
    mask_union = _geometry_union(mask_metric.geometry)

    if mask_union is None or mask_union.is_empty:
        raise ValueError("La geometrÃ­a unificada de la mÃ¡scara estÃ¡ vacÃ­a.")

    minx, miny, maxx, maxy = mask_union.bounds
    side = float(hex_size_m)
    hex_height = math.sqrt(3.0) * side
    x_step = 1.5 * side
    y_step = hex_height

    minx -= 2 * side
    maxx += 2 * side
    miny -= 2 * hex_height
    maxy += 2 * hex_height

    geometries = []
    rows = []

    col = 0
    x = minx
    cell_id = 1

    while x <= maxx:
        y_offset = (hex_height / 2.0) if (col % 2) else 0.0
        y = miny + y_offset

        while y <= maxy:
            polygon = _regular_hexagon(x, y, side)
            center = polygon.centroid

            if selection_mode == "centroid":
                keep = mask_union.covers(center)
            else:
                keep = mask_union.intersects(polygon)

            if keep:
                final_geom = polygon.intersection(mask_union) if clip_to_mask else polygon

                if final_geom is not None and not final_geom.is_empty:
                    rows.append({
                        "cell_id": cell_id,
                        "hex_row": int(round((y - miny) / y_step)),
                        "hex_col": col,
                        "hex_side_m": side,
                    })
                    geometries.append(final_geom)
                    cell_id += 1

            y += y_step

        col += 1
        x += x_step

    if not rows:
        raise RuntimeError("No se generaron hexÃ¡gonos dentro de la mÃ¡scara.")

    return gpd.GeoDataFrame(
        rows,
        geometry=geometries,
        crs=f"EPSG:{int(analysis_srid)}"
    )


def create_temp_point_table_from_gdf(
    conn,
    points_gdf,
    analysis_srid,
    temp_prefix="tmp_planchas"
):
    """
    Sube una capa puntual local/QGIS a una tabla temporal PostGIS.

    Esta funciÃ³n es el cambio central respecto al proyecto anterior: las
    planchas ya no se buscan en tablas PostGIS configuradas; se toman
    de las capas activas del proyecto QGIS y solo se suben temporalmente para
    reutilizar el motor SQL optimizado del KDE.
    """
    _require_runtime_dependencies(require_db=True)

    if points_gdf is None or points_gdf.empty:
        return create_empty_temp_point_table(
            conn=conn,
            analysis_srid=analysis_srid,
            temp_prefix=temp_prefix
        )

    if points_gdf.crs is None:
        raise ValueError("points_gdf no tiene CRS.")

    points = points_gdf.to_crs(epsg=int(analysis_srid)).copy()
    points = points[points.geometry.notnull() & ~points.geometry.is_empty].copy()

    if points.empty:
        return create_empty_temp_point_table(
            conn=conn,
            analysis_srid=analysis_srid,
            temp_prefix=temp_prefix
        )

    temp_points = f"{safe_column_name(temp_prefix)}_{uuid.uuid4().hex[:10]}"

    create_query = sql.SQL("""
        CREATE TEMP TABLE {temp_points} (
            id INTEGER PRIMARY KEY,
            geom geometry(Point, {analysis_srid}),
            area_m2 DOUBLE PRECISION
        );
    """).format(
        temp_points=sql.Identifier(temp_points),
        analysis_srid=sql.Literal(int(analysis_srid)),
    )

    insert_query = sql.SQL("""
        INSERT INTO {temp_points} (id, geom, area_m2)
        VALUES %s;
    """).format(
        temp_points=sql.Identifier(temp_points),
    )

    values = []
    next_id = 1

    for geom in points.geometry:
        if geom is None or geom.is_empty:
            continue

        if geom.geom_type == "MultiPoint":
            sub_geoms = list(geom.geoms)
        elif geom.geom_type == "Point":
            sub_geoms = [geom]
        else:
            sub_geoms = [geom.representative_point()]

        for point in sub_geoms:
            values.append((
                next_id,
                Binary(point.wkb),
                None,
            ))
            next_id += 1

    with conn.cursor() as cur:
        cur.execute(create_query)

        if values:
            execute_values(
                cur,
                insert_query.as_string(conn),
                values,
                template=(
                    f"(%s, ST_Force2D(ST_SetSRID("
                    f"ST_GeomFromWKB(%s), {int(analysis_srid)}"
                    f"))::geometry(Point,{int(analysis_srid)}), %s)"
                ),
            )

        cur.execute(
            sql.SQL("""
                CREATE INDEX {idx_name}
                ON {temp_points}
                USING GIST (geom);
                ANALYZE {temp_points};
            """).format(
                idx_name=sql.Identifier(f"{temp_points}_geom_idx"),
                temp_points=sql.Identifier(temp_points),
            )
        )

    return temp_points


def classify_all_hexagons_suitability(
    density_gdf,
    target_layer="total",
    primary_ratio_percentile_max=30,
    secondary_ratio_percentile_max=60,
    high_construction_percentile=60,
    keep_low_construction_as_secondary=True,
    min_construction_norm=1e-9,
):
    """
    Clasifica TODOS los hexÃ¡gonos, no solo los idÃ³neos.

    Salidas principales:
    - target_priority: primaria | secundaria | no_idonea | sin_contexto
    - suitability_class: idoneo | no_idoneo
    - is_suitable: booleano
    """
    if density_gdf is None or density_gdf.empty:
        raise ValueError("density_gdf estÃ¡ vacÃ­o o es None.")

    gdf = density_gdf.copy()
    target_layer = safe_column_name(target_layer)

    if "kde_construcciones_norm" not in gdf.columns:
        raise KeyError("Falta la columna kde_construcciones_norm.")

    if target_layer == "total":
        ratio_col = "ratio_kde_total_construcciones"
        kde_layer_col = "kde_puntos_total_norm"
        n_layer_col = "n_puntos_total"
    else:
        ratio_col = f"ratio_kde_{target_layer}_construcciones"
        kde_layer_col = f"kde_{target_layer}_norm"
        n_layer_col = f"n_{target_layer}"

    if ratio_col not in gdf.columns:
        if kde_layer_col not in gdf.columns:
            raise KeyError(
                f"No existe {ratio_col} ni {kde_layer_col}. "
                f"Revisa target_layer='{target_layer}'."
            )

        gdf[ratio_col] = np.where(
            gdf["kde_construcciones_norm"] > min_construction_norm,
            gdf[kde_layer_col] / gdf["kde_construcciones_norm"],
            np.nan,
        )

    valid_context = gdf["kde_construcciones_norm"] > min_construction_norm
    gdf.loc[~valid_context, ratio_col] = np.nan

    gdf = add_suitability_percentiles(
        gdf=gdf,
        ratio_col=ratio_col,
        kde_layer_col=kde_layer_col,
        min_construction_norm=min_construction_norm,
    )

    gdf["target_layer"] = target_layer
    gdf["target_ratio_col"] = ratio_col
    gdf["target_priority"] = "no_idonea"

    primary_ratio_mask = (
        valid_context
        & (gdf["idoneidad_percentil_0_100"] <= primary_ratio_percentile_max)
    )

    secondary_ratio_mask = (
        valid_context
        & (gdf["idoneidad_percentil_0_100"] > primary_ratio_percentile_max)
        & (gdf["idoneidad_percentil_0_100"] <= secondary_ratio_percentile_max)
    )

    high_construction_mask = (
        gdf["construcciones_percentil_0_100"] >= high_construction_percentile
    )

    primary_mask = primary_ratio_mask & high_construction_mask
    secondary_mask = secondary_ratio_mask.copy()

    if keep_low_construction_as_secondary:
        secondary_mask = (
            secondary_mask
            | (primary_ratio_mask & ~high_construction_mask)
        )

    gdf.loc[~valid_context, "target_priority"] = "sin_contexto"
    gdf.loc[secondary_mask, "target_priority"] = "secundaria"
    gdf.loc[primary_mask, "target_priority"] = "primaria"

    gdf["is_suitable"] = gdf["target_priority"].isin(
        ["primaria", "secundaria"]
    )
    gdf["suitability_class"] = np.where(
        gdf["is_suitable"],
        "idoneo",
        "no_idoneo",
    )

    if n_layer_col in gdf.columns:
        gdf["target_n_layer"] = gdf[n_layer_col].fillna(0)
    else:
        gdf["target_n_layer"] = np.nan

    return gdf


def _extract_polygon_parts(geometry):
    """Devuelve solo las partes poligonales de una geometrÃ­a Shapely."""
    if geometry is None or geometry.is_empty:
        return []

    if geometry.geom_type == "Polygon":
        return [geometry]

    if geometry.geom_type == "MultiPolygon":
        return list(geometry.geoms)

    if geometry.geom_type == "GeometryCollection":
        parts = []
        for part in geometry.geoms:
            parts.extend(_extract_polygon_parts(part))
        return parts

    return []


def _chaikin_closed_ring(coords, iterations=2):
    """Suaviza un anillo cerrado con corner cutting de Chaikin."""
    if not coords:
        return coords
    ring = list(coords)
    if len(ring) < 4:
        return ring
    if ring[0] == ring[-1]:
        ring = ring[:-1]
    if len(ring) < 3:
        return list(coords)

    for _ in range(max(1, int(iterations))):
        smoothed = []
        n = len(ring)
        for idx in range(n):
            x1, y1 = ring[idx][0], ring[idx][1]
            x2, y2 = ring[(idx + 1) % n][0], ring[(idx + 1) % n][1]
            smoothed.append((0.75 * x1 + 0.25 * x2, 0.75 * y1 + 0.25 * y2))
            smoothed.append((0.25 * x1 + 0.75 * x2, 0.25 * y1 + 0.75 * y2))
        ring = smoothed
    ring.append(ring[0])
    return ring


def _smooth_polygon_geometry(geometry, iterations=2):
    """Aplica suavizado cartografico a poligonos sin modificar atributos."""
    if geometry is None or geometry.is_empty:
        return geometry
    try:
        from shapely.geometry import MultiPolygon, Polygon
    except Exception:
        return geometry

    def _smooth_polygon(poly):
        if poly is None or poly.is_empty or poly.geom_type != "Polygon":
            return poly
        exterior = _chaikin_closed_ring(list(poly.exterior.coords), iterations=iterations)
        interiors = [
            _chaikin_closed_ring(list(interior.coords), iterations=iterations)
            for interior in poly.interiors
            if len(interior.coords) >= 4
        ]
        try:
            smoothed = Polygon(exterior, interiors)
            if not smoothed.is_valid:
                smoothed = smoothed.buffer(0)
            return smoothed if smoothed is not None and not smoothed.is_empty else poly
        except Exception:
            return poly

    try:
        if geometry.geom_type == "Polygon":
            return _smooth_polygon(geometry)
        if geometry.geom_type == "MultiPolygon":
            parts = [_smooth_polygon(part) for part in geometry.geoms]
            parts = [part for part in parts if part is not None and not part.is_empty]
            if not parts:
                return geometry
            return MultiPolygon(parts)
        if geometry.geom_type == "GeometryCollection":
            parts = [_smooth_polygon(part) for part in _extract_polygon_parts(geometry)]
            parts = [part for part in parts if part is not None and not part.is_empty]
            if not parts:
                return geometry
            return MultiPolygon(parts) if len(parts) > 1 else parts[0]
    except Exception:
        return geometry
    return geometry


def smooth_polygonal_geodataframe(gdf, iterations=2, method="chaikin"):
    """Devuelve una copia suavizada para salida cartografica sin dejar huecos."""
    if gdf is None or getattr(gdf, "empty", True):
        return gdf
    if method != "chaikin":
        method = "chaikin"

    original = gdf.copy()
    original = original[original.geometry.notnull() & ~original.geometry.is_empty].copy()
    if original.empty:
        return original

    result = original.copy()
    result["geometry"] = result.geometry.apply(
        lambda geom: _smooth_polygon_geometry(geom, iterations=iterations)
    )
    result = result[result.geometry.notnull() & ~result.geometry.is_empty].copy()
    if result.empty:
        return original

    try:
        original_union = _geometry_union(original.geometry)
        smoothed_union = _geometry_union(result.geometry)
    except Exception:
        original_union = None
        smoothed_union = None

    if (
        original_union is not None
        and not original_union.is_empty
        and smoothed_union is not None
        and not smoothed_union.is_empty
    ):
        repaired_geometries = []
        for idx, row in result.iterrows():
            smoothed = row.geometry
            original_geom = original.loc[idx].geometry if idx in original.index else smoothed
            repaired = smoothed
            try:
                missing_piece = original_geom.difference(smoothed_union)
                if missing_piece is not None and not missing_piece.is_empty:
                    repaired = repaired.union(missing_piece)
                repaired = repaired.intersection(original_union)
                if not repaired.is_valid:
                    repaired = repaired.buffer(0)
            except Exception:
                repaired = smoothed
            repaired_geometries.append(repaired if repaired is not None and not repaired.is_empty else smoothed)
        result["geometry"] = repaired_geometries

    result["geometria_suavizada"] = True
    result["metodo_suavizado"] = method
    result["iteraciones_suavizado"] = int(iterations)
    result["relleno_huecos_suavizado"] = True
    try:
        result = result.set_geometry("geometry")
    except Exception:
        pass
    return result


def create_voronoi_from_hexagons(
    classified_hexagons_gdf,
    mask_gdf,
    source="suitable",
    target_layer=None,
):
    """
    Construye polÃ­gonos de Voronoi usando puntos representativos de hexÃ¡gonos.

    InterpretaciÃ³n geomÃ©trica:
    Un Voronoi clÃ¡sico requiere semillas puntuales. Por ello, se toma la
    geometrÃ­a de cada hexÃ¡gono seleccionado y se obtiene
    `geometry.representative_point()`. Ese punto queda garantizado dentro del
    hexÃ¡gono incluso si el hexÃ¡gono fue recortado en el borde de la mÃ¡scara.

    source:
    - "suitable": primaria + secundaria.
    - "primary": solo prioridad primaria.
    - "all": todos los hexÃ¡gonos clasificados.
    """
    _require_runtime_dependencies()

    if classified_hexagons_gdf is None or classified_hexagons_gdf.empty:
        return gpd.GeoDataFrame(
            columns=["cell_id", "target_layer", "target_priority", "geometry"],
            geometry="geometry",
            crs=getattr(classified_hexagons_gdf, "crs", None),
        )

    selected = classified_hexagons_gdf.copy()

    if target_layer is not None and "target_layer" in selected.columns:
        selected = selected[
            selected["target_layer"] == safe_column_name(target_layer)
        ].copy()

    source_key = normalize_key(source)

    if source_key in ["suitable", "idoneos", "idoneo"]:
        selected = selected[selected["is_suitable"]].copy()
    elif source_key in ["primary", "primaria"]:
        selected = selected[selected["target_priority"] == "primaria"].copy()
    elif source_key in ["all", "todos"]:
        pass
    else:
        raise ValueError("source debe ser 'suitable', 'primary' o 'all'.")

    if selected.empty:
        return gpd.GeoDataFrame(
            columns=list(classified_hexagons_gdf.columns) + ["seed_x", "seed_y"],
            geometry="geometry",
            crs=classified_hexagons_gdf.crs,
        )

    if mask_gdf is None or mask_gdf.empty:
        raise ValueError("mask_gdf estÃ¡ vacÃ­o o es None.")

    selected = selected.to_crs(mask_gdf.crs)
    mask = mask_gdf.to_crs(selected.crs)
    mask_union = _geometry_union(mask.geometry)

    seed_records = []
    seed_points = []

    # Evita semillas duplicadas, que pueden romper algunos motores Voronoi.
    seen_coords = set()

    for _, row in selected.iterrows():
        point = row.geometry.representative_point()
        key = (round(point.x, 9), round(point.y, 9))

        if key in seen_coords:
            continue

        seen_coords.add(key)
        seed_records.append(row.to_dict())
        seed_points.append(point)

    if not seed_points:
        return gpd.GeoDataFrame(
            columns=list(selected.columns),
            geometry="geometry",
            crs=selected.crs,
        )

    if len(seed_points) == 1:
        record = dict(seed_records[0])
        record["geometry"] = mask_union
        record["seed_x"] = seed_points[0].x
        record["seed_y"] = seed_points[0].y
        record["voronoi_id"] = 1

        return gpd.GeoDataFrame(
            [record],
            geometry="geometry",
            crs=selected.crs,
        )

    from shapely.geometry import MultiPoint

    voronoi_geometry = None
    voronoi_error = None

    # Shapely 2.x
    try:
        from shapely import voronoi_polygons

        voronoi_geometry = voronoi_polygons(
            MultiPoint(seed_points),
            extend_to=mask_union.envelope,
        )
    except Exception as exc:
        voronoi_error = exc

    # Shapely 1.8 / 2.x fallback
    if voronoi_geometry is None:
        try:
            from shapely.ops import voronoi_diagram

            voronoi_geometry = voronoi_diagram(
                MultiPoint(seed_points),
                envelope=mask_union.envelope,
                edges=False,
            )
        except Exception as exc:
            voronoi_error = exc

    if voronoi_geometry is None:
        raise RuntimeError(
            "No fue posible construir Voronoi con la versiÃ³n de Shapely "
            f"disponible. Detalle: {voronoi_error}"
        )

    polygons = _extract_polygon_parts(voronoi_geometry)

    # AsignaciÃ³n Voronoi -> semilla. Cada polÃ­gono debe cubrir exactamente
    # una semilla; se usa una bÃºsqueda robusta para evitar depender del orden.
    output_records = []

    for polygon in polygons:
        clipped = polygon.intersection(mask_union)

        for clipped_part in _extract_polygon_parts(clipped):
            if clipped_part.is_empty:
                continue

            seed_index = None

            for i, point in enumerate(seed_points):
                if clipped_part.covers(point):
                    seed_index = i
                    break

            if seed_index is None:
                # Fallback numÃ©rico: asigna la semilla mÃ¡s cercana.
                centroid = clipped_part.representative_point()
                seed_index = min(
                    range(len(seed_points)),
                    key=lambda i: centroid.distance(seed_points[i])
                )

            record = dict(seed_records[seed_index])
            record["geometry"] = clipped_part
            record["seed_x"] = seed_points[seed_index].x
            record["seed_y"] = seed_points[seed_index].y
            output_records.append(record)

    if not output_records:
        return gpd.GeoDataFrame(
            columns=list(selected.columns) + ["seed_x", "seed_y", "voronoi_id"],
            geometry="geometry",
            crs=selected.crs,
        )

    result = gpd.GeoDataFrame(
        output_records,
        geometry="geometry",
        crs=selected.crs,
    )
    result["voronoi_id"] = range(1, len(result) + 1)
    return result


def _resolve_mask_for_plate_analysis(
    conn,
    dbname,
    nivel_1,
    nivel_2,
    mapping_path,
    target_srid,
    mask_gdf=None,
):
    """
    Obtiene la mÃ¡scara directamente o desde `admin_mask.fetch_search_mask`.
    """
    if mask_gdf is not None:
        if mask_gdf.empty:
            raise ValueError("mask_gdf fue suministrado pero estÃ¡ vacÃ­o.")
        return mask_gdf.to_crs(epsg=int(target_srid))

    try:
        from .admin_mask import fetch_search_mask
    except Exception:
        try:
            from admin_mask import fetch_search_mask
        except Exception as exc:
            raise ImportError(
                "No se pudo importar admin_mask.py. ColÃ³calo en la misma "
                "carpeta core/ que density_analysis.py."
            ) from exc

    if conn is None:
        raise ValueError(
            "Se necesita una conexiÃ³n PostGIS para generar la mÃ¡scara."
        )

    if not dbname:
        raise ValueError("dbname es obligatorio para generar la mÃ¡scara.")

    if nivel_1 is None or nivel_2 is None:
        raise ValueError(
            "Para generar la mÃ¡scara desde admin_mask se requieren "
            "nivel_1 y nivel_2. Alternativamente pasa mask_gdf directamente."
        )

    return fetch_search_mask(
        conn=conn,
        dbname=dbname,
        nivel_1=nivel_1,
        nivel_2=nivel_2,
        mapping_path=mapping_path,
        target_srid=target_srid,
    )


def _open_connection_for_plate_analysis(
    conn=None,
    db_manager=None,
    country=None,
    nivel_1=None,
    nivel_2=None,
    dbname=None,
    config_path=None,
):
    """
    Resuelve la conexiÃ³n con tres prioridades:

    1. `conn` recibida directamente.
    2. `db_manager` del complemento QGIS.
    3. `database_resolver.resolve_connection`.
    """
    if conn is not None:
        return conn, dbname, False

    if db_manager is not None:
        if not hasattr(db_manager, "_connect"):
            raise TypeError("db_manager no expone el mÃ©todo _connect().")

        opened = db_manager._connect()
        resolved_dbname = dbname

        if not resolved_dbname:
            cfg = getattr(db_manager, "config", None)
            resolved_dbname = getattr(cfg, "database", None)

        return opened, resolved_dbname, True

    try:
        from .database_resolver import resolve_connection
    except Exception:
        try:
            from database_resolver import resolve_connection
        except Exception as exc:
            raise ImportError(
                "No hay conexiÃ³n directa ni DBManager y no se pudo importar "
                "database_resolver.py."
            ) from exc

    kwargs = {
        "country": country,
        "nivel_1": nivel_1,
        "nivel_2": nivel_2,
    }

    if config_path is not None:
        kwargs["config_path"] = config_path

    opened, resolved_dbname, _run = resolve_connection(**kwargs)
    return opened, resolved_dbname, True


def run_plate_hex_voronoi_analysis(
    plate_layers,
    conn=None,
    db_manager=None,
    country=None,
    nivel_1=None,
    nivel_2=None,
    dbname=None,
    config_path=None,
    mapping_path=DEFAULT_MAPPING_PATH,
    mask_gdf=None,
    construction_context_gdf=None,
    target_srid=4326,
    analysis_srid=None,
    hex_size_m=100.0,
    hex_selection_mode="intersects",
    clip_hexagons_to_mask=False,
    density_mode="hybrid",
    bandwidth_m=300.0,
    search_radius_m=None,
    kde_max_neighbors=100,
    construction_kde_max_neighbors=None,
    kernel_type="epanechnikov",
    create_indexes=False,
    use_construction_point_column=True,
    construction_point_column="geom_punto",
    fallback_source_srid=4326,
    primary_ratio_percentile_max=30,
    secondary_ratio_percentile_max=60,
    high_construction_percentile=60,
    keep_low_construction_as_secondary=True,
    include_total_target=False,
    generate_voronoi=True,
    voronoi_source="suitable",
    verbose=True,
    progress_callback=None,
):
    """
    Ejecuta el flujo completo del complemento.

    Retorna un diccionario con:
        mask
        hex_grid
        density_hexagons
        classified_hexagons
        suitable_hexagons
        voronoi
        by_layer
        parameters
    """
    _require_runtime_dependencies(require_db=True)

    t0 = time.perf_counter()
    step_t0 = t0

    if bandwidth_m <= 0:
        raise ValueError("bandwidth_m debe ser mayor que 0.")

    if search_radius_m is None:
        search_radius_m = bandwidth_m

    if search_radius_m <= 0:
        raise ValueError("search_radius_m debe ser mayor que 0.")

    local_conn, resolved_dbname, owns_connection = _open_connection_for_plate_analysis(
        conn=conn,
        db_manager=db_manager,
        country=country,
        nivel_1=nivel_1,
        nivel_2=nivel_2,
        dbname=dbname,
        config_path=config_path,
    )
    _timed_step(progress_callback, verbose, "conexion PostgreSQL", step_t0)
    step_t0 = time.perf_counter()

    temp_tables = []

    try:
        mask = _resolve_mask_for_plate_analysis(
            conn=local_conn,
            dbname=resolved_dbname,
            nivel_1=nivel_1,
            nivel_2=nivel_2,
            mapping_path=mapping_path,
            target_srid=target_srid,
            mask_gdf=mask_gdf,
        )
        _timed_step(progress_callback, verbose, "mascara administrativa", step_t0)
        step_t0 = time.perf_counter()

        if analysis_srid is None:
            analysis_srid = estimate_metric_srid(mask)

        if verbose:
            print("==============================================")
            print("ANÃLISIS QGIS DE PLANCHAS")
            print(f"Base: {resolved_dbname}")
            print(f"analysis_srid: {analysis_srid}")
            print(f"hex_size_m: {hex_size_m}")
            print(f"bandwidth_m: {bandwidth_m}")
            print(f"search_radius_m: {search_radius_m}")
            print("==============================================")

        hex_grid = create_hexagonal_grid_from_mask(
            mask_gdf=mask,
            hex_size_m=hex_size_m,
            analysis_srid=analysis_srid,
            selection_mode=hex_selection_mode,
            clip_to_mask=clip_hexagons_to_mask,
        )
        _analysis_progress(
            progress_callback,
            verbose,
            f"[perfil] hexagonos generados: {len(hex_grid):,}",
        )
        _timed_step(progress_callback, verbose, "grilla hexagonal", step_t0)
        step_t0 = time.perf_counter()

        plate_inputs = _coerce_plate_layers_to_gdfs(
            plate_layers=plate_layers,
            analysis_srid=analysis_srid,
            filter_gdf=mask_metric,
        )
        for item in plate_inputs:
            _analysis_progress(
                progress_callback,
                verbose,
                f"[perfil] puntos capa activa antes de mascara ({item['alias']}): {len(item['gdf']):,}",
            )

        # Limita las planchas al Ã¡rea de influencia de la mÃ¡scara.
        mask_metric = mask.to_crs(epsg=int(analysis_srid))
        mask_union = _geometry_union(mask_metric.geometry)

        for item in plate_inputs:
            item["gdf"] = item["gdf"][
                item["gdf"].geometry.intersects(mask_union)
            ].copy()
            _analysis_progress(
                progress_callback,
                verbose,
                f"[perfil] puntos capa activa dentro de mascara ({item['alias']}): {len(item['gdf']):,}",
            )

        if all(item["gdf"].empty for item in plate_inputs):
            raise RuntimeError(
                "Ninguna plancha intersecta la mÃ¡scara seleccionada."
            )
        _timed_step(progress_callback, verbose, "preparacion capa activa", step_t0)
        step_t0 = time.perf_counter()

        db_cfg = get_db_mapping(
            dbname=resolved_dbname,
            mapping_path=mapping_path,
        )
        admin_cfg = resolve_administrativo_config(db_cfg)

        if create_indexes:
            # Solo construcciones: las planchas son capas locales, no tablas
            # permanentes de puntos.
            ensure_needed_indexes(
                conn=local_conn,
                admin_cfg=admin_cfg,
                point_layers=[],
                construction_point_column=construction_point_column,
            )

        prepared_grid = prepare_grid_gdf(
            grid_gdf=hex_grid,
            analysis_srid=analysis_srid,
        )

        temp_grid_table = create_temp_grid_table(
            conn=local_conn,
            grid_gdf=prepared_grid,
            analysis_srid=analysis_srid,
        )
        temp_tables.append(temp_grid_table)
        _timed_step(progress_callback, verbose, "tabla temporal de grilla", step_t0)
        step_t0 = time.perf_counter()

        temp_extent_table = create_temp_extent_table(
            conn=local_conn,
            temp_grid_table=temp_grid_table,
            analysis_srid=analysis_srid,
            search_radius_m=search_radius_m,
        )
        temp_tables.append(temp_extent_table)
        _timed_step(progress_callback, verbose, "bbox expandido", step_t0)
        step_t0 = time.perf_counter()

        temp_construction_points = create_temp_construction_point_table_fast(
            conn=local_conn,
            admin_cfg=admin_cfg,
            temp_extent_table=temp_extent_table,
            analysis_srid=analysis_srid,
            construction_point_column=construction_point_column,
            use_construction_point_column=use_construction_point_column,
            fallback_source_srid=fallback_source_srid,
        )
        temp_tables.append(temp_construction_points)
        try:
            n_construction_points = count_table(local_conn, temp_construction_points)
            _analysis_progress(
                progress_callback,
                verbose,
                f"[perfil] construcciones temporales: {n_construction_points:,}",
            )
        except Exception:
            pass
        _timed_step(progress_callback, verbose, "tabla temporal de construcciones", step_t0)
        step_t0 = time.perf_counter()

        temp_layer_tables = {}
        analysis_layers = []
        selected_aliases = []

        for item in plate_inputs:
            alias = item["alias"]
            selected_aliases.append(alias)

            temp_table = create_temp_point_table_from_gdf(
                conn=local_conn,
                points_gdf=item["gdf"],
                analysis_srid=analysis_srid,
                temp_prefix=f"tmp_{alias}",
            )

            temp_layer_tables[alias] = temp_table
            temp_tables.append(temp_table)
            try:
                n_layer_points = count_table(local_conn, temp_table)
                _analysis_progress(
                    progress_callback,
                    verbose,
                    f"[perfil] puntos temporales {alias}: {n_layer_points:,}",
                )
            except Exception:
                pass

            # build_density_query_hybrid_fast solo necesita el alias.
            analysis_layers.append({
                "alias": alias,
                "frontend_key": item["name"],
                "key": alias,
            })
        _timed_step(progress_callback, verbose, "tablas temporales capa activa", step_t0)
        step_t0 = time.perf_counter()

        query = build_density_query_hybrid_fast(
            temp_grid_table=temp_grid_table,
            temp_construction_points=temp_construction_points,
            temp_layer_tables=temp_layer_tables,
            point_layers=analysis_layers,
            density_mode=density_mode,
            bandwidth_m=bandwidth_m,
            search_radius_m=search_radius_m,
            kde_max_neighbors=kde_max_neighbors,
            construction_kde_max_neighbors=construction_kde_max_neighbors,
            kernel_type=kernel_type,
        )
        _timed_step(progress_callback, verbose, "construccion SQL KDE", step_t0)
        step_t0 = time.perf_counter()

        df = fetch_density_dataframe(
            conn=local_conn,
            query=query,
        )
        _analysis_progress(
            progress_callback,
            verbose,
            f"[perfil] filas KDE devueltas: {len(df):,}",
        )
        _timed_step(progress_callback, verbose, "ejecucion SQL KDE", step_t0)
        step_t0 = time.perf_counter()

        df = build_density_metrics(
            df=df,
            selected_layers=selected_aliases,
            density_mode=density_mode,
        )

        density_hexagons = dataframe_to_geodataframe(
            df=df,
            analysis_crs=f"EPSG:{int(analysis_srid)}",
            output_crs=f"EPSG:{int(target_srid)}",
        )

        # Reincorpora metadatos propios de la grilla hexagonal.
        hex_meta = hex_grid[
            ["cell_id", "hex_row", "hex_col", "hex_side_m"]
        ].copy()
        density_hexagons = density_hexagons.merge(
            hex_meta,
            on="cell_id",
            how="left",
        )
        density_hexagons = gpd.GeoDataFrame(
            density_hexagons,
            geometry="geometry",
            crs=f"EPSG:{int(target_srid)}",
        )
        _timed_step(progress_callback, verbose, "metricas y GeoDataFrame", step_t0)
        step_t0 = time.perf_counter()

        target_layers = list(selected_aliases)
        if include_total_target:
            target_layers.append("total")

        by_layer = {}
        classified_parts = []
        suitable_parts = []
        voronoi_parts = []

        for target_layer in target_layers:
            classified = classify_all_hexagons_suitability(
                density_gdf=density_hexagons,
                target_layer=target_layer,
                primary_ratio_percentile_max=primary_ratio_percentile_max,
                secondary_ratio_percentile_max=secondary_ratio_percentile_max,
                high_construction_percentile=high_construction_percentile,
                keep_low_construction_as_secondary=keep_low_construction_as_secondary,
            )

            suitable = classified[classified["is_suitable"]].copy()
            _timed_step(progress_callback, verbose, f"clasificacion {target_layer}", step_t0)
            step_t0 = time.perf_counter()

            if generate_voronoi:
                voronoi = create_voronoi_from_hexagons(
                    classified_hexagons_gdf=classified,
                    mask_gdf=mask.to_crs(classified.crs),
                    source=voronoi_source,
                    target_layer=target_layer,
                )
                _timed_step(progress_callback, verbose, f"voronoi {target_layer}", step_t0)
                step_t0 = time.perf_counter()
            else:
                voronoi = gpd.GeoDataFrame(
                    columns=["geometry"],
                    geometry="geometry",
                    crs=classified.crs,
                )

            by_layer[target_layer] = {
                "classified_hexagons": classified,
                "suitable_hexagons": suitable,
                "voronoi": voronoi,
            }

            classified_parts.append(classified)

            if not suitable.empty:
                suitable_parts.append(suitable)

            if voronoi is not None and not voronoi.empty:
                voronoi_parts.append(voronoi)

        classified_all = gpd.GeoDataFrame(
            pd.concat(classified_parts, ignore_index=True),
            geometry="geometry",
            crs=density_hexagons.crs,
        )

        if suitable_parts:
            suitable_all = gpd.GeoDataFrame(
                pd.concat(suitable_parts, ignore_index=True),
                geometry="geometry",
                crs=density_hexagons.crs,
            )
        else:
            suitable_all = gpd.GeoDataFrame(
                columns=list(classified_all.columns),
                geometry="geometry",
                crs=density_hexagons.crs,
            )

        if voronoi_parts:
            voronoi_all = gpd.GeoDataFrame(
                pd.concat(voronoi_parts, ignore_index=True),
                geometry="geometry",
                crs=density_hexagons.crs,
            )
        else:
            voronoi_all = gpd.GeoDataFrame(
                columns=["geometry"],
                geometry="geometry",
                crs=density_hexagons.crs,
            )

        elapsed = time.perf_counter() - t0

        return {
            "mask": mask,
            "hex_grid": hex_grid.to_crs(epsg=int(target_srid)),
            "density_hexagons": density_hexagons,
            "classified_hexagons": classified_all,
            "suitable_hexagons": suitable_all,
            "voronoi": voronoi_all,
            "by_layer": by_layer,
            "parameters": {
                "dbname": resolved_dbname,
                "analysis_srid": int(analysis_srid),
                "target_srid": int(target_srid),
                "hex_size_m": float(hex_size_m),
                "bandwidth_m": float(bandwidth_m),
                "search_radius_m": float(search_radius_m),
                "kernel_type": kernel_type,
                "density_mode": density_mode,
                "voronoi_source": voronoi_source,
                "elapsed_seconds": elapsed,
            },
        }

    finally:
        try:
            drop_temp_tables(local_conn, reversed(temp_tables))
        except Exception:
            try:
                local_conn.rollback()
            except Exception:
                pass

        if owns_connection and local_conn is not None:
            try:
                local_conn.close()
            except Exception:
                pass


def geodataframe_to_qgis_memory_layer(gdf, layer_name):
    """
    Convierte un GeoDataFrame a una capa temporal QGIS y la agrega al proyecto.

    Se usa para mostrar los resultados del anÃ¡lisis sin obligar a exportarlos.
    """
    _require_runtime_dependencies(require_qgis=True)

    if gdf is None or gdf.empty:
        return None

    if gdf.crs is None:
        raise ValueError(f"El GeoDataFrame '{layer_name}' no tiene CRS.")

    geom_series = gdf.geometry[gdf.geometry.notnull() & ~gdf.geometry.is_empty]

    if geom_series.empty:
        return None

    first_type = geom_series.iloc[0].geom_type

    if first_type in ["Point", "MultiPoint"]:
        geom_name = "MultiPoint" if first_type == "MultiPoint" else "Point"
    elif first_type in ["LineString", "MultiLineString"]:
        geom_name = "MultiLineString" if first_type == "MultiLineString" else "LineString"
    else:
        geom_name = "MultiPolygon" if first_type == "MultiPolygon" else "Polygon"

    try:
        epsg = gdf.crs.to_epsg()
    except Exception:
        epsg = None

    crs_text = f"EPSG:{epsg}" if epsg else str(gdf.crs)

    layer = QgsVectorLayer(
        f"{geom_name}?crs={crs_text}",
        layer_name,
        "memory",
    )
    provider = layer.dataProvider()

    attribute_columns = [
        col for col in gdf.columns
        if col != gdf.geometry.name
    ]

    fields = QgsFields()

    for col in attribute_columns:
        series = gdf[col]

        if pd.api.types.is_bool_dtype(series):
            qtype = QVariant.Bool
        elif pd.api.types.is_integer_dtype(series):
            qtype = QVariant.LongLong
        elif pd.api.types.is_numeric_dtype(series):
            qtype = QVariant.Double
        else:
            qtype = QVariant.String

        fields.append(QgsField(str(col)[:63], qtype))

    provider.addAttributes(fields)
    layer.updateFields()

    features = []
    batch_size = 1000

    for _, row in gdf.iterrows():
        geom = row.geometry

        if geom is None or geom.is_empty:
            continue

        feature = QgsFeature(layer.fields())
        qgeom = QgsGeometry()
        qgeom.fromWkb(bytes(geom.wkb))
        feature.setGeometry(qgeom)

        attrs = []

        for col in attribute_columns:
            value = row[col]

            if pd.isna(value):
                attrs.append(None)
            elif isinstance(value, (np.integer,)):
                attrs.append(int(value))
            elif isinstance(value, (np.floating,)):
                attrs.append(float(value))
            elif isinstance(value, (np.bool_,)):
                attrs.append(bool(value))
            else:
                attrs.append(value)

        feature.setAttributes(attrs)
        features.append(feature)

        if len(features) >= batch_size:
            provider.addFeatures(features)
            features = []

    if features:
        provider.addFeatures(features)
    layer.updateExtents()
    QgsProject.instance().addMapLayer(layer)
    return layer


def _kernel_weight_array(distances, bandwidth_m, kernel_type="epanechnikov"):
    """Calcula pesos kernel para distancias numpy en metros."""
    bandwidth = float(bandwidth_m)
    if bandwidth <= 0:
        raise ValueError("bandwidth_m debe ser mayor que 0.")

    u = np.asarray(distances, dtype="float64") / bandwidth
    inside = u <= 1.0
    kernel_key = normalize_key(kernel_type)
    weights = np.zeros_like(u, dtype="float64")

    if kernel_key in ["epanechnikov", "epanechikov", "epanovich", "epa"]:
        weights[inside] = 1.0 - np.square(u[inside])
    elif kernel_key in ["gaussian", "gaussiano", "normal"]:
        weights[inside] = np.exp(-0.5 * np.square(u[inside]))
    elif kernel_key == "triangular":
        weights[inside] = 1.0 - u[inside]
    elif kernel_key in ["quartic", "biweight"]:
        weights[inside] = np.square(1.0 - np.square(u[inside]))
    else:
        raise ValueError(
            "kernel_type debe ser 'epanechnikov', 'gaussian', 'triangular' o 'quartic'."
        )

    return weights


def _scipy_voronoi_polygons(seed_coords, mask_union):
    """Fallback Voronoi finito usando scipy.spatial.Voronoi."""
    from scipy.spatial import Voronoi
    from shapely.geometry import Polygon

    points = np.asarray(seed_coords, dtype="float64")
    vor = Voronoi(points)

    center = points.mean(axis=0)
    minx, miny, maxx, maxy = mask_union.bounds
    radius = max(maxx - minx, maxy - miny) * 4.0

    all_ridges = {}
    for (p1, p2), (v1, v2) in zip(vor.ridge_points, vor.ridge_vertices):
        all_ridges.setdefault(p1, []).append((p2, v1, v2))
        all_ridges.setdefault(p2, []).append((p1, v1, v2))

    regions = []
    vertices = vor.vertices.tolist()

    for p1, region_index in enumerate(vor.point_region):
        vertices_idx = vor.regions[region_index]

        if vertices_idx and all(v >= 0 for v in vertices_idx):
            regions.append(vertices_idx)
            continue

        new_region = [v for v in vertices_idx if v >= 0]

        for p2, v1, v2 in all_ridges.get(p1, []):
            if v2 < 0:
                v1, v2 = v2, v1
            if v1 >= 0:
                continue

            tangent = points[p2] - points[p1]
            norm = np.linalg.norm(tangent)
            if norm == 0:
                continue
            tangent /= norm
            normal = np.array([-tangent[1], tangent[0]])
            midpoint = points[[p1, p2]].mean(axis=0)
            direction = np.sign(np.dot(midpoint - center, normal)) * normal
            far_point = vor.vertices[v2] + direction * radius
            vertices.append(far_point.tolist())
            new_region.append(len(vertices) - 1)

        if not new_region:
            continue

        region_points = np.asarray([vertices[v] for v in new_region])
        centroid = region_points.mean(axis=0)
        angles = np.arctan2(
            region_points[:, 1] - centroid[1],
            region_points[:, 0] - centroid[0],
        )
        new_region = [v for _, v in sorted(zip(angles, new_region))]
        regions.append(new_region)

    polygons = []
    for region in regions:
        polygon = Polygon([vertices[v] for v in region])
        if polygon.is_valid and not polygon.is_empty:
            polygons.append(polygon)

    return polygons


def create_voronoi_from_points(points_gdf, mask_gdf):
    """
    Crea poligonos Voronoi directamente desde los puntos seleccionados.

    Los poligonos se recortan por la mascara administrativa. Si existen puntos
    duplicados exactos, se usa una sola semilla espacial para evitar que
    Shapely falle con coordenadas repetidas.
    """
    _require_runtime_dependencies()

    if points_gdf is None or points_gdf.empty:
        raise ValueError("points_gdf esta vacio o es None.")
    if mask_gdf is None or mask_gdf.empty:
        raise ValueError("mask_gdf esta vacio o es None.")
    if points_gdf.crs is None:
        raise ValueError("points_gdf no tiene CRS.")
    if mask_gdf.crs is None:
        raise ValueError("mask_gdf no tiene CRS.")

    points = points_gdf.to_crs(mask_gdf.crs).copy()
    mask = mask_gdf.to_crs(points.crs)
    mask_union = _geometry_union(mask.geometry)
    points = points[points.geometry.notnull() & ~points.geometry.is_empty].copy()
    points = points[points.geometry.intersects(mask_union)].copy()

    if points.empty:
        raise ValueError("No hay puntos dentro de la mascara administrativa.")

    seed_records = []
    seed_points = []
    seen_coords = set()

    for _, row in points.iterrows():
        geom = row.geometry
        if geom.geom_type == "MultiPoint":
            geom = list(geom.geoms)[0]
        elif geom.geom_type != "Point":
            geom = geom.representative_point()

        key = (round(geom.x, 9), round(geom.y, 9))
        if key in seen_coords:
            continue

        seen_coords.add(key)
        record = row.to_dict()
        record["seed_x"] = geom.x
        record["seed_y"] = geom.y
        seed_records.append(record)
        seed_points.append(geom)

    if not seed_points:
        raise ValueError("No hay semillas validas para crear Voronoi.")

    if len(seed_points) == 1:
        record = dict(seed_records[0])
        record["geometry"] = mask_union
        record["voronoi_id"] = 1
        return gpd.GeoDataFrame([record], geometry="geometry", crs=points.crs)

    from shapely.geometry import MultiPoint

    seed_coords = [(point.x, point.y) for point in seed_points]

    voronoi_geometry = None
    voronoi_error = None

    try:
        from shapely import voronoi_polygons

        voronoi_geometry = voronoi_polygons(
            MultiPoint(seed_coords),
            extend_to=mask_union.envelope,
        )
    except Exception as exc:
        voronoi_error = exc

    if voronoi_geometry is None:
        try:
            from shapely.ops import voronoi_diagram

            voronoi_geometry = voronoi_diagram(
                MultiPoint(seed_coords),
                envelope=mask_union.envelope,
                edges=False,
            )
        except Exception as exc:
            voronoi_error = exc

    if voronoi_geometry is None:
        try:
            polygons = _scipy_voronoi_polygons(seed_coords, mask_union)
        except Exception as exc:
            raise RuntimeError(
                "No fue posible construir Voronoi desde puntos. "
                f"Detalle Shapely: {voronoi_error}. Detalle SciPy: {exc}"
            ) from exc
    else:
        polygons = _extract_polygon_parts(voronoi_geometry)

    output_records = []

    for polygon in polygons:
        clipped = polygon.intersection(mask_union)

        for clipped_part in _extract_polygon_parts(clipped):
            if clipped_part.is_empty:
                continue

            seed_index = None
            for i, point in enumerate(seed_points):
                if clipped_part.covers(point):
                    seed_index = i
                    break

            if seed_index is None:
                representative = clipped_part.representative_point()
                seed_index = min(
                    range(len(seed_points)),
                    key=lambda i: representative.distance(seed_points[i]),
                )

            record = dict(seed_records[seed_index])
            record["geometry"] = clipped_part
            output_records.append(record)

    if not output_records:
        return gpd.GeoDataFrame(
            columns=list(points.columns) + ["seed_x", "seed_y", "voronoi_id"],
            geometry="geometry",
            crs=points.crs,
        )

    result = gpd.GeoDataFrame(output_records, geometry="geometry", crs=points.crs)
    result["voronoi_id"] = range(1, len(result) + 1)
    return result


def compute_point_kde_at_points(
    points_gdf,
    bandwidth_m,
    search_radius_m=None,
    kernel_type="epanechnikov",
):
    """Calcula KDE de puntos evaluado en cada punto de entrada."""
    _require_runtime_dependencies()

    if points_gdf is None or points_gdf.empty:
        raise ValueError("points_gdf esta vacio o es None.")

    points = points_gdf.copy()
    points = points[points.geometry.notnull() & ~points.geometry.is_empty].copy()

    if points.empty:
        raise ValueError("No hay puntos validos para KDE.")

    search_radius = float(search_radius_m or bandwidth_m)
    if search_radius <= 0:
        raise ValueError("search_radius_m debe ser mayor que 0.")

    point_geoms = points.geometry
    sindex = points.sindex
    kde_values = []
    neighbor_counts = []

    for point_pos, center in enumerate(points.geometry):
        search_geom = center.buffer(search_radius)

        try:
            candidate_idx = list(sindex.query(search_geom, predicate="intersects"))
        except TypeError:
            candidate_idx = list(sindex.intersection(search_geom.bounds))

        # El KDE debe medir concentracion alrededor del punto, no la existencia
        # del punto mismo. Por eso se excluye la semilla evaluada.
        candidate_idx = [int(idx) for idx in candidate_idx if int(idx) != point_pos]

        if not candidate_idx:
            kde_values.append(0.0)
            neighbor_counts.append(0)
            continue

        candidates = point_geoms.iloc[candidate_idx]
        distances = candidates.distance(center).to_numpy(dtype="float64")
        weights = _kernel_weight_array(
            distances=distances,
            bandwidth_m=bandwidth_m,
            kernel_type=kernel_type,
        )
        kde_values.append(float(weights.sum()))
        neighbor_counts.append(int(np.count_nonzero(weights > 0)))

    result = points.copy()
    result["kde_punto_raw"] = kde_values
    result["kde_vecinos_radio"] = neighbor_counts
    result["kde_punto_norm"] = minmax_normalize(pd.Series(kde_values, index=result.index))
    result["kde_punto_pct"] = result["kde_punto_norm"] * 100.0
    return result


def build_kde_sampling_surface(
    points_gdf,
    mask_gdf,
    bandwidth_m,
    search_radius_m=None,
    kernel_type="epanechnikov",
    sample_spacing_m=None,
):
    """Construye una superficie KDE muestreada regularmente dentro de la mascara."""
    _require_runtime_dependencies()

    if points_gdf is None or points_gdf.empty:
        raise ValueError("points_gdf esta vacio o es None.")
    if mask_gdf is None or mask_gdf.empty:
        raise ValueError("mask_gdf esta vacio o es None.")
    if points_gdf.crs is None or mask_gdf.crs is None:
        raise ValueError("points_gdf y mask_gdf deben tener CRS definido.")

    points = points_gdf.to_crs(mask_gdf.crs).copy()
    points = points[points.geometry.notnull() & ~points.geometry.is_empty].copy()
    if points.empty:
        raise ValueError("No hay puntos validos para construir superficie KDE.")

    mask = mask_gdf.to_crs(points.crs)
    mask_union = _geometry_union(mask.geometry)

    search_radius = float(search_radius_m or bandwidth_m)
    if search_radius <= 0:
        raise ValueError("search_radius_m debe ser mayor que 0.")

    if sample_spacing_m is None:
        sample_spacing_m = max(25.0, min(150.0, float(bandwidth_m) / 2.0))
    sample_spacing = float(sample_spacing_m)
    if sample_spacing <= 0:
        raise ValueError("sample_spacing_m debe ser mayor que 0.")

    minx, miny, maxx, maxy = mask_union.bounds
    xs = np.arange(minx, maxx + sample_spacing, sample_spacing)
    ys = np.arange(miny, maxy + sample_spacing, sample_spacing)

    from shapely.geometry import Point

    sample_points = []
    sample_ids = []
    sample_id = 1
    for x in xs:
        for y in ys:
            point = Point(float(x), float(y))
            if mask_union.covers(point):
                sample_points.append(point)
                sample_ids.append(sample_id)
                sample_id += 1

    if not sample_points:
        representative = mask_union.representative_point()
        sample_points = [representative]
        sample_ids = [1]

    samples = gpd.GeoDataFrame(
        {"sample_id": sample_ids},
        geometry=sample_points,
        crs=points.crs,
    )

    point_geoms = points.geometry
    sindex = points.sindex
    kde_values = []
    neighbor_counts = []

    for center in samples.geometry:
        search_geom = center.buffer(search_radius)
        try:
            candidate_idx = list(sindex.query(search_geom, predicate="intersects"))
        except TypeError:
            candidate_idx = list(sindex.intersection(search_geom.bounds))

        if not candidate_idx:
            kde_values.append(0.0)
            neighbor_counts.append(0)
            continue

        candidates = point_geoms.iloc[[int(idx) for idx in candidate_idx]]
        distances = candidates.distance(center).to_numpy(dtype="float64")
        weights = _kernel_weight_array(
            distances=distances,
            bandwidth_m=bandwidth_m,
            kernel_type=kernel_type,
        )
        kde_values.append(float(weights.sum()))
        neighbor_counts.append(int(np.count_nonzero(weights > 0)))

    samples["kde_superficie_raw"] = kde_values
    samples["kde_vecinos_radio"] = neighbor_counts
    samples["kde_superficie_norm"] = minmax_normalize(
        pd.Series(kde_values, index=samples.index)
    )
    samples["kde_superficie_pct"] = samples["kde_superficie_norm"] * 100.0
    samples["sample_spacing_m"] = sample_spacing
    return samples


def fetch_construction_points_for_kde(
    conn,
    dbname,
    mapping_path,
    mask_gdf,
    analysis_srid,
    construction_point_column="geom_punto",
    use_construction_point_column=True,
    fallback_source_srid=4326,
):
    """Obtiene puntos de construcciones dentro de la mascara con peso area_m2."""
    _require_runtime_dependencies(require_db=True)

    if conn is None:
        raise ValueError("conn es requerido para calcular KDE de construcciones.")
    if mask_gdf is None or mask_gdf.empty:
        raise ValueError("mask_gdf esta vacio o es None.")

    db_cfg = get_db_mapping(dbname=dbname, mapping_path=mapping_path)
    admin_cfg = resolve_administrativo_config(db_cfg)
    schema_name = admin_cfg.get("construcciones_schema", admin_cfg["schema"])
    table_name = admin_cfg["construcciones_table"]
    geom_column = admin_cfg["construcciones_geom"]

    if not table_exists(conn, schema_name, table_name):
        raise RuntimeError(f"No existe la tabla {schema_name}.{table_name}.")
    if not column_exists(conn, schema_name, table_name, geom_column):
        raise RuntimeError(
            f"No existe la columna poligonal {geom_column} en {schema_name}.{table_name}."
        )

    use_point_column = (
        use_construction_point_column
        and column_exists(conn, schema_name, table_name, construction_point_column)
        and column_has_non_null(conn, schema_name, table_name, construction_point_column)
    )
    source_geom_column = construction_point_column if use_point_column else geom_column

    if not column_exists(conn, schema_name, table_name, source_geom_column):
        raise RuntimeError(
            f"No existe la columna {source_geom_column} en {schema_name}.{table_name}."
        )

    source_srid = get_geometry_srid(conn, schema_name, table_name, source_geom_column)
    if source_srid is None or source_srid == 0:
        source_srid = fallback_source_srid

    polygon_srid = get_geometry_srid(conn, schema_name, table_name, geom_column)
    if polygon_srid is None or polygon_srid == 0:
        polygon_srid = fallback_source_srid

    mask_metric = mask_gdf.to_crs(epsg=int(analysis_srid))
    mask_union = _geometry_union(mask_metric.geometry)
    if mask_union is None or mask_union.is_empty:
        raise ValueError("La mascara no tiene geometria valida.")

    cache_key = (
        "construction_points_for_kde",
        str(dbname or ""),
        _file_signature(mapping_path),
        str(schema_name),
        str(table_name),
        str(geom_column),
        str(source_geom_column),
        int(analysis_srid),
        _geometry_cache_digest(mask_union),
    )
    cached = _get_construction_cache(cache_key)
    if cached is not None:
        return cached

    base_geom_norm = sql.SQL("""
        CASE
            WHEN ST_SRID(c.{source_geom_column}) = 0
                THEN ST_SetSRID(c.{source_geom_column}, {source_srid})
            ELSE c.{source_geom_column}
        END
    """).format(
        source_geom_column=sql.Identifier(source_geom_column),
        source_srid=sql.Literal(int(source_srid)),
    )

    polygon_geom_norm = sql.SQL("""
        CASE
            WHEN ST_SRID(c.{geom_column}) = 0
                THEN ST_SetSRID(c.{geom_column}, {polygon_srid})
            ELSE c.{geom_column}
        END
    """).format(
        geom_column=sql.Identifier(geom_column),
        polygon_srid=sql.Literal(int(polygon_srid)),
    )

    if use_point_column:
        point_expr_source = base_geom_norm
    else:
        point_expr_source = sql.SQL("ST_PointOnSurface({base_geom})").format(
            base_geom=base_geom_norm
        )

    point_expr_metric = sql.SQL("""
        ST_Force2D(
            ST_Transform(
                {point_expr_source},
                {analysis_srid}
            )
        )
    """).format(
        point_expr_source=point_expr_source,
        analysis_srid=sql.Literal(int(analysis_srid)),
    )

    polygon_expr_metric = sql.SQL("""
        ST_Force2D(
            ST_Transform(
                {polygon_geom_norm},
                {analysis_srid}
            )
        )
    """).format(
        polygon_geom_norm=polygon_geom_norm,
        analysis_srid=sql.Literal(int(analysis_srid)),
    )

    query = sql.SQL("""
        WITH mask AS (
            SELECT ST_SetSRID(ST_GeomFromWKB(%s), {analysis_srid}) AS geom
        )
        SELECT
            ST_AsBinary({point_expr_metric}) AS geom_wkb,
            ST_AsBinary({polygon_expr_metric}) AS construction_geom_wkb,
            GREATEST(ST_Area({polygon_expr_metric}), 0)::double precision AS area_m2
        FROM {schema_name}.{table_name} c
        JOIN mask m
          ON c.{source_geom_column} IS NOT NULL
         AND c.{geom_column} IS NOT NULL
         AND ST_Intersects({polygon_expr_metric}, m.geom)
         AND ST_Intersects({point_expr_metric}, m.geom);
    """).format(
        analysis_srid=sql.Literal(int(analysis_srid)),
        point_expr_metric=point_expr_metric,
        polygon_expr_metric=polygon_expr_metric,
        schema_name=sql.Identifier(schema_name),
        table_name=sql.Identifier(table_name),
        source_geom_column=sql.Identifier(source_geom_column),
        geom_column=sql.Identifier(geom_column),
    )

    with conn.cursor() as cur:
        cur.execute(query, (Binary(mask_union.wkb),))
        rows = cur.fetchall()
        columns = [desc[0] for desc in cur.description]

    df = pd.DataFrame(rows, columns=columns)
    if df.empty:
        empty_result = gpd.GeoDataFrame(
            {"area_m2": []},
            geometry=[],
            crs=f"EPSG:{int(analysis_srid)}",
        )
        _set_construction_cache(cache_key, empty_result)
        return empty_result

    geometries = gpd.GeoSeries.from_wkb(
        [normalize_wkb(value) for value in df["geom_wkb"]],
        crs=f"EPSG:{int(analysis_srid)}",
    )
    construction_geometries = gpd.GeoSeries.from_wkb(
        [normalize_wkb(value) for value in df["construction_geom_wkb"]],
        crs=f"EPSG:{int(analysis_srid)}",
    )
    result = gpd.GeoDataFrame(
        df.drop(columns=["geom_wkb", "construction_geom_wkb"]),
        geometry=geometries,
        crs=f"EPSG:{int(analysis_srid)}",
    )
    result["construction_geometry"] = list(construction_geometries)
    result["area_m2"] = pd.to_numeric(result["area_m2"], errors="coerce").fillna(0.0)
    result = result[result.geometry.notnull() & ~result.geometry.is_empty].copy()
    result = result[result["area_m2"] > 0].copy()
    _set_construction_cache(cache_key, result)
    return result


def qgis_construction_layer_to_kde_points(layer, mask_gdf, analysis_srid):
    """Lee construcciones QGIS por bbox de mascara y genera puntos KDE ponderados."""
    _require_runtime_dependencies(require_qgis=True)

    if layer is None or not isinstance(layer, QgsVectorLayer) or not layer.isValid():
        raise ValueError("La capa QGIS de construcciones no es valida.")
    if mask_gdf is None or getattr(mask_gdf, "empty", True):
        raise ValueError("La mascara esta vacia o no fue suministrada.")
    if getattr(mask_gdf, "crs", None) is None:
        raise ValueError("La mascara debe tener CRS definido.")
    if not layer.crs().isValid():
        raise ValueError(f"La capa '{layer.name()}' no tiene un CRS valido.")

    mask_metric = mask_gdf.to_crs(epsg=int(analysis_srid)).copy()
    mask_union = _geometry_union(mask_metric.geometry)
    if mask_union is None or mask_union.is_empty:
        raise ValueError("La mascara no tiene geometria valida.")

    request = QgsFeatureRequest() if QgsFeatureRequest is not None else None
    if request is not None:
        try:
            request.setNoAttributes()
        except Exception:
            pass
        try:
            mask_layer_crs = mask_gdf.to_crs(layer.crs().authid())
            mask_layer_union = _geometry_union(mask_layer_crs.geometry)
            if mask_layer_union is not None and not mask_layer_union.is_empty and QgsRectangle is not None:
                minx, miny, maxx, maxy = mask_layer_union.bounds
                request.setFilterRect(QgsRectangle(float(minx), float(miny), float(maxx), float(maxy)))
        except Exception:
            pass

    transform = None
    try:
        target_crs = QgsCoordinateReferenceSystem(f"EPSG:{int(analysis_srid)}")
        if layer.crs() != target_crs:
            transform = QgsCoordinateTransform(layer.crs(), target_crs, QgsProject.instance())
    except Exception:
        transform = None

    try:
        from shapely import wkb as shapely_wkb
    except Exception as exc:
        raise RuntimeError(f"No fue posible leer WKB de construcciones locales: {exc}") from exc

    records = []
    point_geometries = []
    features = layer.getFeatures(request) if request is not None else layer.getFeatures()
    for feature in features:
        qgeom = feature.geometry()
        if qgeom is None or qgeom.isEmpty():
            continue
        try:
            qgeom = QgsGeometry(qgeom)
        except Exception:
            pass
        if transform is not None:
            try:
                qgeom.transform(transform)
            except Exception:
                continue

        try:
            geom = shapely_wkb.loads(bytes(qgeom.asWkb()))
        except Exception:
            continue
        if geom is None or geom.is_empty:
            continue
        try:
            if not geom.intersects(mask_union):
                continue
            clipped = geom.intersection(mask_union)
        except Exception:
            continue
        if clipped is None or clipped.is_empty:
            continue
        area_m2 = float(getattr(clipped, "area", 0.0) or 0.0)
        if area_m2 <= 0:
            continue
        try:
            point = clipped.representative_point()
        except Exception:
            point = clipped.centroid
        if point is None or point.is_empty:
            continue
        records.append({
            "source_fid": int(feature.id()),
            "source_layer": layer.name(),
            "area_m2": area_m2,
            "construction_geometry": clipped,
        })
        point_geometries.append(point)

    if not records:
        raise ValueError("Las construcciones locales no intersectan la mascara de analisis.")

    return gpd.GeoDataFrame(
        records,
        geometry=point_geometries,
        crs=f"EPSG:{int(analysis_srid)}",
    )


def construction_context_to_kde_points(context_gdf, mask_gdf, analysis_srid):
    """Convierte una huella urbana local en puntos KDE ponderados por area."""
    _require_runtime_dependencies()

    if QgsVectorLayer is not None and isinstance(context_gdf, QgsVectorLayer):
        return qgis_construction_layer_to_kde_points(
            context_gdf,
            mask_gdf=mask_gdf,
            analysis_srid=analysis_srid,
        )

    if context_gdf is None or getattr(context_gdf, "empty", True):
        raise ValueError("La huella urbana local esta vacia o no fue suministrada.")
    if mask_gdf is None or getattr(mask_gdf, "empty", True):
        raise ValueError("La mascara esta vacia o no fue suministrada.")
    if getattr(context_gdf, "crs", None) is None or getattr(mask_gdf, "crs", None) is None:
        raise ValueError("La huella urbana y la mascara deben tener CRS definido.")

    context = context_gdf.to_crs(epsg=int(analysis_srid)).copy()
    mask = mask_gdf.to_crs(epsg=int(analysis_srid)).copy()
    mask_union = _geometry_union(mask.geometry)
    if mask_union is None or mask_union.is_empty:
        raise ValueError("La mascara no tiene geometria valida.")

    context = _spatial_prefilter_by_geometry(context, mask_union)
    if context is None or context.empty:
        raise ValueError("Las construcciones locales no intersectan la mascara de analisis.")

    def _context_worker(item):
        idx, geom = item
        if geom is None or geom.is_empty:
            return None
        clipped = geom.intersection(mask_union)
        if clipped is None or clipped.is_empty:
            return None
        area_m2 = float(getattr(clipped, "area", 0.0) or 0.0)
        if area_m2 <= 0:
            return None
        point = clipped.representative_point()
        if point is None or point.is_empty:
            return None
        return {
            "record": {
                "source_fid": int(idx),
                "source_layer": "construcciones_locales",
                "area_m2": area_m2,
                "construction_geometry": clipped,
            },
            "geometry": point,
        }

    env_workers = os.environ.get("QGIS_PLATE_ANALYZER_KDE_THREADS", "").strip()
    try:
        max_workers = int(env_workers) if env_workers else min(8, max(1, (os.cpu_count() or 2) - 1))
    except ValueError:
        max_workers = 1
    max_workers = max(1, int(max_workers))

    items = list(context.geometry.items())
    if max_workers > 1 and len(items) > 256:
        chunk_size = max(64, int(math.ceil(len(items) / float(max_workers * 4))))
        chunks = [items[start:start + chunk_size] for start in range(0, len(items), chunk_size)]

        def _chunk_worker(chunk):
            return [_context_worker(item) for item in chunk]

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            chunks_out = list(executor.map(_chunk_worker, chunks))
        output = [row for chunk in chunks_out for row in chunk if row is not None]
    else:
        output = [row for item in items for row in [_context_worker(item)] if row is not None]

    records = [row["record"] for row in output]
    geometries = [row["geometry"] for row in output]

    if not records:
        raise ValueError(
            "La huella urbana local no intersecta la mascara administrativa o no tiene area valida."
        )

    return gpd.GeoDataFrame(records, geometry=geometries, crs=f"EPSG:{int(analysis_srid)}")


def build_kde_cell_surface(
    points_gdf,
    mask_gdf,
    bandwidth_m,
    search_radius_m=None,
    kernel_type="epanechnikov",
    cell_size_m=None,
    construction_points_gdf=None,
    ratio_epsilon=1e-9,
    max_workers=None,
):
    """Construye celdas hexagonales KDE y ratio placas/construcciones sobre la mascara."""
    _require_runtime_dependencies()

    if points_gdf is None or points_gdf.empty:
        raise ValueError("points_gdf esta vacio o es None.")
    if mask_gdf is None or mask_gdf.empty:
        raise ValueError("mask_gdf esta vacio o es None.")
    if points_gdf.crs is None or mask_gdf.crs is None:
        raise ValueError("points_gdf y mask_gdf deben tener CRS definido.")

    points = points_gdf.to_crs(mask_gdf.crs).copy()
    points = points[points.geometry.notnull() & ~points.geometry.is_empty].copy()
    if points.empty:
        raise ValueError("No hay puntos validos para construir celdas KDE.")

    mask = mask_gdf.to_crs(points.crs)
    mask_union = _geometry_union(mask.geometry)

    construction_points = None
    construction_geoms = None
    construction_sindex = None
    construction_effective_geoms = None
    construction_effective_sindex = None
    if construction_points_gdf is not None and not construction_points_gdf.empty:
        construction_source_crs = construction_points_gdf.crs
        construction_points = construction_points_gdf.to_crs(points.crs).copy()
        construction_points = construction_points[
            construction_points.geometry.notnull()
            & ~construction_points.geometry.is_empty
        ].copy()
        if not construction_points.empty:
            if "area_m2" not in construction_points.columns:
                construction_points["area_m2"] = 1.0
            construction_points["area_m2"] = pd.to_numeric(
                construction_points["area_m2"],
                errors="coerce",
            ).fillna(0.0).clip(lower=0.0)
            if "construction_geometry" in construction_points.columns:
                try:
                    construction_effective_geoms = gpd.GeoSeries(
                        construction_points["construction_geometry"],
                        crs=construction_source_crs,
                    ).to_crs(points.crs)
                    construction_points["construction_geometry"] = list(construction_effective_geoms)
                except Exception:
                    construction_effective_geoms = None

    search_radius = float(search_radius_m or bandwidth_m)
    if search_radius <= 0:
        raise ValueError("search_radius_m debe ser mayor que 0.")

    if cell_size_m is None:
        cell_size_m = max(25.0, min(150.0, float(bandwidth_m) / 2.0))
    cell_size = float(cell_size_m)
    if cell_size <= 0:
        raise ValueError("cell_size_m debe ser mayor que 0.")

    if max_workers is None:
        env_workers = os.environ.get("QGIS_PLATE_ANALYZER_KDE_THREADS", "").strip()
        if env_workers:
            try:
                max_workers = int(env_workers)
            except ValueError:
                max_workers = 0
        else:
            max_workers = min(8, max(1, (os.cpu_count() or 2) - 1))
    try:
        max_workers = int(max_workers)
    except (TypeError, ValueError):
        max_workers = 1
    max_workers = max(1, max_workers)

    points = points.reset_index(drop=True)
    point_geoms = points.geometry
    point_x = point_geoms.x.to_numpy(dtype="float64")
    point_y = point_geoms.y.to_numpy(dtype="float64")
    sindex = None
    point_tree = None
    try:
        from scipy.spatial import cKDTree

        point_tree = cKDTree(np.column_stack((point_x, point_y)))
    except Exception:
        sindex = points.sindex
    construction_x = None
    construction_y = None
    construction_area_values = None
    construction_effective_geom_values = None
    construction_tree = None
    if construction_points is not None and not construction_points.empty:
        construction_points = construction_points.reset_index(drop=True)
        construction_geoms = construction_points.geometry
        if "construction_geometry" in construction_points.columns:
            construction_effective_geoms = gpd.GeoSeries(
                construction_points["construction_geometry"],
                crs=points.crs,
            )
            valid_effective = (
                construction_effective_geoms.notnull()
                & ~construction_effective_geoms.is_empty
            )
            if not bool(valid_effective.all()):
                construction_effective_geoms = construction_geoms
        else:
            construction_effective_geoms = construction_geoms
        construction_effective_sindex = construction_effective_geoms.sindex
        construction_effective_geom_values = list(construction_effective_geoms)
        construction_x = construction_geoms.x.to_numpy(dtype="float64")
        construction_y = construction_geoms.y.to_numpy(dtype="float64")
        try:
            if point_tree is not None:
                construction_tree = cKDTree(np.column_stack((construction_x, construction_y)))
            else:
                construction_sindex = construction_points.sindex
        except Exception:
            construction_tree = None
            construction_sindex = construction_points.sindex
        construction_area_values = pd.to_numeric(
            construction_points["area_m2"],
            errors="coerce",
        ).fillna(0.0).clip(lower=0.0).to_numpy(dtype="float64")
    records = []
    plate_kde_values = []
    construction_kde_values = []
    ratio_values = []
    neighbor_counts = []
    construction_neighbor_counts = []
    minx, miny, maxx, maxy = mask_union.bounds
    cell_id = 1
    hex_cells = []

    # `cell_size_m` controla el lado del hexagono. La separacion entre centros
    # se deriva de una malla flat-top para cubrir la mascara sin cuadricula.
    side = cell_size
    hex_height = math.sqrt(3.0) * side
    x_step = 1.5 * side
    y_step = hex_height
    grid_minx = float(minx - (2.0 * side))
    grid_maxx = float(maxx + (2.0 * side))
    grid_miny = float(miny - (2.0 * hex_height))
    grid_maxy = float(maxy + (2.0 * hex_height))
    cell_fragments = {}
    cell_meta = {}
    mask_parts = _extract_polygon_parts(mask_union)
    if not mask_parts:
        mask_parts = [mask_union]

    for mask_part in mask_parts:
        if mask_part is None or mask_part.is_empty:
            continue
        try:
            from shapely.prepared import prep as _prep_part_geometry
            prepared_mask_part = _prep_part_geometry(mask_part)
        except Exception:
            prepared_mask_part = None
        part_minx, part_miny, part_maxx, part_maxy = mask_part.bounds
        col_start = max(0, int(math.floor((float(part_minx) - (2.0 * side) - grid_minx) / x_step)))
        col_end = int(math.ceil((float(part_maxx) + (2.0 * side) - grid_minx) / x_step))
        for col in range(col_start, col_end + 1):
            x = grid_minx + (float(col) * x_step)
            y_offset = (hex_height / 2.0) if (col % 2) else 0.0
            y_base = grid_miny + y_offset
            row_start = max(
                0,
                int(math.floor((float(part_miny) - (2.0 * hex_height) - y_base) / y_step)),
            )
            row_end = int(math.ceil((float(part_maxy) + (2.0 * hex_height) - y_base) / y_step))
            for row in range(row_start, row_end + 1):
                key = (int(row), int(col))
                y = y_base + (float(row) * y_step)
                cell = _regular_hexagon(float(x), float(y), side)
                try:
                    touches_mask = (
                        prepared_mask_part.intersects(cell)
                        if prepared_mask_part is not None
                        else mask_part.intersects(cell)
                    )
                except Exception:
                    touches_mask = True
                if not touches_mask:
                    continue
                clipped = cell.intersection(mask_part)
                if clipped is not None and not clipped.is_empty:
                    cell_fragments.setdefault(key, []).append(clipped)
                    cell_meta[key] = (row, col)

    for key in sorted(cell_fragments.keys()):
        fragments = cell_fragments[key]
        if not fragments:
            continue
        clipped = fragments[0] if len(fragments) == 1 else _geometry_union(fragments)
        if clipped is None or clipped.is_empty:
            continue
        row, col = cell_meta.get(key, key)
        hex_cells.append(
            (
                cell_id,
                row,
                col,
                clipped,
                clipped.representative_point(),
                float(clipped.area),
            )
        )
        cell_id += 1

    validate_hex_coverage = os.environ.get(
        "QGIS_PLATE_ANALYZER_VALIDATE_HEX_COVERAGE",
        "",
    ).strip().lower() in {"1", "true", "yes", "si", "sí"}
    if hex_cells and (validate_hex_coverage or len(hex_cells) <= 20000):
        try:
            covered_union = _geometry_union([item[3] for item in hex_cells])
            missing = (
                mask_union.difference(covered_union)
                if covered_union is not None and not covered_union.is_empty
                else mask_union
            )
            area_tolerance = max(1.0, float(mask_union.area) * 1e-7)
            if missing is not None and not missing.is_empty and float(missing.area) > area_tolerance:
                min_part_area = max(1.0, float(mask_union.area) * 1e-9)
                for missing_part in _extract_polygon_parts(missing):
                    if missing_part is None or missing_part.is_empty:
                        continue
                    if float(missing_part.area) <= min_part_area:
                        continue
                    hex_cells.append(
                        (
                            cell_id,
                            -1,
                            -1,
                            missing_part,
                            missing_part.representative_point(),
                            float(missing_part.area),
                        )
                    )
                    cell_id += 1
        except Exception:
            # Si la verificacion falla, se conserva la malla original para no
            # detener el analisis por una geometria puntual dificil de reparar.
            pass

    if not hex_cells:
        raise ValueError("No se generaron hexagonos KDE dentro de la mascara.")

    try:
        from shapely.prepared import prep as _prep_geometry
    except Exception:
        _prep_geometry = None

    def _query_point_indexes(spatial_index, center, kd_tree=None):
        if kd_tree is not None:
            return kd_tree.query_ball_point(
                [float(center.x), float(center.y)],
                r=search_radius,
            )
        bounds = (
            float(center.x - search_radius),
            float(center.y - search_radius),
            float(center.x + search_radius),
            float(center.y + search_radius),
        )
        try:
            return list(spatial_index.intersection(bounds))
        except Exception:
            return list(spatial_index.query(_regular_hexagon(center.x, center.y, search_radius)))

    def _evaluate_hex_cell(item):
        local_cell_id, local_row, local_col, clipped, center, area_m2 = item
        candidate_idx = _query_point_indexes(sindex, center, point_tree)

        if candidate_idx:
            idx_array = np.asarray([int(idx) for idx in candidate_idx], dtype="int64")
            dx = point_x[idx_array] - float(center.x)
            dy = point_y[idx_array] - float(center.y)
            distances = np.sqrt((dx * dx) + (dy * dy))
            distances = distances[distances <= search_radius]
            weights = _kernel_weight_array(
                distances=distances,
                bandwidth_m=bandwidth_m,
                kernel_type=kernel_type,
            )
            plate_kde_value = float(weights.sum())
            neighbor_count = int(np.count_nonzero(weights > 0))
        else:
            plate_kde_value = 0.0
            neighbor_count = 0

        construction_kde_value = np.nan
        construction_neighbor_count = 0
        construction_effective_count = 0
        construction_effective_area_m2 = 0.0
        construction_effective_area_ratio = 0.0
        if (
            (construction_tree is not None or construction_sindex is not None)
            and construction_x is not None
            and construction_y is not None
            and construction_area_values is not None
        ):
            construction_idx = _query_point_indexes(
                construction_sindex,
                center,
                construction_tree,
            )

            if construction_idx:
                construction_idx_array = np.asarray(
                    [int(idx) for idx in construction_idx],
                    dtype="int64",
                )
                construction_dx = construction_x[construction_idx_array] - float(center.x)
                construction_dy = construction_y[construction_idx_array] - float(center.y)
                construction_distances = np.sqrt(
                    (construction_dx * construction_dx)
                    + (construction_dy * construction_dy)
                )
                valid_radius = construction_distances <= search_radius
                if np.any(valid_radius):
                    construction_distances = construction_distances[valid_radius]
                    construction_weights = _kernel_weight_array(
                        distances=construction_distances,
                        bandwidth_m=bandwidth_m,
                        kernel_type=kernel_type,
                    )
                    construction_areas = construction_area_values[
                        construction_idx_array[valid_radius]
                    ]
                    valid_construction = construction_weights > 0
                    construction_kde_value = float((construction_areas * construction_weights).sum())
                    construction_neighbor_count = int(np.count_nonzero(valid_construction))

            if (
                construction_effective_sindex is not None
                and construction_effective_geom_values is not None
            ):
                try:
                    effective_idx = list(construction_effective_sindex.intersection(clipped.bounds))
                except Exception:
                    effective_idx = list(construction_effective_sindex.query(clipped))
                prepared_cell = _prep_geometry(clipped) if _prep_geometry is not None else None
                effective_indexes = []
                effective_area_parts = []
                for raw_idx in effective_idx:
                    idx = int(raw_idx)
                    try:
                        geom = construction_effective_geom_values[idx]
                    except Exception:
                        continue
                    if geom is None or geom.is_empty:
                        continue
                    try:
                        intersects = bool(prepared_cell.intersects(geom)) if prepared_cell is not None else bool(geom.intersects(clipped))
                    except Exception:
                        intersects = False
                    if intersects:
                        effective_indexes.append(idx)
                        try:
                            if getattr(geom, "area", 0.0) > 0:
                                effective_area_parts.append(float(geom.intersection(clipped).area))
                            else:
                                effective_area_parts.append(float(construction_area_values[idx]))
                        except Exception:
                            try:
                                effective_area_parts.append(float(construction_area_values[idx]))
                            except Exception:
                                effective_area_parts.append(0.0)
                if effective_indexes:
                    construction_effective_count = int(len(effective_indexes))
                    construction_effective_area_m2 = float(np.sum(effective_area_parts))
                    if area_m2 > 0:
                        construction_effective_area_ratio = float(construction_effective_area_m2 / float(area_m2))

        if np.isfinite(construction_kde_value) and construction_kde_value > 0:
            ratio_value = float(plate_kde_value / max(construction_kde_value, float(ratio_epsilon)))
        else:
            ratio_value = np.nan

        return {
            "record": {
                "kde_cell_id": local_cell_id,
                "sample_x": float(center.x),
                "sample_y": float(center.y),
                "kde_vecinos_radio": neighbor_count,
                "kde_construcciones_vecinos_radio": construction_neighbor_count,
                "n_construcciones": construction_effective_count,
                "area_construida_m2": construction_effective_area_m2,
                "pct_area_construida": construction_effective_area_ratio,
                "sample_spacing_m": cell_size,
                "cell_geometry": "hexagon",
                "hex_row": local_row,
                "hex_col": local_col,
                "hex_side_m": side,
                "cell_area_m2": area_m2,
                "geometry": clipped,
                "kde_thread_count": max_workers,
                "kde_neighbor_index": "cKDTree" if point_tree is not None else "spatial_index",
            },
            "plate_kde_value": plate_kde_value,
            "construction_kde_value": construction_kde_value,
            "ratio_value": ratio_value,
            "neighbor_count": neighbor_count,
            "construction_neighbor_count": construction_neighbor_count,
        }

    chunk_size = max(16, int(math.ceil(len(hex_cells) / float(max_workers * 4))))
    chunks = [
        hex_cells[start:start + chunk_size]
        for start in range(0, len(hex_cells), chunk_size)
    ]

    def _evaluate_chunk(chunk):
        return [_evaluate_hex_cell(item) for item in chunk]

    def _evaluated_to_geodataframe(evaluated_items):
        local_records = []
        local_plate_kde_values = []
        local_construction_kde_values = []
        local_ratio_values = []
        local_neighbor_counts = []
        local_construction_neighbor_counts = []

        for evaluated_item in evaluated_items:
            local_records.append(evaluated_item["record"])
            local_plate_kde_values.append(evaluated_item["plate_kde_value"])
            local_construction_kde_values.append(evaluated_item["construction_kde_value"])
            local_ratio_values.append(evaluated_item["ratio_value"])
            local_neighbor_counts.append(evaluated_item["neighbor_count"])
            local_construction_neighbor_counts.append(evaluated_item["construction_neighbor_count"])

        local_cells = gpd.GeoDataFrame(local_records, geometry="geometry", crs=points.crs)
        local_cells["kde_puntos_raw"] = local_plate_kde_values
        local_cells["kde_construcciones_raw"] = local_construction_kde_values
        local_cells["ratio_kde_puntos_construcciones"] = local_ratio_values
        local_cells["kde_superficie_raw"] = local_cells["ratio_kde_puntos_construcciones"]
        local_cells["kde_vecinos_radio"] = local_neighbor_counts
        local_cells["kde_construcciones_vecinos_radio"] = local_construction_neighbor_counts
        return local_cells

    try:
        incremental_threshold = int(os.environ.get("QGIS_PLATE_ANALYZER_INCREMENTAL_HEX_THRESHOLD", "75000"))
    except ValueError:
        incremental_threshold = 75000
    incremental_threshold = max(0, int(incremental_threshold))

    cells = None
    incremental_used = False
    if incremental_threshold and len(hex_cells) > incremental_threshold and len(chunks) > 1:
        chunk_frames = []
        temp_dir = tempfile.TemporaryDirectory(prefix="qgis_plate_kde_chunks_")
        try:
            temp_root = Path(temp_dir.name)
            for chunk_index, chunk in enumerate(chunks, start=1):
                evaluated_chunk = _evaluate_chunk(chunk)
                chunk_gdf = _evaluated_to_geodataframe(evaluated_chunk)
                chunk_gdf["kde_chunk_id"] = int(chunk_index)
                chunk_path = temp_root / f"kde_chunk_{chunk_index:05d}.gpkg"
                try:
                    chunk_gdf.to_file(chunk_path, layer="kde_chunk", driver="GPKG")
                    chunk_frames.append(gpd.read_file(chunk_path, layer="kde_chunk"))
                except Exception:
                    chunk_frames.append(chunk_gdf)
                del evaluated_chunk
                del chunk_gdf

            if chunk_frames:
                cells = gpd.GeoDataFrame(
                    pd.concat(chunk_frames, ignore_index=True),
                    geometry="geometry",
                    crs=points.crs,
                )
                incremental_used = True
        finally:
            try:
                temp_dir.cleanup()
            except Exception:
                pass

    if cells is None:
        if max_workers > 1 and len(chunks) > 1:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                evaluated_chunks = list(executor.map(_evaluate_chunk, chunks))
            evaluated = [item for chunk in evaluated_chunks for item in chunk]
        else:
            evaluated = _evaluate_chunk(hex_cells)
        cells = _evaluated_to_geodataframe(evaluated)

    cells = cells.reset_index(drop=True)
    cells["kde_execution_mode"] = "incremental_gpkg_chunks" if incremental_used else "memory_chunks"
    cells["kde_incremental_threshold"] = int(incremental_threshold)
    kde_puntos_raw = pd.to_numeric(cells["kde_puntos_raw"], errors="coerce")
    kde_construcciones_raw = pd.to_numeric(cells["kde_construcciones_raw"], errors="coerce")
    cells["kde_puntos_norm"] = minmax_normalize(kde_puntos_raw)
    cells["kde_puntos_pct"] = cells["kde_puntos_norm"] * 100.0
    cells["kde_construcciones_norm"] = minmax_normalize(kde_construcciones_raw)
    cells["kde_construcciones_pct"] = cells["kde_construcciones_norm"] * 100.0
    cells["ratio_kde_puntos_construcciones_norm"] = minmax_normalize(
        cells["ratio_kde_puntos_construcciones"]
    )
    cells["ratio_kde_puntos_construcciones_pct"] = (
        cells["ratio_kde_puntos_construcciones_norm"] * 100.0
    )
    cells["kde_superficie_norm"] = cells["ratio_kde_puntos_construcciones_norm"]
    cells["kde_superficie_pct"] = cells["kde_superficie_norm"] * 100.0
    return cells

def classify_kde_priority_frame(frame, value_column="kde_superficie_raw"):
    """Agrega cobertura por relacion KDE puntos/construcciones y contexto construido."""
    if frame is None or frame.empty:
        return frame
    result = frame.copy()
    kde = pd.to_numeric(result[value_column], errors="coerce")

    no_construction_context = pd.Series(False, index=result.index)
    has_effective_construction_fields = (
        "n_construcciones" in result.columns
        or "area_construida_m2" in result.columns
    )
    if has_effective_construction_fields:
        if "n_construcciones" in result.columns:
            n_constructions = pd.to_numeric(result["n_construcciones"], errors="coerce").fillna(0.0)
        else:
            n_constructions = pd.Series(np.nan, index=result.index, dtype="float64")
        if "area_construida_m2" in result.columns:
            construction_area = pd.to_numeric(result["area_construida_m2"], errors="coerce").fillna(0.0)
        else:
            construction_area = pd.Series(np.nan, index=result.index, dtype="float64")
        if "cell_area_m2" in result.columns:
            cell_area = pd.to_numeric(result["cell_area_m2"], errors="coerce").fillna(0.0)
        else:
            try:
                cell_area = result.geometry.area
            except Exception:
                cell_area = pd.Series(0.0, index=result.index, dtype="float64")
        min_effective_area = np.maximum(1.0, cell_area.astype("float64") * 0.0001)
        no_construction_context = (
            n_constructions.fillna(0.0).le(0)
            | construction_area.fillna(0.0).le(min_effective_area)
        )
        result["area_construida_minima_m2"] = min_effective_area
    elif "n_construcciones" in result.columns:
        n_constructions = pd.to_numeric(result["n_construcciones"], errors="coerce").fillna(0.0)
        no_construction_context |= n_constructions <= 0
    elif "kde_construcciones_vecinos_radio" in result.columns:
        construction_neighbors = pd.to_numeric(
            result["kde_construcciones_vecinos_radio"], errors="coerce"
        ).fillna(0.0)
        no_construction_context |= construction_neighbors <= 0
    elif "kde_construcciones_raw" in result.columns:
        construction_kde_raw = pd.to_numeric(
            result["kde_construcciones_raw"], errors="coerce"
        ).fillna(0.0)
        no_construction_context |= construction_kde_raw <= 1e-9
    elif "kde_construcciones_norm" in result.columns:
        construction_kde_norm = pd.to_numeric(
            result["kde_construcciones_norm"], errors="coerce"
        ).fillna(0.0)
        no_construction_context |= construction_kde_norm <= 1e-9

    valid_kde = kde[np.isfinite(kde) & ~no_construction_context]
    if valid_kde.empty:
        kde_median = 0.0
        kde_std = 0.0
        kde_mad = 0.0
        robust_sigma = 0.0
        low_density_threshold = 0.0
        has_spatial_contrast = False
    else:
        kde_median = float(valid_kde.median())
        kde_std = float(valid_kde.std(ddof=0))
        kde_mad = float((valid_kde - kde_median).abs().median())
        robust_sigma = float(1.4826 * kde_mad) if np.isfinite(kde_mad) else 0.0
        if np.isfinite(robust_sigma) and robust_sigma > 0:
            low_density_threshold = max(0.0, kde_median - robust_sigma)
            has_spatial_contrast = True
        else:
            low_density_threshold = max(0.0, kde_median - kde_std)
            has_spatial_contrast = bool(np.isfinite(kde_std) and kde_std > 0)

    low_coverage_mask = (
        has_spatial_contrast
        & kde.notna()
        & ~no_construction_context
        & (kde <= low_density_threshold)
    )
    result["prioridad_sin_placas"] = np.select(
        [
            no_construction_context,
            low_coverage_mask,
        ],
        [
            "sin_construcciones",
            "alta",
        ],
        default="baja",
    )
    result["cobertura"] = np.select(
        [
            no_construction_context,
            low_coverage_mask,
        ],
        [
            "Sin construcciones",
            "No cubierto",
        ],
        default="Cubierto",
    )
    result["umbral_kde_baja_densidad"] = low_density_threshold
    result["umbral_ratio_kde_bajo"] = low_density_threshold
    result["kde_mediana"] = kde_median
    result["ratio_kde_mediana"] = kde_median
    result["kde_desviacion_prioridad"] = kde_std
    result["ratio_kde_desviacion_prioridad"] = kde_std
    result["kde_mad_prioridad"] = kde_mad
    result["ratio_kde_mad_prioridad"] = kde_mad
    result["kde_sigma_robusto_prioridad"] = robust_sigma
    result["ratio_kde_sigma_robusto_prioridad"] = robust_sigma
    result["criterio_prioridad_sin_placas"] = (
        "sin_construcciones_si_no_hay_interseccion_efectiva_con_construcciones; no_cubierto_si_ratio_kde_puntos_construcciones_menor_o_igual_a_mediana_menos_sigma_robusto_mad"
        if has_spatial_contrast
        else "sin_construcciones_si_no_hay_interseccion_efectiva_con_construcciones; cubierto_sin_contraste_espacial_suficiente"
    )
    result["clase_densidad_placas"] = np.select(
        [
            result["kde_superficie_pct"] >= 70.0,
            result["kde_superficie_pct"] >= 40.0,
        ],
        [
            "alta",
            "media",
        ],
        default="baja",
    )
    score = 100.0 - pd.to_numeric(result["kde_superficie_pct"], errors="coerce")
    result["score_sin_placas"] = score
    construction_priority_metric = pd.to_numeric(
        result.get("kde_construcciones_raw", pd.Series(np.nan, index=result.index)),
        errors="coerce",
    )
    categoria_busqueda = _search_category_by_percentile_position(
        construction_priority_metric,
        eligible_mask=low_coverage_mask,
        default_category="Muy bajo",
        low_category="Bajo",
        medium_category="Medio",
        high_category="Alto",
    )
    categoria_busqueda.loc[no_construction_context] = "Nulo"
    result["categoria_busqueda"] = categoria_busqueda
    return result

def _search_category_by_percentile_position(
    score,
    eligible_mask=None,
    default_category="Muy bajo",
    low_category="Bajo",
    medium_category="Medio",
    high_category="Alto",
):
    """Clasifica prioridad por percentil de valores unicos sin separar empates.

    Solo las zonas elegibles compiten por prioridad. El resto queda con la
    categoria por defecto.
    """
    score = pd.to_numeric(score, errors="coerce")
    category = pd.Series(default_category, index=score.index, dtype="object")
    valid = score.notna() & np.isfinite(score)
    if eligible_mask is not None:
        eligible = pd.Series(eligible_mask, index=score.index).fillna(False).astype(bool)
        valid &= eligible
    unique_scores = np.sort(score.loc[valid].drop_duplicates().to_numpy(dtype="float64"))
    unique_count = int(len(unique_scores))
    if unique_count <= 0:
        return category

    if unique_count == 1:
        category.loc[valid] = high_category
        return category

    unique_percentiles = {
        float(value): (float(pos) / float(unique_count - 1)) * 100.0
        for pos, value in enumerate(unique_scores)
    }
    percentiles = score.map(lambda value: unique_percentiles.get(float(value), np.nan))
    category.loc[valid] = low_category
    category.loc[valid & (percentiles > 40.0)] = medium_category
    category.loc[valid & (percentiles > 90.0)] = high_category
    return category

def vectorize_kde_surface_zones(
    kde_surface_gdf,
    mask_gdf,
    sample_spacing_m=None,
    assume_clipped_to_mask=False,
):
    """Discretiza la superficie KDE en poligonos y disuelve por cobertura."""
    _require_runtime_dependencies()

    if kde_surface_gdf is None or kde_surface_gdf.empty:
        raise ValueError("kde_surface_gdf esta vacio o es None.")
    if mask_gdf is None or mask_gdf.empty:
        raise ValueError("mask_gdf esta vacio o es None.")
    if kde_surface_gdf.crs is None or mask_gdf.crs is None:
        raise ValueError("kde_surface_gdf y mask_gdf deben tener CRS definido.")

    surface = kde_surface_gdf.to_crs(mask_gdf.crs).copy()
    mask_union = None
    if not assume_clipped_to_mask:
        mask = mask_gdf.to_crs(surface.crs)
        mask_union = _geometry_union(mask.geometry)

    cell_records = []
    geom_types = set(surface.geometry.geom_type.dropna().astype(str).str.lower())
    if geom_types and geom_types.issubset({"point", "multipoint"}):
        if sample_spacing_m is None:
            if "sample_spacing_m" in surface.columns:
                sample_spacing_m = float(pd.to_numeric(surface["sample_spacing_m"], errors="coerce").dropna().iloc[0])
            else:
                sample_spacing_m = 100.0
        sample_spacing = float(sample_spacing_m)
        half = sample_spacing / 2.0

        from shapely.geometry import box

        for _, row in surface.iterrows():
            point = row.geometry
            if point is None or point.is_empty:
                continue
            cell = box(point.x - half, point.y - half, point.x + half, point.y + half)
            clipped = cell if assume_clipped_to_mask else cell.intersection(mask_union)
            if clipped is None or clipped.is_empty:
                continue
            record = row.to_dict()
            record["geometry"] = clipped
            cell_records.append(record)
    else:
        for _, row in surface.iterrows():
            geom = row.geometry
            if geom is None or geom.is_empty:
                continue
            clipped = geom if assume_clipped_to_mask else geom.intersection(mask_union)
            if clipped is None or clipped.is_empty:
                continue
            record = row.to_dict()
            record["geometry"] = clipped
            cell_records.append(record)

    if not cell_records:
        return gpd.GeoDataFrame(
            columns=[
                "cobertura",
                "kde_superficie_raw",
                "kde_superficie_pct",
                "kde_puntos_raw",
                "kde_construcciones_raw",
                "n_construcciones",
                "area_construida_m2",
                "pct_area_construida",
                "area_construida_minima_m2",
                "ratio_kde_puntos_construcciones",
                "ratio_kde_puntos_construcciones_pct",
                "score_sin_placas",
                "categoria_busqueda",
                "geometry",
            ],
            geometry="geometry",
            crs=surface.crs,
        )

    cells = gpd.GeoDataFrame(cell_records, geometry="geometry", crs=surface.crs)
    cells = classify_kde_priority_frame(cells, value_column="kde_superficie_raw")
    cells["score_sin_placas"] = 100.0 - pd.to_numeric(cells["kde_superficie_pct"], errors="coerce")
    cells["_area_m2"] = cells.geometry.area

    def _weighted_numeric(group, column, area):
        if column not in group.columns:
            return np.nan
        values = pd.to_numeric(group[column], errors="coerce")
        valid = values.notna() & np.isfinite(values)
        if not bool(valid.any()):
            return np.nan
        if area > 0:
            weights = pd.to_numeric(group.loc[valid, "_area_m2"], errors="coerce").fillna(0.0)
            weight_sum = float(weights.sum())
            if weight_sum > 0:
                return float((values.loc[valid] * weights).sum() / weight_sum)
        return float(values.loc[valid].mean())

    def _sum_numeric(group, column):
        if column not in group.columns:
            return np.nan
        values = pd.to_numeric(group[column], errors="coerce")
        valid = values.notna() & np.isfinite(values)
        if not bool(valid.any()):
            return np.nan
        return float(values.loc[valid].sum())

    rows = []
    group_columns = ["cobertura"]
    if "categoria_busqueda" in cells.columns:
        group_columns.append("categoria_busqueda")
    for group_key, group in cells.groupby(group_columns, dropna=False):
        if group.empty:
            continue
        if isinstance(group_key, tuple):
            coverage_value = group_key[0]
            category_value = group_key[1] if len(group_key) > 1 else ""
        else:
            coverage_value = group_key
            category_value = ""
        coverage_text = str(coverage_value) if str(coverage_value).strip() else "Sin clasificar"
        category_text = str(category_value) if str(category_value).strip() else "Muy bajo"
        priority = str(group["prioridad_sin_placas"].iloc[0]) if "prioridad_sin_placas" in group.columns else ""
        area = float(group["_area_m2"].sum())
        weighted_kde = _weighted_numeric(group, "kde_superficie_raw", area)
        weighted_pct = _weighted_numeric(group, "kde_superficie_pct", area)
        weighted_plate_kde = _weighted_numeric(group, "kde_puntos_raw", area)
        weighted_construction_kde = _weighted_numeric(group, "kde_construcciones_raw", area)
        construction_count = _sum_numeric(group, "n_construcciones")
        construction_area = _sum_numeric(group, "area_construida_m2")
        construction_area_ratio = (
            float(construction_area / area)
            if area > 0 and np.isfinite(construction_area)
            else np.nan
        )
        weighted_ratio = _weighted_numeric(group, "ratio_kde_puntos_construcciones", area)
        weighted_ratio_pct = _weighted_numeric(group, "ratio_kde_puntos_construcciones_pct", area)
        score_sin_placas = 100.0 - weighted_pct if np.isfinite(weighted_pct) else np.nan
        rows.append(
            {
                "cobertura": coverage_text,
                "kde_superficie_raw": weighted_kde,
                "kde_superficie_min": float(pd.to_numeric(group["kde_superficie_raw"], errors="coerce").min()),
                "kde_superficie_max": float(pd.to_numeric(group["kde_superficie_raw"], errors="coerce").max()),
                "kde_superficie_pct": weighted_pct,
                "kde_puntos_raw": weighted_plate_kde,
                "kde_construcciones_raw": weighted_construction_kde,
                "n_construcciones": construction_count,
                "area_construida_m2": construction_area,
                "pct_area_construida": construction_area_ratio,
                "area_construida_minima_m2": _weighted_numeric(group, "area_construida_minima_m2", area),
                "ratio_kde_puntos_construcciones": weighted_ratio,
                "ratio_kde_puntos_construcciones_pct": weighted_ratio_pct,
                "score_sin_placas": score_sin_placas,
                "categoria_busqueda": category_text,
                "kde_muestras": int(len(group)),
                "area_m2": area,
                "umbral_kde_baja_densidad": float(group["umbral_kde_baja_densidad"].iloc[0]),
                "umbral_ratio_kde_bajo": float(group["umbral_ratio_kde_bajo"].iloc[0]),
                "kde_mediana": float(group["kde_mediana"].iloc[0]),
                "ratio_kde_mediana": float(group["ratio_kde_mediana"].iloc[0]),
                "kde_desviacion_prioridad": float(group["kde_desviacion_prioridad"].iloc[0]),
                "ratio_kde_desviacion_prioridad": float(group["ratio_kde_desviacion_prioridad"].iloc[0]),
                "kde_mad_prioridad": float(group["kde_mad_prioridad"].iloc[0]) if "kde_mad_prioridad" in group.columns else np.nan,
                "ratio_kde_mad_prioridad": float(group["ratio_kde_mad_prioridad"].iloc[0]) if "ratio_kde_mad_prioridad" in group.columns else np.nan,
                "kde_sigma_robusto_prioridad": float(group["kde_sigma_robusto_prioridad"].iloc[0]) if "kde_sigma_robusto_prioridad" in group.columns else np.nan,
                "ratio_kde_sigma_robusto_prioridad": float(group["ratio_kde_sigma_robusto_prioridad"].iloc[0]) if "ratio_kde_sigma_robusto_prioridad" in group.columns else np.nan,
                "criterio_prioridad_sin_placas": str(group["criterio_prioridad_sin_placas"].iloc[0]),
                "clase_densidad_placas": (
                    "sin_construcciones"
                    if coverage_text.lower() == "sin construcciones"
                    else ("baja" if str(priority).lower() == "alta" else "media_alta")
                ),
                "geometry": _geometry_union(group.geometry),
            }
        )

    result = gpd.GeoDataFrame(rows, geometry="geometry", crs=surface.crs)
    if "categoria_busqueda" not in result.columns:
        result["categoria_busqueda"] = _search_category_by_percentile_position(result["score_sin_placas"])
    coverage_order = {"No cubierto": 0, "Cubierto": 1, "Sin construcciones": 2}
    result["_order"] = result["cobertura"].map(coverage_order).fillna(9)
    result = result.sort_values("_order").drop(columns=["_order"]).reset_index(drop=True)
    result["zona_kde_id"] = range(1, len(result) + 1)
    return result

def assign_surface_kde_to_voronoi(voronoi_gdf, kde_surface_gdf):
    """Resume la superficie KDE dentro de cada poligono Voronoi."""
    _require_runtime_dependencies()

    if voronoi_gdf is None or voronoi_gdf.empty:
        raise ValueError("voronoi_gdf esta vacio o es None.")
    if kde_surface_gdf is None or kde_surface_gdf.empty:
        raise ValueError("kde_surface_gdf esta vacio o es None.")

    voronoi = voronoi_gdf.copy()
    surface = kde_surface_gdf.to_crs(voronoi.crs).copy()
    voronoi["_voronoi_row_id"] = np.arange(len(voronoi))

    joined = gpd.sjoin(
        surface[["kde_superficie_raw", "kde_vecinos_radio", "geometry"]],
        voronoi[["_voronoi_row_id", "geometry"]],
        how="inner",
        predicate="within",
    )

    if joined.empty:
        joined = gpd.sjoin(
            surface[["kde_superficie_raw", "kde_vecinos_radio", "geometry"]],
            voronoi[["_voronoi_row_id", "geometry"]],
            how="inner",
            predicate="intersects",
        )

    summary = joined.groupby("_voronoi_row_id").agg(
        kde_superficie_raw=("kde_superficie_raw", "mean"),
        kde_superficie_max=("kde_superficie_raw", "max"),
        kde_muestras=("kde_superficie_raw", "size"),
        kde_vecinos_radio=("kde_vecinos_radio", "max"),
    )

    result = voronoi.merge(
        summary,
        how="left",
        left_on="_voronoi_row_id",
        right_index=True,
    )

    missing = result["kde_superficie_raw"].isna()
    if missing.any():
        surface_geoms = surface.geometry
        surface_sindex = surface.sindex
        fallback_values = {}
        fallback_neighbors = {}
        for idx, row in result.loc[missing].iterrows():
            representative = row.geometry.representative_point()
            try:
                candidate_idx = list(surface_sindex.nearest(representative, return_all=False))
            except TypeError:
                candidate_idx = list(surface_sindex.nearest(representative.bounds, 1))
            if not candidate_idx:
                continue
            nearest_pos = min(
                [int(pos) for pos in candidate_idx],
                key=lambda pos: representative.distance(surface_geoms.iloc[pos]),
            )
            fallback_values[idx] = float(surface.iloc[nearest_pos]["kde_superficie_raw"])
            fallback_neighbors[idx] = int(surface.iloc[nearest_pos]["kde_vecinos_radio"])

        for idx, value in fallback_values.items():
            result.at[idx, "kde_superficie_raw"] = value
            result.at[idx, "kde_superficie_max"] = value
            result.at[idx, "kde_muestras"] = 1
            result.at[idx, "kde_vecinos_radio"] = fallback_neighbors.get(idx, 0)

    result["kde_superficie_raw"] = result["kde_superficie_raw"].fillna(0.0)
    result["kde_superficie_max"] = result["kde_superficie_max"].fillna(0.0)
    result["kde_muestras"] = result["kde_muestras"].fillna(0).astype(int)
    result["kde_vecinos_radio"] = result["kde_vecinos_radio"].fillna(0).astype(int)
    result["kde_superficie_norm"] = minmax_normalize(result["kde_superficie_raw"])
    result["kde_superficie_pct"] = result["kde_superficie_norm"] * 100.0
    result["score_sin_placas"] = 100.0 - result["kde_superficie_pct"]

    kde = pd.to_numeric(result["kde_superficie_raw"], errors="coerce")
    valid_kde = kde[np.isfinite(kde)]
    if valid_kde.empty:
        kde_median = 0.0
        kde_std = 0.0
        low_density_threshold = 0.0
        has_spatial_contrast = False
    else:
        kde_median = float(valid_kde.median())
        kde_std = float(valid_kde.std(ddof=0))
        low_density_threshold = max(0.0, kde_median - kde_std)
        has_spatial_contrast = bool(np.isfinite(kde_std) and kde_std > 0)

    result["prioridad_sin_placas"] = np.where(
        has_spatial_contrast & kde.notna() & (kde <= low_density_threshold),
        "alta",
        "baja",
    )
    result["umbral_kde_baja_densidad"] = low_density_threshold
    result["umbral_ratio_kde_bajo"] = low_density_threshold
    result["kde_mediana"] = kde_median
    result["ratio_kde_mediana"] = kde_median
    result["kde_desviacion_prioridad"] = kde_std
    result["ratio_kde_desviacion_prioridad"] = kde_std
    result["criterio_prioridad_sin_placas"] = (
        "alta_si_kde_superficie_raw_menor_o_igual_a_mediana_menos_1_desviacion"
        if has_spatial_contrast
        else "baja_sin_contraste_espacial_suficiente"
    )
    result["clase_densidad_placas"] = np.select(
        [
            result["kde_superficie_pct"] >= 70.0,
            result["kde_superficie_pct"] >= 40.0,
        ],
        [
            "alta",
            "media",
        ],
        default="baja",
    )

    result = result.drop(columns=["_voronoi_row_id"], errors="ignore")
    return result


def classify_voronoi_by_kde(voronoi_gdf, value_column="kde_punto_raw"):
    """Clasifica Voronoi usando un campo KDE continuo."""
    _require_runtime_dependencies()

    if voronoi_gdf is None or voronoi_gdf.empty:
        raise ValueError("voronoi_gdf esta vacio o es None.")

    result = voronoi_gdf.copy()
    if value_column not in result.columns:
        raise KeyError(f"Falta la columna {value_column} en voronoi_gdf.")

    kde = pd.to_numeric(result[value_column], errors="coerce")
    mean_value = float(kde.mean()) if len(kde) else 0.0
    std_value = float(kde.std(ddof=0)) if len(kde) else 0.0

    neighbor_count = pd.to_numeric(
        result.get("kde_vecinos_radio", pd.Series(1, index=result.index)),
        errors="coerce",
    ).fillna(0)
    has_neighbors = neighbor_count > 0

    if not np.isfinite(std_value) or std_value <= 0:
        lower = mean_value
        upper = mean_value
        inside = kde.notna() & has_neighbors & (kde > 0)
    else:
        lower = mean_value - std_value
        upper = mean_value + std_value
        inside = kde.between(lower, upper, inclusive="both") & has_neighbors

    result["kde_media"] = mean_value
    result["kde_desviacion_estandar"] = std_value
    result["kde_rango_inferior"] = lower
    result["kde_rango_superior"] = upper
    result["kde_zscore"] = np.where(
        std_value > 0,
        (kde - mean_value) / std_value,
        0.0,
    )
    result["clasificacion_datos"] = np.where(inside, "con datos", "sin datos")
    result["motivo_clasificacion"] = np.select(
        [
            ~has_neighbors,
            kde < lower,
            kde > upper,
            inside,
        ],
        [
            "sin_vecinos_en_radio",
            "fuera_rango_inferior",
            "fuera_rango_superior",
            "dentro_rango_estadistico",
        ],
        default="sin_datos",
    )
    result["criterio_clasificacion"] = "media_mas_menos_1_desviacion_estandar"
    return result


def classify_voronoi_by_point_kde(voronoi_gdf):
    """Clasifica Voronoi usando el KDE calculado en su punto semilla."""
    return classify_voronoi_by_kde(voronoi_gdf, value_column="kde_punto_raw")


def run_point_voronoi_kde_analysis(
    plate_layers,
    conn=None,
    db_manager=None,
    country=None,
    nivel_1=None,
    nivel_2=None,
    dbname=None,
    config_path=None,
    mapping_path=DEFAULT_MAPPING_PATH,
    mask_gdf=None,
    construction_context_gdf=None,
    target_srid=4326,
    analysis_srid=None,
    hex_size_m=100.0,
    bandwidth_m=300.0,
    search_radius_m=None,
    kernel_type="epanechnikov",
    progress_callback=None,
    verbose=True,
):
    """Flujo alternativo: puntos -> superficie KDE -> zonas discretizadas por cobertura."""
    needs_db = mask_gdf is None or construction_context_gdf is None
    _require_runtime_dependencies(require_db=needs_db)

    t0 = time.perf_counter()
    step_t0 = t0

    local_conn = None
    resolved_dbname = dbname
    owns_connection = False
    if needs_db:
        local_conn, resolved_dbname, owns_connection = _open_connection_for_plate_analysis(
            conn=conn,
            db_manager=db_manager,
            country=country,
            nivel_1=nivel_1,
            nivel_2=nivel_2,
            dbname=dbname,
            config_path=config_path,
        )
        _timed_step(progress_callback, verbose, "conexion PostgreSQL", step_t0)
    else:
        _analysis_progress(
            progress_callback,
            verbose,
            "[perfil] flujo manual local: no se requiere conexion PostgreSQL.",
        )
        _timed_step(progress_callback, verbose, "flujo manual sin conexion PostgreSQL", step_t0)
    step_t0 = time.perf_counter()

    try:
        mask = _resolve_mask_for_plate_analysis(
            conn=local_conn,
            dbname=resolved_dbname,
            nivel_1=nivel_1,
            nivel_2=nivel_2,
            mapping_path=mapping_path,
            target_srid=target_srid,
            mask_gdf=mask_gdf,
        )
        _timed_step(progress_callback, verbose, "mascara administrativa", step_t0)
        step_t0 = time.perf_counter()

        if analysis_srid is None:
            analysis_srid = estimate_metric_srid(mask)

        mask_metric = mask.to_crs(epsg=int(analysis_srid))
        mask_union = _geometry_union(mask_metric.geometry)

        plate_inputs = _coerce_plate_layers_to_gdfs(
            plate_layers=plate_layers,
            analysis_srid=analysis_srid,
        )

        point_parts = []
        for item in plate_inputs:
            points = item["gdf"].copy()
            points = _spatial_prefilter_by_geometry(points, mask_union)
            points["target_layer"] = item["alias"]
            points["source_layer"] = item["name"]
            point_parts.append(points)
            _analysis_progress(
                progress_callback,
                verbose,
                f"[perfil] puntos dentro de mascara ({item['alias']}): {len(points):,}",
            )

        points_all = gpd.GeoDataFrame(
            pd.concat(point_parts, ignore_index=True),
            geometry="geometry",
            crs=f"EPSG:{int(analysis_srid)}",
        )

        if points_all.empty:
            raise RuntimeError("Ningun punto intersecta la mascara seleccionada.")

        if construction_context_gdf is not None:
            construction_points = construction_context_to_kde_points(
                context_gdf=construction_context_gdf,
                mask_gdf=mask_metric,
                analysis_srid=analysis_srid,
            )
            construction_source = "construcciones locales"
        else:
            construction_points = fetch_construction_points_for_kde(
                conn=local_conn,
                dbname=resolved_dbname,
                mapping_path=mapping_path,
                mask_gdf=mask_metric,
                analysis_srid=analysis_srid,
            )
            construction_source = "PostGIS"
        _analysis_progress(
            progress_callback,
            verbose,
            f"[perfil] construcciones dentro de mascara ({construction_source}): {len(construction_points):,}",
        )
        _timed_step(progress_callback, verbose, "construcciones ponderadas por area", step_t0)
        step_t0 = time.perf_counter()

        kde_surface = build_kde_cell_surface(
            points_gdf=points_all,
            mask_gdf=mask_metric,
            bandwidth_m=bandwidth_m,
            search_radius_m=search_radius_m,
            kernel_type=kernel_type,
            cell_size_m=hex_size_m,
            construction_points_gdf=construction_points,
        )
        kde_surface = classify_kde_priority_frame(
            kde_surface,
            value_column="kde_superficie_raw",
        )
        _timed_step(progress_callback, verbose, "superficie ratio kde placas/construcciones", step_t0)
        step_t0 = time.perf_counter()

        density_zones = vectorize_kde_surface_zones(
            kde_surface_gdf=kde_surface,
            mask_gdf=mask_metric,
            assume_clipped_to_mask=True,
        )
        _timed_step(progress_callback, verbose, "vectorizacion kde por prioridad", step_t0)
        step_t0 = time.perf_counter()

        smoothing_iterations = 2
        try:
            smooth_max_features = int(os.environ.get("QGIS_PLATE_ANALYZER_SMOOTH_MAX_FEATURES", "50000"))
        except ValueError:
            smooth_max_features = 50000
        smooth_max_features = max(0, int(smooth_max_features))

        if smooth_max_features and len(kde_surface) > smooth_max_features:
            kde_surface_output = kde_surface.copy()
            kde_surface_output["geometria_suavizada"] = False
            kde_surface_output["metodo_suavizado"] = "omitido_por_volumen"
            kde_surface_output["iteraciones_suavizado"] = 0
            kde_surface_output["relleno_huecos_suavizado"] = False
            _analysis_progress(
                progress_callback,
                verbose,
                f"[perfil] suavizado capa 04 omitido por volumen: {len(kde_surface):,} hexagonos.",
            )
        else:
            kde_surface_output = smooth_polygonal_geodataframe(
                kde_surface,
                iterations=smoothing_iterations,
            )

        density_zones_output = smooth_polygonal_geodataframe(
            density_zones,
            iterations=smoothing_iterations,
        )
        _timed_step(progress_callback, verbose, "suavizado cartografico de capas 04 y 05", step_t0)

        elapsed = time.perf_counter() - t0

        return {
            "mask": mask,
            "points": points_all.to_crs(epsg=int(target_srid)),
            "kde_surface": kde_surface_output.to_crs(epsg=int(target_srid)),
            "density_zones": density_zones_output.to_crs(epsg=int(target_srid)),
            "parameters": {
                "dbname": resolved_dbname,
                "analysis_srid": int(analysis_srid),
                "target_srid": int(target_srid),
                "bandwidth_m": float(bandwidth_m),
                "search_radius_m": float(search_radius_m or bandwidth_m),
                "kernel_type": kernel_type,
                "kde_assignment": "discretizacion_de_ratio_kde_puntos_sobre_kde_construcciones",
                "classification": "umbral_robusto_ratio_bajo_mediana_menos_sigma_mad",
                "construction_kde": "ponderado_por_area_m2",
                "construction_source": construction_source,
                "geometry_smoothing": "chaikin",
                "geometry_smoothing_iterations": int(smoothing_iterations),
                "geometry_smoothing_max_features": int(smooth_max_features),
                "kde_surface_smoothing_applied": bool(
                    not smooth_max_features or len(kde_surface) <= smooth_max_features
                ),
                "elapsed_seconds": elapsed,
            },
        }

    finally:
        if owns_connection and local_conn is not None:
            try:
                local_conn.close()
            except Exception:
                pass


class DensityAnalysis:
    """
    Adaptador para usar el flujo desde la interfaz actual del complemento.

    La UI puede mantener el patrÃ³n:

        analysis = DensityAnalysis(
            feedback=...,
            db_manager=self.db
        )

        ok, msg, result = analysis.run(
            layer,
            method="kde",
            radius=300,
            pixel_size=100,
            nivel_1="Huila",
            nivel_2="Neiva",
            mapping_path="..."
        )

    En esta adaptaciÃ³n:
    - `layer`       = capa activa de planchas.
    - `radius`      = bandwidth KDE en metros.
    - `pixel_size`  = lado del hexagono en metros para la superficie KDE.
    """

    def __init__(self, feedback=None, db_manager=None):
        self.feedback = feedback
        self.db_manager = db_manager

    def _log(self, message):
        if self.feedback:
            try:
                self.feedback(str(message))
            except Exception:
                pass

    def run(
        self,
        layer,
        method="kde",
        radius=300.0,
        pixel_size=100.0,
        weight_field="",
        **kwargs,
    ):
        del weight_field  # Las planchas usan peso unitario en este flujo.

        try:
            method_key = normalize_key(method)

            if method_key not in [
                "kde",
                "hybrid",
                "hibrido",
                "epanechnikov",
                "analisis",
            ]:
                return (
                    False,
                    "Este flujo esta disenado para KDE/hibrido de planchas "
                    "sobre zonas discretizadas de densidad.",
                    None,
                )

            self._log("1/6 Resolviendo conexion y mascara administrativa...")

            result = run_point_voronoi_kde_analysis(
                plate_layers=[layer],
                db_manager=self.db_manager,
                bandwidth_m=float(radius),
                hex_size_m=float(pixel_size),
                kernel_type=kwargs.pop("kernel_type", "epanechnikov"),
                progress_callback=self._log,
                **kwargs,
            )

            self._log("2/6 Superficie KDE de placas calculada.")
            self._log("3/6 Hexagonos de huella urbana clasificados.")
            self._log("4/6 Capa hexagonal sin disolver preparada.")
            self._log("5/6 Zonas finales disueltas por cobertura.")

            qgis_outputs = {}

            for key, layer_name in [
                ("kde_surface", "04_hexagonos_cobertura_sin_disolver"),
                ("density_zones", "05_zonas_cobertura_disuelta"),
            ]:
                gdf = result.get(key)

                if gdf is not None and not gdf.empty:
                    self._log(f"6/6 Agregando capa QGIS: {layer_name}")
                    qgis_outputs[key] = geodataframe_to_qgis_memory_layer(
                        gdf,
                        layer_name,
                    )

            result["qgis_layers"] = qgis_outputs
            self._log("Analisis terminado correctamente.")

            n_points = len(result["points"])
            n_samples = len(result.get("kde_surface", []))
            zones = result["density_zones"]
            n_zones = len(zones)
            n_no_cubierto = int((zones["cobertura"] == "No cubierto").sum()) if "cobertura" in zones.columns else 0
            n_cubierto = int((zones["cobertura"] == "Cubierto").sum()) if "cobertura" in zones.columns else 0
            n_sin_construcciones = int((zones["cobertura"] == "Sin construcciones").sum()) if "cobertura" in zones.columns else 0

            message = (
                f"Analisis terminado: {n_zones:,} zonas KDE discretizadas, "
                f"{n_points:,} puntos de placas, {n_samples:,} muestras KDE, "
                f"{n_no_cubierto:,} no cubiertas, {n_cubierto:,} cubiertas "
                f"y {n_sin_construcciones:,} sin construcciones."
            )

            return True, message, result

        except Exception as exc:
            import traceback

            self._log(f"Error: {exc}")
            self._log(traceback.format_exc())
            return False, str(exc), None

