const state = {
  activeTab: 1,
  connected: false,
  connecting: false,
  systemStatus: 'Disconnected',
  progress: 0,
  showResults: false,
  showHeatmap: false,
  maskEnabled: true,
  memory: 41.8,
  db: { host: 'localhost', port: '5432', database: 'gis_db', user: 'postgres', password: '********' },
  geo: { schema: 'public', country: 'Colombia', city: 'Bogotá D.C.' },
  activeLayer: 'manzanas_catastrales_v1',
  activeLayerId: '',
  confirmedLayer: '',
  confirmedLayerId: '',
  analysis: { method: 'kde', radius: 500, pixelSize: 50, weightField: '' },
  qgisLayers: [],
  postgisTables: ['tbl_placas_georef', 'manzanas_catastrales_v1', 'red_vial_urbana', 'zonas_administrativas'],
  logs: [
    { timestamp: '[14:22:01]', message: "Inicializando plugin de QGIS 'Análisis de Placas'...", type: 'info' },
    { timestamp: '[14:22:02]', message: 'Comprobando dependencias del sistema Python (GDAL, Psycopg2, Pandas)... OK', type: 'success' },
    { timestamp: '[14:22:03]', message: 'Esperando conexión a base de datos externa de PostGIS...', type: 'warning' },
  ],
};

let bridge = null;
let bridgeReady = false;

const root = document.getElementById('root');
const pad = (n) => String(n).padStart(2, '0');
const nowStamp = () => {
  const d = new Date();
  return `[${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}]`;
};
function addLog(message, type = 'info') {
  state.logs.push({ timestamp: nowStamp(), message, type });
  const terminal = document.querySelector('.terminal');
  renderLogsOnly();
  renderStatusOnly();
  if (terminal) terminal.scrollTop = terminal.scrollHeight;
}

function callBridge(action, payload = {}) {
  return new Promise((resolve) => {
    if (!bridgeReady || !bridge || typeof bridge.action !== 'function') {
      resolve({ ok: false, simulated: true, message: 'QGIS WebChannel no disponible. Acción ejecutada en modo visual.' });
      return;
    }
    try {
      bridge.action(JSON.stringify({ action, payload }), (raw) => {
        try { resolve(JSON.parse(raw)); }
        catch { resolve({ ok: false, message: raw || 'Respuesta inválida desde QGIS.' }); }
      });
    } catch (err) {
      resolve({ ok: false, message: String(err) });
    }
  });
}

function initBridge() {
  if (window.qt && window.QWebChannel) {
    new QWebChannel(qt.webChannelTransport, (channel) => {
      bridge = channel.objects.qgisBridge;
      bridgeReady = true;
      addLog('Canal QWebChannel activo. Interfaz web enlazada con Python/QGIS.', 'success');
      refreshQgisLayers(true);
    });
  } else {
    setTimeout(() => {
      if (!bridgeReady) addLog('Interfaz cargada en modo visual. QWebChannel no detectado todavía.', 'warning');
    }, 400);
  }
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"]/g, (ch) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
}

function titleForTab(tab) {
  return tab === 1 ? 'Handshake & Configuración' : tab === 2 ? 'Gestión de Capas' : 'Modelo de Densidad Kernel';
}

function icon(name) {
  const map = {
    cable: '⛓', layers: '▰', chart: '⌁', db: '◉', settings: '⚙', help: '?', map: '⌖', lock: '🔒', terminal: '▣', cpu: '◌', play: '▶', server: '▤', shield: '⚠', plus: '+', info: 'i', sliders: '☷', award: '◆', refresh: '↻', zoomIn: '+', zoomOut: '−', reset: '⌾'
  };
  return `<span class="icon-${name}">${map[name] || '•'}</span>`;
}

function shell() {
  return `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand">
          <h1>Analisis de densidad</h1>
          <p>v1.2.0-stable</p>
        </div>
        <nav class="nav">
          ${navButton(1, '1 · Conexión', 'cable')}
          ${navButton(2, '2 · Capas', 'layers')}
          ${navButton(3, '3 · Análisis', 'chart')}
        </nav>
        <div class="sidebar-footer">
          <button id="sidebarConnect" class="connect-shortcut ${state.connected ? 'connected' : ''}">${state.connected ? 'Disconnect Database' : 'Connect Database'}</button>
          <div class="side-links">
            <button class="side-link" data-tab="1">${icon('sliders')} Configuración</button>
            <a class="side-link" href="https://qgis.org" target="_blank">${icon('help')} Ayuda</a>
          </div>
        </div>
      </aside>
      <main class="workspace">
        <header class="topbar">
          <div class="top-title">
            <h2>Análisis de Placas</h2>
            <div class="separator"></div>
            <span>${titleForTab(state.activeTab)}</span>
          </div>
          <div class="toolbar">
            <button class="tool-btn" data-tab="1" title="Base de datos">${icon('db')}</button>
            <button class="tool-btn" title="Preferencias">${icon('settings')}</button>
          </div>
        </header>
        <div id="content" class="content">${renderTab()}</div>
        <div id="logsPanel" class="logs-panel">${logsPanel()}</div>
        <footer id="statusbar" class="statusbar">${statusbar()}</footer>
      </main>
    </div>`;
}

function navButton(id, label, iconName) {
  return `<button class="nav-btn ${state.activeTab === id ? 'active' : ''}" data-tab="${id}"><span class="nav-icon">${icon(iconName)}</span><span>${label}</span></button>`;
}

function renderTab() {
  if (state.activeTab === 1) return connectionTab();
  if (state.activeTab === 2) return layersTab();
  return analysisTab();
}

function connectionTab() {
  return `<div class="tab-pane">
    <div class="grid-two">
      <section class="card">
        <div class="card-header">
          <h2 class="card-title">${icon('db')} Configuración de Base de Datos</h2>
          <span class="cyan">${icon('db')}</span>
        </div>
        <div class="stack">
          ${inputRow('Host', 'dbHost', state.db.host)}
          ${inputRow('Puerto', 'dbPort', state.db.port)}
          ${inputRow('Base de Datos', 'dbDatabase', state.db.database)}
          ${inputRow('Usuario', 'dbUser', state.db.user)}
          ${inputRow('Contraseña', 'dbPassword', state.db.password, 'password')}
        </div>
        <div class="card-footer">
          <div class="row"><span class="dot ${state.connected ? 'green' : 'red'} pulse"></span><span class="status-text ${state.connected ? 'green' : 'red'}">${state.connecting ? 'Conectando...' : state.connected ? 'Conectado (PostGIS Activo)' : 'Desconectado'}</span></div>
          <button id="connectBtn" class="btn ${state.connected ? 'btn-danger' : 'btn-primary'}" ${state.connecting ? 'disabled' : ''}>${state.connecting ? 'Conectando...' : state.connected ? 'Desconectar' : 'Conectar'}</button>
        </div>
      </section>
      <section class="card secondary ${state.connected ? '' : 'locked'}">
        ${state.connected ? '' : `<div class="lock-overlay"><div class="lock-message">${icon('lock')} Conectar base de datos primero</div></div>`}
        <div class="card-header">
          <h2 class="card-title green">${icon('map')} Filtro Geográfico</h2>
          <span class="green">⌖</span>
        </div>
        <div class="stack">
          <div class="field"><label class="label">Esquema</label>${select('geoSchema', ['public','analisis_espacial','catastro_nacional','infraestructura'], state.geo.schema, 'Seleccionar esquema...')}</div>
          <div class="field"><label class="label">País</label>${select('geoCountry', ['Colombia','México','España','Chile','Argentina'], state.geo.country, 'Seleccionar país...')}</div>
          <div class="field"><label class="label">Ciudad / Municipio</label>${select('geoCity', citiesByCountry()[state.geo.country] || [], state.geo.city, state.geo.country ? 'Seleccionar ciudad...' : 'Seleccione un país primero...')}</div>
        </div>
        <div style="margin-top:26px"><button id="loadMuniBtn" class="btn btn-outline-green">Cargar Capa de Municipio</button></div>
      </section>
    </div>
    <div class="info-card">
      <div class="thumb"></div>
      <div>
        <h3>Visualización de Datos de Placas <span class="muted">?</span></h3>
        <p>Una vez establecida la conexión con PostgreSQL / PostGIS, podrá visualizar, filtrar y procesar las geometrías de las placas municipales georeferenciadas de manera vectorial. El sistema detecta y utiliza el sistema de referencia espacial <span class="cyan mono">EPSG:4326</span> (WGS 84) de forma predeterminada para evitar desajustes de reproyección.</p>
      </div>
    </div>
  </div>`;
}

function inputRow(label, id, value, type='text') {
  return `<div class="form-grid"><label class="label" for="${id}">${label}</label><input id="${id}" class="input" type="${type}" value="${esc(value)}" ${state.connecting || state.connected ? 'disabled' : ''}></div>`;
}

function select(id, values, selected, placeholder) {
  const opts = [`<option value="">${esc(placeholder)}</option>`].concat(values.map(v => `<option value="${esc(v)}" ${v === selected ? 'selected' : ''}>${esc(v)}</option>`));
  return `<select id="${id}" class="select">${opts.join('')}</select>`;
}

function citiesByCountry() {
  return {
    'Colombia': ['Bogotá D.C.', 'Medellín', 'Cali', 'Barranquilla', 'Bucaramanga', 'Cartagena'],
    'México': ['Ciudad de México', 'Guadalajara', 'Monterrey', 'Puebla', 'Tijuana'],
    'España': ['Madrid', 'Barcelona', 'Valencia', 'Sevilla', 'Zaragoza'],
    'Chile': ['Santiago', 'Valparaíso', 'Concepción', 'La Serena'],
    'Argentina': ['Buenos Aires', 'Córdoba', 'Rosario', 'Mendoza'],
  };
}

function layersTab() {
  const layers = state.qgisLayers.length ? state.qgisLayers : [
    { id: '', name: 'manzanas_catastrales_v1', srid: 'EPSG:4326', type: 'Vectorial', geometryType: 'Polygon', featureCount: 140 },
    { id: '', name: 'tbl_placas_georef', srid: 'EPSG:4326', type: 'Vectorial', geometryType: 'Point', featureCount: 1482901 },
    { id: '', name: 'red_vial_urbana', srid: 'EPSG:4326', type: 'Vectorial', geometryType: 'LineString', featureCount: 60 },
  ];
  const active = layers.find(l => l.name === state.activeLayer) || layers[0];
  if (active) { state.activeLayer = active.name; state.activeLayerId = active.id || ''; }
  const confirmed = layers.find(l => (state.confirmedLayerId && l.id === state.confirmedLayerId) || l.name === state.confirmedLayer);
  return `<div class="tab-pane">
    <div class="grid-12">
      <section class="col-7 card soft no-bar">
        <div class="layer-select-card">
          <div class="selected-layer-row">
            <div>
              <div class="row"><span class="cyan">${icon('layers')}</span><h3 style="margin:0;font-size:16px">Capas Activas en QGIS</h3></div>
              <p class="small muted" style="margin:6px 0 0">Seleccione una capa vectorial activa del proyecto actual.</p>
            </div>
            <button id="refreshLayersBtn" class="btn btn-ghost">${icon('refresh')} Actualizar</button>
          </div>
          <select id="activeLayerSelect" class="select">${layers.map(l => `<option value="${esc(l.name)}" ${l.name === state.activeLayer ? 'selected' : ''}>${esc(l.name)}</option>`).join('')}</select>
          <button id="confirmLayerBtn" class="btn btn-secondary" style="width:100%;margin-top:10px;text-transform:uppercase;font-size:12px">${icon('shield')} Confirmar capa a analizar</button>
          <div style="margin-top:12px;padding:11px 13px;background:rgba(78,222,163,.10);border:1px solid rgba(78,222,163,.25);border-radius:10px">
            <div class="small muted upper mono">Capa confirmada para analisis</div>
            <div class="white" style="font-weight:900;margin-top:4px">${esc(confirmed?.name || 'Ninguna capa confirmada')}</div>
            <p class="tiny muted" style="margin:6px 0 0;line-height:1.35">Solo esta capa confirmada sera enviada al flujo de analisis, aunque QGIS cambie la capa activa.</p>
          </div>
          <div class="row-between">
            <div>
              <div class="small muted upper mono">Capa seleccionada</div>
              <div class="white" style="font-weight:800;margin-top:3px">${esc(active?.name || 'Sin capa')}</div>
              <div class="badges">
                <span class="badge">${esc(active?.srid || 'EPSG:4326')}</span>
                <span class="badge">Vectorial</span>
                <span class="badge green">${esc(active?.geometryType || 'Polygon')}</span>
                <span class="badge">${Number(active?.featureCount || 0).toLocaleString('es-CO')} Features</span>
              </div>
            </div>
          </div>
          <div class="map-box"><div class="map-controls"><div class="map-control-group"><button class="map-btn" data-map-zoom="in">+</button><button class="map-btn" data-map-zoom="out">−</button><button class="map-btn" data-map-reset="1">⌾</button></div><button class="grid-toggle active">▦ GRID</button></div><canvas id="layerMap" class="map-canvas"></canvas><div class="map-label"><span class="green">● Layer:</span> ${esc(state.activeLayer)} | <span class="cyan">Zoom:</span> 1.0x</div></div>
        </div>
      </section>
      <section class="col-5 card soft no-bar">
        <div class="switch-card">
          <div>
            <div class="row"><span class="cyan">${icon('sliders')}</span><h3 style="margin:0;font-size:16px">Opciones de Máscara</h3></div>
            <p class="small muted" style="line-height:1.65">Configuración avanzada de recortes espaciales para limitar el procesamiento de densidad de placas vectoriales a polígonos de contención.</p>
          </div>
          <label class="toggle-row">
            <div><div class="small white" style="font-weight:800">Municipio como máscara</div><div class="tiny muted" style="margin-top:4px;line-height:1.35">Recortar resultados de análisis a límites municipales cargados</div></div>
            <span class="switch"><input id="maskToggle" type="checkbox" ${state.maskEnabled ? 'checked' : ''}><span class="slider"></span></span>
          </label>
        </div>
      </section>
      <section class="col-12 card soft no-bar border-top-cyan">
        ${state.connected ? '' : `<div class="lock-big"><div class="lock-big-inner"><div class="red" style="font-size:36px">${icon('shield')}</div><h4>PostGIS no Conectado</h4><p>Para importar tablas vectoriales espaciales directamente desde su base de datos, debe ir a la pestaña <span class="green" style="font-weight:800">1 · Conexión</span> y pulsar el botón conectar.</p></div></div>`}
        <div class="row" style="margin-bottom:16px"><span class="cyan">${icon('server')}</span><div><h3 style="margin:0;font-size:15px">Capas desde PostGIS</h3><p class="tiny muted" style="margin:3px 0 0">Importación directa de geometrías desde la base de datos vinculada</p></div></div>
        <div class="grid-two" style="grid-template-columns:1fr 1fr auto;max-width:none;gap:16px;align-items:end">
          <div class="field"><label class="label">Esquema</label>${select('pgSchema', ['public','analisis_espacial','catastro_nacional','infraestructura'], state.geo.schema, 'public')}</div>
          <div class="field"><label class="label">Tabla Espacial</label>${select('pgTable', state.postgisTables, state.postgisTables[0], 'Seleccione una tabla...')}</div>
          <button id="addPgLayerBtn" class="btn btn-secondary" style="height:38px;text-transform:uppercase;font-size:12px">${icon('plus')} Agregar al Proyecto</button>
        </div>
        <div style="margin-top:16px;padding:13px;background:rgba(28,27,29,.5);border-radius:10px;border-left:4px solid var(--secondary);display:flex;gap:12px;align-items:flex-start"><span class="green">${icon('info')}</span><p class="small muted" style="margin:0;line-height:1.6">Solo se listan y procesan las tablas que contienen una columna de geometría espacial registrada en el catálogo <span class="mono white">geometry_columns</span> de PostGIS. El sistema detectará automáticamente el SRID de origen y reproyectará al vuelo si es necesario.</p></div>
      </section>
      <section class="col-12"><div class="landscape"><div class="landscape-copy"><div class="row"><span class="dot green pulse"></span><span class="tiny mono upper green" style="font-weight:900">Live Spatial Engine Active</span></div><h4>Previsualización Dinámica del Proyecto Vectorial</h4></div></div></section>
    </div>
  </div>`;
}

function analysisTab() {
  const executionLayer = state.confirmedLayer || 'Sin capa confirmada';
  const confirmationState = state.confirmedLayer ? 'Confirmada' : 'Pendiente';
  return `<div class="tab-pane">
    <div class="grid-12">
      <section class="col-8 card soft no-bar">
        <div class="row-between" style="margin-bottom:14px"><div><h3 style="margin:0;color:var(--primary);font-size:17px">Preview Espacial / Heatmap</h3><p class="small muted" style="margin:5px 0 0">Visualización dinámica de la capa seleccionada y resultado de densidad.</p></div><span class="badge green">${state.maskEnabled ? 'MASK ON' : 'MASK OFF'}</span></div>
        <div class="map-box big-map"><div class="map-controls"><div class="map-control-group"><button class="map-btn">+</button><button class="map-btn">−</button><button class="map-btn">⌾</button></div><button class="grid-toggle active">▦ GRID</button></div><canvas id="analysisMap" class="map-canvas"></canvas><div class="map-label"><span class="green">● Layer:</span> ${esc(executionLayer)} | <span class="cyan">Heatmap:</span> ${state.showHeatmap ? 'ON' : 'OFF'}</div></div>
      </section>
      <section class="col-4 card soft no-bar">
        <h3 style="margin:0 0 12px;color:var(--primary);font-size:15px">Método de Análisis</h3>
        <div class="method-grid">
          ${methodCard('kde','Kernel Density','Estimación de densidad por radio de influencia')}
          ${methodCard('dbscan','DBSCAN','Agrupamiento espacial por concentración')}
          ${methodCard('nearest_neighbor','Vecino Cercano','Patrón de distribución espacial')}
          ${methodCard('getis_ord','Getis-Ord Gi*','Hotspots estadísticos')}
        </div>
      </section>
      <section class="col-8 card soft no-bar border-top-cyan">
        <div class="grid-12" style="max-width:none">
          <div class="col-8 stack">
            <div class="parameter-grid">
              <div class="field"><label class="label">Radio de Influencia (m)</label><div style="position:relative"><input id="radiusInput" class="input" type="number" min="1" value="${state.analysis.radius}"><span class="tiny mono muted upper" style="position:absolute;right:12px;top:11px">Meters</span></div></div>
              <div class="field"><label class="label">Tamaño de Píxel (m)</label><div style="position:relative"><input id="pixelInput" class="input" type="number" min="1" value="${state.analysis.pixelSize}"><span class="tiny mono muted upper" style="position:absolute;right:12px;top:11px">Res</span></div></div>
            </div>
            <div class="field"><label class="label">Campo de Peso (Atributo)</label><div class="row"><select id="weightField" class="select"><option value="">Sin ponderación</option><option value="intensidad">intensidad</option><option value="score">score</option><option value="frecuencia">frecuencia</option></select><button class="btn btn-ghost">⚖</button></div></div>
          </div>
          <div class="col-4 curve-box">
            <div><h3 class="tiny upper cyan" style="margin:0;font-weight:900">Vista Previa de Influencia</h3><p class="tiny muted" style="line-height:1.45">Muestra el decaimiento de la influencia del punto según la distancia del radio de búsqueda de ${state.analysis.radius} metros.</p></div>
            <div class="curve-inner"><svg viewBox="0 0 200 100" width="100%" height="100%"><line x1="10" y1="90" x2="190" y2="90" stroke="rgba(58,73,74,.4)"/><line x1="10" y1="10" x2="10" y2="90" stroke="rgba(58,73,74,.4)"/><path d="M 10 90 C 50 90, 60 22, 100 22 C 140 22, 150 90, 190 90" fill="url(#g)"/><path d="M 10 90 C 50 90, 60 22, 100 22 C 140 22, 150 90, 190 90" fill="none" stroke="#00f5ff" stroke-width="2.5"/><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#00f5ff" stop-opacity=".25"/><stop offset="1" stop-color="#00f5ff" stop-opacity="0"/></linearGradient></defs><text x="100" y="98" fill="rgba(185,202,202,.4)" font-size="8" text-anchor="middle" font-family="monospace">Decaimiento Kernel</text></svg></div>
          </div>
        </div>
      </section>
      <section class="col-4 card soft no-bar">
        <h3 style="margin:0;color:var(--primary);font-size:15px">Resumen de Entrada</h3>
        <div class="stack" style="margin-top:16px">
          <div class="row-between small"><span class="muted">Capa que se ejecutara</span><b>${esc(executionLayer)}</b></div>
          <div class="row-between small"><span class="muted">Estado de capa</span><b class="${state.confirmedLayer ? 'green' : 'red'}">${confirmationState}</b></div>
          <div class="row-between small"><span class="muted">CRS</span><b class="mono">EPSG:4326</b></div>
          <div class="row-between small"><span class="muted">Máscara municipal</span><b class="${state.maskEnabled ? 'green' : 'red'}">${state.maskEnabled ? 'Activa' : 'Inactiva'}</b></div>
          <div class="row-between small"><span class="muted">Motor</span><b class="cyan mono">QGIS Processing</b></div>
        </div>
      </section>
    </div>
    <div class="execute-wrap"><button id="executeAnalysisBtn" class="btn btn-blue execute" ${state.systemStatus === 'PROCESSING' ? 'disabled' : ''}>${state.systemStatus === 'PROCESSING' ? `${icon('cpu')} Procesando Capas Vectoriales...` : `${icon('play')} Ejecutar Análisis Espacial`}</button><span class="tiny muted mono upper" style="margin-top:9px">Tiempo estimado: ~4.2s para 1.5M de registros vectoriales</span></div>
    ${state.showResults ? resultsCard() : ''}
  </div>`;
}

function methodCard(id, title, desc) {
  return `<button class="method-card ${state.analysis.method === id ? 'active' : ''}" data-method="${id}"><h4>${title}</h4><p>${desc}</p></button>`;
}

function resultsCard() {
  return `<div class="results card soft no-bar border-top-green"><div class="row" style="align-items:flex-start"><div style="padding:9px;background:rgba(78,222,163,.15);border:1px solid rgba(78,222,163,.35);border-radius:10px;color:var(--secondary);font-size:24px">${icon('award')}</div><div style="flex:1"><h3 style="margin:0;color:var(--primary);font-size:16px">Análisis Completado Exitosamente <span class="green">✓</span></h3><p class="small muted" style="margin:6px 0 0">El procesamiento de densidad Kernel ha culminado y la capa resultante ha sido inyectada directamente en el proyecto QGIS.</p><div class="stats-grid"><div class="stat"><span>Puntos Analizados</span><p>1,482,901</p></div><div class="stat"><span>Dimensiones Raster</span><p>2400 x 3600 px</p></div><div class="stat"><span>Densidad Promedio</span><p class="cyan">4.18 placas/km²</p></div><div class="stat"><span>Tiempo Empleado</span><p class="green">4.12 segundos</p></div></div></div></div></div>`;
}

function logsPanel() {
  return `<div class="logs-shell"><div class="logs-head"><div class="logs-head-title">${icon('terminal')} Logs de Sistema / Consola de Salida</div><div class="log-actions"><button id="copyLogsBtn" class="log-action" title="Copiar Logs">⧉</button><button id="clearLogsBtn" class="log-action" title="Limpiar Consola">⌫</button></div></div><div class="terminal">${logsHtml()}</div></div>`;
}

function logsHtml() {
  if (!state.logs.length) return `<div class="empty-terminal">La consola de salida está vacía. Inicie una acción para ver los registros del geoprocesamiento.</div>`;
  return state.logs.map(log => `<div class="log-line ${log.type}"><span class="log-time">${esc(log.timestamp)}</span><span>${log.type === 'success' ? '✓' : log.type === 'warning' ? '⚠' : log.type === 'error' ? '!' : 'i'}</span><span>${esc(log.message)}</span></div>`).join('');
}

function statusbar() {
  const statusClass = state.systemStatus === 'PROCESSING' ? 'amber' : state.connected ? 'green' : 'red';
  const label = state.systemStatus === 'PROCESSING' ? 'Engine: Processing' : `Base de datos: ${state.connected ? 'Conectado' : 'Desconectado'}`;
  return `<div class="status-left"><div class="row"><span class="dot ${statusClass} pulse"></span><span class="status-text ${statusClass}">${label}</span></div><div class="divider-v"></div><div class="mono muted"><b class="white">EPSG:4326 (WGS 84)</b></div></div><div class="status-center">${state.systemStatus === 'PROCESSING' || state.progress > 0 ? `<div class="progress-wrap"><span class="progress-label">Running</span><div class="progress-track"><div class="progress-fill" style="width:${state.progress}%"></div></div><span class="progress-num">${state.progress}%</span></div>` : `<div class="ticker"><b>LOG:</b><span>${esc(lastLog())}</span></div>`}</div><div class="status-right"><div class="mono muted">${icon('cpu')} Mem: <b class="white">${state.memory.toFixed(1)} MB</b></div><div class="divider-v"></div><div class="row"><a class="muted small" href="https://qgis.org/es/site/" target="_blank" style="text-decoration:none">Documentation ↗</a><span class="muted">•</span><a class="muted small" href="https://github.com/qgis/QGIS/issues" target="_blank" style="text-decoration:none">Issue Tracker</a></div></div>`;
}
function lastLog() { return state.logs.length ? state.logs[state.logs.length - 1].message : 'Esperando acciones...'; }

function render() {
  root.innerHTML = shell();
  bindEvents();
  requestAnimationFrame(() => drawMaps());
  const terminal = document.querySelector('.terminal');
  if (terminal) terminal.scrollTop = terminal.scrollHeight;
}
function renderContentOnly() {
  document.getElementById('content').innerHTML = renderTab();
  document.getElementById('statusbar').innerHTML = statusbar();
  bindEvents();
  requestAnimationFrame(() => drawMaps());
}
function renderLogsOnly() {
  const terminal = document.querySelector('.terminal');
  if (terminal) {
    terminal.innerHTML = logsHtml();
    terminal.scrollTop = terminal.scrollHeight;
  }
}
function renderStatusOnly() {
  const status = document.getElementById('statusbar');
  if (status) status.innerHTML = statusbar();
}

function bindEvents() {
  document.querySelectorAll('[data-tab]').forEach(btn => btn.onclick = () => { state.activeTab = Number(btn.dataset.tab); state.showResults = false; render(); });
  const sidebarConnect = document.getElementById('sidebarConnect');
  if (sidebarConnect) sidebarConnect.onclick = () => state.connected ? disconnectDb() : (state.activeTab = 1, render(), addLog('Por favor, verifique sus credenciales de PostGIS y pulse el botón "Conectar".', 'info'));
  const connectBtn = document.getElementById('connectBtn'); if (connectBtn) connectBtn.onclick = () => state.connected ? disconnectDb() : connectDb();
  ['dbHost','dbPort','dbDatabase','dbUser','dbPassword'].forEach(id => { const el = document.getElementById(id); if (el) el.oninput = () => { const k = id.replace('db','').toLowerCase(); const key = k === 'database' ? 'database' : k; state.db[key] = el.value; }; });
  const geoSchema = document.getElementById('geoSchema'); if (geoSchema) geoSchema.onchange = () => { state.geo.schema = geoSchema.value; };
  const geoCountry = document.getElementById('geoCountry'); if (geoCountry) geoCountry.onchange = () => { state.geo.country = geoCountry.value; state.geo.city = ''; renderContentOnly(); };
  const geoCity = document.getElementById('geoCity'); if (geoCity) geoCity.onchange = () => { state.geo.city = geoCity.value; };
  const loadMuni = document.getElementById('loadMuniBtn'); if (loadMuni) loadMuni.onclick = loadMunicipality;
  const refresh = document.getElementById('refreshLayersBtn'); if (refresh) refresh.onclick = () => refreshQgisLayers(false);
  const confirmLayer = document.getElementById('confirmLayerBtn'); if (confirmLayer) confirmLayer.onclick = confirmAnalysisLayer;
  const activeLayer = document.getElementById('activeLayerSelect'); if (activeLayer) activeLayer.onchange = () => { state.activeLayer = activeLayer.value; const layer = state.qgisLayers.find(l => l.name === state.activeLayer); state.activeLayerId = layer?.id || ''; addLog(`Capa activa seleccionada: ${state.activeLayer}`, 'info'); renderContentOnly(); };
  const maskToggle = document.getElementById('maskToggle'); if (maskToggle) maskToggle.onchange = () => { state.maskEnabled = maskToggle.checked; addLog(`Máscara de contención municipal ${state.maskEnabled ? 'ACTIVADA' : 'DESACTIVADA'}`, 'info'); renderContentOnly(); };
  const addPg = document.getElementById('addPgLayerBtn'); if (addPg) addPg.onclick = addPostgisLayer;
  document.querySelectorAll('.method-card').forEach(btn => btn.onclick = () => { state.analysis.method = btn.dataset.method; renderContentOnly(); });
  const radius = document.getElementById('radiusInput'); if (radius) radius.oninput = () => { state.analysis.radius = Number(radius.value || 0); renderStatusOnly(); };
  const pixel = document.getElementById('pixelInput'); if (pixel) pixel.oninput = () => { state.analysis.pixelSize = Number(pixel.value || 0); };
  const weight = document.getElementById('weightField'); if (weight) weight.onchange = () => { state.analysis.weightField = weight.value; };
  const exec = document.getElementById('executeAnalysisBtn'); if (exec) exec.onclick = executeAnalysis;
  const clear = document.getElementById('clearLogsBtn'); if (clear) clear.onclick = () => { state.logs = []; renderLogsOnly(); renderStatusOnly(); };
  const copy = document.getElementById('copyLogsBtn'); if (copy) copy.onclick = () => { const text = state.logs.map(l => `${l.timestamp} ${l.message}`).join('\n'); navigator.clipboard?.writeText(text); addLog('Logs copiados al portapapeles.', 'success'); };
}

async function connectDb() {
  if (state.connecting) return;
  state.connecting = true;
  state.systemStatus = 'PROCESSING';
  state.progress = 8;
  render();
  addLog(`Intentando conectar a ${state.db.user}@${state.db.host}:${state.db.port}/${state.db.database || 'gis_db'}...`, 'info');
  await wait(350); state.progress = 24; renderStatusOnly(); addLog('Estableciendo Handshake TCP con el servidor remoto...', 'info');
  await wait(450); state.progress = 42; renderStatusOnly(); addLog('Autenticando credenciales de PostgreSQL...', 'info');
  await wait(450); state.progress = 63; renderStatusOnly(); addLog('Verificando disponibilidad de la extensión PostGIS...', 'info');
  const res = await callBridge('connectDb', state.db);
  state.connecting = false;
  state.progress = 100; renderStatusOnly();
  await wait(280);
  state.progress = 0;
  if (res.ok) {
    state.connected = true;
    state.systemStatus = 'Connected';
    if (Array.isArray(res.schemas) && res.schemas.length) state.geo.schema = res.schemas.includes('public') ? 'public' : res.schemas[0];
    if (Array.isArray(res.tables) && res.tables.length) state.postgisTables = res.tables.map(t => t.table || t.name).filter(Boolean);
    addLog('¡Conexión establecida con éxito! Base de datos en línea.', 'success');
  } else if (res.simulated) {
    state.connected = true;
    state.systemStatus = 'Connected';
    addLog('Modo visual: conexión simulada porque QWebChannel no respondió.', 'warning');
  } else {
    state.connected = false;
    state.systemStatus = 'Disconnected';
    addLog(`No se pudo conectar a PostGIS: ${res.message}`, 'error');
  }
  render();
}
async function disconnectDb() {
  addLog('Cerrando conexión con la base de datos...', 'info');
  await callBridge('disconnectDb', {});
  state.connected = false;
  state.systemStatus = 'Disconnected';
  state.progress = 0;
  addLog('Conexión cerrada. Base de datos desconectada.', 'warning');
  render();
}
async function loadMunicipality() {
  if (!state.geo.city) { addLog('Por favor, seleccione una ciudad/municipio para cargar.', 'error'); return; }
  addLog(`Cargando capa vectorial de límites del municipio: ${state.geo.city} (${state.geo.country})...`, 'info');
  await wait(350); addLog('Extrayendo geometrías administrativas para SRID:4326...', 'info');
  const res = await callBridge('loadMunicipality', { schema: state.geo.schema, city: state.geo.city, table: 'municipios', geom: 'geom', filterColumn: 'nombre' });
  if (res.ok || res.simulated) {
    addLog(`¡Capa vectorial '${state.geo.city.toLowerCase().replace(/\s/g, '_')}_limite' agregada correctamente al proyecto QGIS!`, 'success');
    state.activeTab = 2;
    refreshQgisLayers(true);
  } else addLog(`No se pudo cargar municipio: ${res.message}`, 'error');
  render();
}

function confirmAnalysisLayer() {
  const layer = state.qgisLayers.find(l => l.name === state.activeLayer) || {
    id: state.activeLayerId,
    name: state.activeLayer,
  };
  if (!layer || !layer.name) {
    addLog('Seleccione una capa antes de confirmarla para analisis.', 'error');
    return;
  }
  state.confirmedLayer = layer.name;
  state.confirmedLayerId = layer.id || state.activeLayerId || '';
  addLog(`Capa confirmada para analisis: ${state.confirmedLayer}`, 'success');
  renderContentOnly();
}

async function refreshQgisLayers(silent=false) {
  const res = await callBridge('getLayers', {});
  if (res.ok && Array.isArray(res.layers)) {
    state.qgisLayers = res.layers;
    if (res.layers.length && !res.layers.find(l => l.name === state.activeLayer)) {
      state.activeLayer = res.layers[0].name;
      state.activeLayerId = res.layers[0].id;
    }
    if (state.confirmedLayer && !res.layers.find(l => (state.confirmedLayerId && l.id === state.confirmedLayerId) || l.name === state.confirmedLayer)) {
      addLog(`La capa confirmada '${state.confirmedLayer}' ya no esta disponible. Confirme una capa nuevamente.`, 'warning');
      state.confirmedLayer = '';
      state.confirmedLayerId = '';
    }
    if (!silent) addLog(`Capas activas actualizadas desde QGIS: ${res.layers.length} capas vectoriales detectadas.`, 'success');
  } else if (!silent) addLog('No se pudo leer el proyecto QGIS; se mantiene la lista visual por defecto.', 'warning');
  if (state.activeTab === 2 || state.activeTab === 3) renderContentOnly();
}
async function addPostgisLayer() {
  const schema = document.getElementById('pgSchema')?.value || state.geo.schema;
  const table = document.getElementById('pgTable')?.value || '';
  if (!table) { addLog('Seleccione una tabla espacial antes de agregarla.', 'error'); return; }
  addLog(`Conectando al catálogo PostGIS. Leyendo tabla: ${schema}.${table}...`, 'info');
  const res = await callBridge('addPostgisLayer', { schema, table, geom: 'geom' });
  if (res.ok || res.simulated) {
    state.activeLayer = table;
    addLog(`Detectando columnas de geometría... Encontrada columna 'geom' de tipo MULTIPOLYGON (SRID:4326).`, 'success');
    addLog(`Capa '${table}' agregada al proyecto QGIS con éxito.`, 'success');
    await refreshQgisLayers(true);
  } else addLog(`No se pudo agregar la capa: ${res.message}`, 'error');
  renderContentOnly();
}
async function executeAnalysis() {
  if (!state.confirmedLayer) {
    addLog('Primero confirme la capa a analizar en el panel 2 - Capas.', 'error');
    state.activeTab = 2;
    render();
    return;
  }
  state.systemStatus = 'PROCESSING';
  state.progress = 0;
  state.showResults = false;
  state.showHeatmap = false;
  render();
  addLog(`Capa confirmada enviada al backend: ${state.confirmedLayer}`, 'success');
  addLog(`Iniciando análisis espacial '${state.analysis.method.toUpperCase()}' sobre la capa '${state.activeLayer}'...`, 'info');
  const steps = [
    [12, 'Preparando geometrías y validando CRS EPSG:4326...'],
    [28, 'Construyendo índice espacial en memoria...'],
    [47, `Aplicando radio de influencia de ${state.analysis.radius} m...`],
    [64, 'Calculando raster de densidad / superficie de influencia...'],
    [82, 'Aplicando máscara municipal y normalizando salida...'],
  ];
  for (const [pct, msg] of steps) { await wait(480); state.progress = pct; renderStatusOnly(); addLog(msg, 'info'); }
  const res = await callBridge('runAnalysis', { layerId: state.confirmedLayerId, layerName: state.confirmedLayer, method: state.analysis.method, radius: state.analysis.radius, pixelSize: state.analysis.pixelSize, weightField: state.analysis.weightField });
  await wait(450); state.progress = 100; renderStatusOnly();
  if (res.ok || res.simulated) {
    addLog(res.ok ? res.message : 'Modo visual: análisis simulado por la interfaz embebida.', 'success');
    state.showResults = true;
    state.showHeatmap = true;
  } else {
    addLog(`El análisis no pudo finalizar en QGIS: ${res.message}`, 'error');
  }
  await wait(550);
  state.systemStatus = state.connected ? 'Connected' : 'Disconnected';
  state.progress = 0;
  render();
}
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

function drawMaps() {
  drawMap('layerMap', false);
  drawMap('analysisMap', state.showHeatmap);
}
function drawMap(id, heatmap) {
  const canvas = document.getElementById(id);
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, rect.width * dpr);
  canvas.height = Math.max(1, rect.height * dpr);
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, rect.width, rect.height);
  ctx.fillStyle = '#09090b';
  ctx.fillRect(0, 0, rect.width, rect.height);
  ctx.strokeStyle = 'rgba(58,73,74,.22)';
  ctx.lineWidth = 1;
  const grid = 24;
  for (let x = 0; x < rect.width; x += grid) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, rect.height); ctx.stroke(); }
  for (let y = 0; y < rect.height; y += grid) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(rect.width, y); ctx.stroke(); }
  // boundary polygons
  const cx = rect.width / 2, cy = rect.height / 2;
  ctx.lineWidth = 1.5;
  const polys = [
    [[-150,-48],[-82,-88],[-30,-38],[-52,28],[-124,52]],
    [[-20,-58],[80,-76],[134,-18],[82,42],[-16,22]],
    [[-112,70],[-32,38],[46,70],[22,120],[-90,120]],
  ];
  polys.forEach((poly, idx) => {
    ctx.beginPath();
    poly.forEach(([x,y], i) => i ? ctx.lineTo(cx+x,cy+y) : ctx.moveTo(cx+x,cy+y));
    ctx.closePath();
    ctx.fillStyle = idx % 2 ? 'rgba(0,245,255,.05)' : 'rgba(78,222,163,.045)';
    ctx.strokeStyle = idx % 2 ? 'rgba(0,245,255,.4)' : 'rgba(78,222,163,.36)';
    ctx.fill(); ctx.stroke();
  });
  const points = [
    [-96,-34,9],[-52,-64,5],[-18,-5,7],[38,-42,9],[96,-15,6],[66,34,8],[-84,28,4],[-20,58,7],[24,82,5],[118,58,9],[-140,82,3]
  ];
  if (heatmap) {
    points.forEach(([x,y,intensity]) => {
      const grad = ctx.createRadialGradient(cx+x, cy+y, 0, cx+x, cy+y, 45 + intensity*4);
      grad.addColorStop(0, 'rgba(0,245,255,.28)');
      grad.addColorStop(.42, 'rgba(78,222,163,.15)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(cx+x, cy+y, 70, 0, Math.PI*2); ctx.fill();
    });
  }
  points.forEach(([x,y,intensity], i) => {
    ctx.beginPath();
    ctx.arc(cx+x, cy+y, 3.5 + intensity/4, 0, Math.PI*2);
    ctx.fillStyle = intensity > 7 ? '#00f5ff' : intensity > 5 ? '#4edea3' : '#b9caca';
    ctx.shadowColor = ctx.fillStyle; ctx.shadowBlur = 10;
    ctx.fill();
    ctx.shadowBlur = 0;
    if (i % 3 === 0) {
      ctx.fillStyle = 'rgba(185,202,202,.65)'; ctx.font = '9px monospace'; ctx.fillText(`P-${String(i+1).padStart(3,'0')}`, cx+x+8, cy+y-6);
    }
  });
  // scan line & corners
  const t = (Date.now() / 25) % Math.max(1, rect.height);
  ctx.strokeStyle = 'rgba(0,245,255,.13)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(0, t); ctx.lineTo(rect.width, t); ctx.stroke();
  ctx.strokeStyle = 'rgba(132,148,149,.32)'; ctx.lineWidth = 1.5;
  const p=12,l=11,w=rect.width,h=rect.height;
  [[p,p,p+l,p,p,p+l],[w-p,p,w-p-l,p,w-p,p+l],[p,h-p,p+l,h-p,p,h-p-l],[w-p,h-p,w-p-l,h-p,w-p,h-p-l]].forEach(a=>{ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(a[2],a[3]);ctx.moveTo(a[0],a[1]);ctx.lineTo(a[4],a[5]);ctx.stroke();});
  // compass
  ctx.save(); ctx.translate(rect.width-36, 44); ctx.strokeStyle='rgba(185,202,202,.75)'; ctx.fillStyle='rgba(0,245,255,.9)'; ctx.beginPath(); ctx.arc(0,0,16,0,Math.PI*2); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0,-12); ctx.lineTo(4,0); ctx.lineTo(-4,0); ctx.closePath(); ctx.fill(); ctx.fillStyle='rgba(185,202,202,.75)'; ctx.font='8px monospace'; ctx.textAlign='center'; ctx.fillText('N',0,-19); ctx.restore();
}

setInterval(() => { state.memory += (Math.random() - .5) * .8; state.memory = Math.max(38, Math.min(46, state.memory)); renderStatusOnly(); }, 4000);
setInterval(() => drawMaps(), 1000);
window.addEventListener('resize', () => drawMaps());
render();
initBridge();
