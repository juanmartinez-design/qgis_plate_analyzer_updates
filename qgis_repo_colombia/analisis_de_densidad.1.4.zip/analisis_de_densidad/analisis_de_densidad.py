# -*- coding: utf-8 -*-
"""Main QGIS plugin class.

This file is intentionally lightweight: it only registers the action in QGIS
and opens the main PyQt dialog. The interface and business logic live in
``ui/`` and ``core/``.
"""

from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsApplication


class AnalisisDeDensidad:
    """QGIS plugin bootstrap class."""

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None
        self.menu_name = "&Analisis de densidad"

    def initGui(self):
        """Create toolbar icon and plugin menu entry."""
        try:
            icon = QgsApplication.getThemeIcon("/mActionOpenTable.svg")
        except Exception:  # pragma: no cover - defensive for older QGIS builds
            icon = QIcon()

        self.action = QAction(icon, "Analisis de densidad", self.iface.mainWindow())
        self.action.setObjectName("analisisDeDensidadAction")
        self.action.setToolTip("Abrir Analisis de densidad")
        self.action.triggered.connect(self.run)

        self.iface.addPluginToMenu(self.menu_name, self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        """Remove menu and toolbar items when the plugin is disabled."""
        if self.action is not None:
            self.iface.removePluginMenu(self.menu_name, self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def run(self):
        """Open the main dialog."""
        from .ui.main_dialog import MainDialog

        if self.dialog is None:
            self.dialog = MainDialog(self.iface, self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
