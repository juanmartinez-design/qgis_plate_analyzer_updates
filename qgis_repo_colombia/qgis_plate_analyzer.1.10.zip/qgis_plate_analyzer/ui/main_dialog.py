﻿# -*- coding: utf-8 -*-
"""Main dialog for QGIS Plate Analyzer.

This version does NOT require QtWebEngine.  The original ZIP contained a
React/Vite interface, but several QGIS installations do not bundle
QtWebEngine, so rendering HTML inside QGIS fails.  This dialog recreates the
same application shell natively with PyQt widgets: dark sidebar, header, cards,
map preview, system console and status bar.
"""

import math
import html
import json
import os
import random
import shutil
import tempfile
import time
import traceback
from datetime import datetime
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from qgis.PyQt.QtCore import QPointF, QRectF, Qt, QTimer, QUrl
from qgis.PyQt.QtGui import QColor, QDesktopServices, QFont, QLinearGradient, QPainter, QPen, QRadialGradient
from qgis.PyQt.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QProgressBar,
    QScrollArea,
    QSizePolicy,
    QSpacerItem,
    QStackedWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)
from qgis.core import QgsApplication, QgsProject, QgsVectorLayer

from ..core.db_manager import DBConfig, DBManager
from ..core.density_analysis import DensityAnalysis, qgis_layer_to_geodataframe


DEFAULT_UPDATE_DIR = Path(r"C:\Users\jamartinez\Documents\Herramienta analisis de placas")
DEFAULT_UPDATE_VERSION_FILE = DEFAULT_UPDATE_DIR / "version.json"
DEFAULT_UPDATE_ZIP_FILE = DEFAULT_UPDATE_DIR / "qgis_plate_analyzer_importar_qgis.zip"
DEFAULT_GITHUB_TOKEN_ENV = "QGIS_PLATE_ANALYZER_GITHUB_TOKEN"
DEFAULT_GITHUB_TOKEN_FILE = "~/.qgis_plate_analyzer/github_token.txt"


class MapPreviewWidget(QWidget):
    """Small native canvas inspired by the original React canvas map preview."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(280)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.layer_name = "tbl_placas_georef"
        self.points_count = 120
        self.show_heatmap = False
        self.mask_enabled = True
        self.zoom = 1.0
        self.offset_x = 0.0
        self.offset_y = 0.0
        self.scan_line = 0.0
        self.points = self._generate_points(self.points_count)
        self.boundaries = self._generate_boundaries()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(80)

    def _tick(self):
        self.scan_line = (self.scan_line + 3.0) % max(self.height(), 1)
        self.update()

    def set_layer_name(self, name: str):
        self.layer_name = name or "tbl_placas_georef"
        self.update()

    def set_heatmap(self, enabled: bool):
        self.show_heatmap = bool(enabled)
        self.update()

    def set_mask_enabled(self, enabled: bool):
        self.mask_enabled = bool(enabled)
        self.update()

    def _generate_points(self, count: int) -> List[Tuple[float, float, float]]:
        rnd = random.Random(42)
        pts = []
        for _ in range(count):
            angle = rnd.random() * math.pi * 2
            radius = rnd.random() * 155 + 25
            cluster_x = 100 if rnd.random() > 0.63 else (-120 if rnd.random() > 0.5 else 0)
            cluster_y = -80 if rnd.random() > 0.65 else (90 if rnd.random() > 0.5 else 0)
            x = cluster_x + math.cos(angle) * radius
            y = cluster_y + math.sin(angle) * radius
            intensity = 1 + rnd.random() * 8
            pts.append((x, y, intensity))
        return pts

    def _generate_boundaries(self):
        rnd = random.Random(7)
        boundaries = []
        for _ in range(4):
            cx = (rnd.random() - 0.5) * 210
            cy = (rnd.random() - 0.5) * 210
            sides = 5 + int(rnd.random() * 4)
            poly = []
            for s in range(sides):
                theta = (s / sides) * math.pi * 2
                r = 55 + rnd.random() * 44
                poly.append((cx + math.cos(theta) * r, cy + math.sin(theta) * r))
            boundaries.append(poly)
        return boundaries

    def wheelEvent(self, event):  # pragma: no cover - UI event
        delta = event.angleDelta().y()
        self.zoom = max(0.55, min(2.5, self.zoom + (0.1 if delta > 0 else -0.1)))
        self.update()

    def paintEvent(self, event):  # pragma: no cover - visual painting inside QGIS
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        painter.fillRect(self.rect(), QColor("#ffffff"))

        cx = w / 2 + self.offset_x
        cy = h / 2 + self.offset_y

        # Grid
        painter.setPen(QPen(QColor(17, 24, 39, 24), 1))
        spacing = max(25, int(40 * self.zoom))
        x = int(self.offset_x) % spacing
        while x < w:
            painter.drawLine(x, 0, x, h)
            x += spacing
        y = int(self.offset_y) % spacing
        while y < h:
            painter.drawLine(0, y, w, y)
            y += spacing

        # Municipal boundaries / mask
        if self.mask_enabled:
            painter.setPen(QPen(QColor(91, 191, 121, 150), 1.5))
            painter.setBrush(QColor(183, 247, 194, 34))
            for poly in self.boundaries:
                pts = [QPointF(cx + px * self.zoom, cy + py * self.zoom) for px, py in poly]
                painter.drawPolygon(pts)

        # Heatmap rings
        if self.show_heatmap:
            for px, py, intensity in self.points:
                sx = cx + px * self.zoom
                sy = cy + py * self.zoom
                rad = intensity * 13 * self.zoom
                grad = QRadialGradient(QPointF(sx, sy), rad)
                grad.setColorAt(0.0, QColor(183, 247, 194, 92))
                grad.setColorAt(0.35, QColor(183, 247, 194, 32))
                grad.setColorAt(1.0, QColor(183, 247, 194, 0))
                painter.setBrush(grad)
                painter.setPen(Qt.NoPen)
                painter.drawEllipse(QPointF(sx, sy), rad, rad)

        # Vector connection effect
        painter.setPen(QPen(QColor(0, 245, 255, 18), 1))
        for i in range(0, len(self.points) - 1, 5):
            x1, y1, _ = self.points[i]
            x2, y2, _ = self.points[i + 1]
            painter.drawLine(QPointF(cx + x1 * self.zoom, cy + y1 * self.zoom), QPointF(cx + x2 * self.zoom, cy + y2 * self.zoom))

        # Points
        painter.setPen(Qt.NoPen)
        for px, py, intensity in self.points:
            sx = cx + px * self.zoom
            sy = cy + py * self.zoom
            if sx < -30 or sx > w + 30 or sy < -30 or sy > h + 30:
                continue
            if intensity > 7:
                painter.setBrush(QColor(16, 18, 20, 34))
                painter.drawEllipse(QPointF(sx, sy), 6 * self.zoom, 6 * self.zoom)
                painter.setBrush(QColor("#111111"))
            elif intensity > 4:
                painter.setBrush(QColor("#5fbf79"))
            else:
                painter.setBrush(QColor("#aeb7b0"))
            r = (2.4 + intensity * 0.16) * self.zoom
            painter.drawEllipse(QPointF(sx, sy), r, r)

        # Scanner line
        painter.setPen(QPen(QColor(91, 191, 121, 70), 1))
        painter.drawLine(0, int(self.scan_line), w, int(self.scan_line))

        # Corner frames
        painter.setPen(QPen(QColor(132, 148, 149, 90), 1.5))
        pad, ln = 12, 12
        painter.drawLine(pad, pad, pad + ln, pad)
        painter.drawLine(pad, pad, pad, pad + ln)
        painter.drawLine(w - pad, pad, w - pad - ln, pad)
        painter.drawLine(w - pad, pad, w - pad, pad + ln)
        painter.drawLine(pad, h - pad, pad + ln, h - pad)
        painter.drawLine(pad, h - pad, pad, h - pad - ln)
        painter.drawLine(w - pad, h - pad, w - pad - ln, h - pad)
        painter.drawLine(w - pad, h - pad, w - pad, h - pad - ln)

        # Overlay labels
        painter.setPen(QColor(17, 24, 39, 170))
        painter.setFont(QFont("Consolas", 8, QFont.Bold))
        painter.drawText(16, 26, f"LAYER: {self.layer_name}")
        painter.drawText(16, 44, f"POINTS: {len(self.points)}  |  ZOOM: {self.zoom:.1f}x")
        painter.setPen(QColor(17, 24, 39, 190))
        painter.drawText(w - 140, 26, "EPSG:4326")


class MainDialog(QDialog):
    """Native PyQt version of the QGIS Plate Analyzer interface."""

    CITIES: Dict[str, List[str]] = {
        "Colombia": ["Bogota D.C.", "Medellin", "Cali", "Barranquilla", "Bucaramanga", "Cartagena", "Neiva"],
        "Mexico": ["Ciudad de Mexico", "Guadalajara", "Monterrey", "Puebla", "Tijuana"],
        "Espana": ["Madrid", "Barcelona", "Valencia", "Sevilla", "Zaragoza"],
        "Chile": ["Santiago", "Valparaiso", "Concepcion", "La Serena"],
        "Argentina": ["Buenos Aires", "Cordoba", "Rosario", "Mendoza"],
    }

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.db = DBManager()
        self.is_connected = False
        self.active_tab = 0
        self.nav_buttons: List[QPushButton] = []
        self.layer_id_by_label: Dict[str, str] = {}
        self.confirmed_analysis_layer_id = ""
        self.confirmed_analysis_layer_name = ""
        self.manual_admin_mask_layer_id = ""
        self.manual_admin_mask_name = ""
        self.manual_admin_mask_gdf = None
        self.manual_urban_footprint_layer_id = ""
        self.manual_urban_footprint_name = ""
        self.manual_urban_footprint_gdf = None
        self.manual_constructions_layer_id = ""
        self.manual_constructions_name = ""
        self.manual_constructions_gdf = None
        self.last_analysis_result: Optional[Dict[str, Any]] = None
        self.last_report_path: Optional[Path] = None
        self.table_meta_by_label: Dict[str, Dict[str, object]] = {}
        self.last_log_message = "Esperando acciones..."
        self.show_heatmap = False
        self.mask_enabled = True
        self.plugin_root = Path(__file__).resolve().parents[1]
        self.json_dir = self.plugin_root / "core" / "json"
        self.runtime_config: Dict[str, object] = {}
        self.column_mapping: Dict[str, object] = {}
        self.cities_cache: Dict[str, object] = {}
        self.run_by_country: Dict[str, Dict[str, object]] = {}
        self.city_entries_by_country: Dict[str, List[Dict[str, str]]] = {}

        self.setWindowTitle("Herramienta de analisis general")
        self.setWindowFlags(
            self.windowFlags()
            | Qt.Window
            | Qt.WindowMinimizeButtonHint
            | Qt.WindowMaximizeButtonHint
            | Qt.WindowCloseButtonHint
        )
        self.setSizeGripEnabled(True)
        self.resize(1220, 820)
        self.setMinimumSize(980, 680)
        self.setObjectName("mainDialog")
        self._load_json_configuration()
        self._apply_styles()
        self._build()
        self._refresh_qgis_layers()
        self.add_log("Inicializando plugin de QGIS 'Herramienta de analisis general'...", "info")
        self.add_log("Interfaz nativa cargada sin QtWebEngine.", "success")
        self.add_log("Esperando conexion a base de datos externa de PostGIS...", "warning")

    # ------------------------------------------------------------------
    # UI construction helpers
    # ------------------------------------------------------------------
    def _read_json_file(self, filename: str) -> Dict[str, object]:
        path = self.json_dir / filename
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)

    def _cache_entries_for_dbname(self, dbname: str) -> List[Dict[str, str]]:
        if not isinstance(self.cities_cache, dict):
            return []

        cached = self.cities_cache.get(dbname, {})
        raw_entries = []

        if isinstance(cached, dict):
            for key in ("cities", "municipios", "municipalities", "items", "data"):
                value = cached.get(key)
                if isinstance(value, list):
                    raw_entries = value
                    break
        elif isinstance(cached, list):
            raw_entries = cached

        normalized_entries: List[Dict[str, str]] = []
        seen = set()

        for entry in raw_entries:
            if isinstance(entry, dict):
                city = str(
                    entry.get("ciudad")
                    or entry.get("municipio")
                    or entry.get("nivel_2")
                    or entry.get("city")
                    or entry.get("name")
                    or ""
                ).strip()
                dep = str(
                    entry.get("dep")
                    or entry.get("departamento")
                    or entry.get("nivel_1")
                    or entry.get("department")
                    or entry.get("state")
                    or ""
                ).strip()
            else:
                city = str(entry or "").strip()
                dep = ""

            if not city:
                continue

            key = (city.upper(), dep.upper())
            if key in seen:
                continue

            seen.add(key)
            normalized_entries.append({"ciudad": city, "dep": dep})

        normalized_entries.sort(key=lambda item: (item["dep"], item["ciudad"]))
        return normalized_entries

    def _load_json_configuration(self):
        try:
            self.runtime_config = self._read_json_file("config_Sincontra.json")
            self.column_mapping = self._read_json_file("column_mapping - DEF.json")
            self.cities_cache = self._read_json_file("cities_cache.json")
        except Exception:
            self.runtime_config = {}
            self.column_mapping = {}
            self.cities_cache = {}
            self.run_by_country = {}
            self.city_entries_by_country = {}
            return

        self.run_by_country = {}
        for run in self.runtime_config.get("runs", []):
            if not isinstance(run, dict):
                continue
            country = str(run.get("country") or "").strip()
            dbname = str(run.get("dbname") or "").strip()
            if country and dbname and country not in self.run_by_country:
                self.run_by_country[country] = run

        self.city_entries_by_country = {}
        for country, run in self.run_by_country.items():
            dbname = str(run.get("dbname") or "").strip()
            self.city_entries_by_country[country] = self._cache_entries_for_dbname(dbname)

    def _apply_styles(self):
        self.setStyleSheet(
            """
            QDialog#mainDialog { background: #f7f8f5; color: #111111; font-family: Segoe UI, Inter, Arial; }
            QFrame#sidebar { background: #ffffff; border-right: 1px solid #e5e7df; }
            QFrame#brand { border-bottom: 1px solid #e5e7df; }
            QLabel#brandTitle { color: #111111; font-size: 14px; font-weight: 900; letter-spacing: 1px; }
            QLabel#brandVersion { color: #667066; font-family: Consolas; font-size: 10px; }
            QPushButton#navButton { background: transparent; color: #3f463f; border: none; border-right: 3px solid transparent; padding: 13px 20px; text-align: left; font-size: 12px; font-weight: 750; }
            QPushButton#navButton:hover { background: #f1f5ef; color: #111111; }
            QPushButton#navButton[active="true"] { background: #ecfff0; color: #111111; border-right: 3px solid #111111; }
            QPushButton#connectShortcut { border: none; border-radius: 10px; padding: 10px 12px; font-weight: 900; font-size: 10px; color: #ffffff; background: #111111; }
            QPushButton#connectShortcut:hover { background: #2a2a2a; }
            QPushButton#connectShortcut[connected="true"] { color: white; background: #dc2626; }
            QPushButton#sideLink { text-align: left; background: transparent; color: #4b554b; border: none; border-radius: 8px; padding: 8px 10px; font-size: 12px; font-weight: 650; }
            QPushButton#sideLink:hover { background: #f1f5ef; color: #111111; }
            QFrame#workspace { background: #f7f8f5; }
            QFrame#topbar { background: #ffffff; border-bottom: 1px solid #e5e7df; }
            QLabel#topTitle { color: #111111; font-size: 13px; font-weight: 900; letter-spacing: 2px; text-transform: uppercase; }
            QLabel#topSubtitle { color: #667066; font-size: 12px; font-weight: 650; }
            QFrame#card { background: #ffffff; border: 1px solid #e1e5dc; border-radius: 12px; }
            QFrame#cardAccent { background: #ffffff; border: 1px solid #d8e5d8; border-radius: 12px; border-left: 5px solid #b7f7c2; }
            QLabel#cardTitle { color: #111111; font-size: 17px; font-weight: 850; }
            QLabel#fieldLabel { color: #465046; font-size: 11px; font-weight: 800; letter-spacing: .8px; text-transform: uppercase; }
            QLabel#hint { color: #667066; font-size: 11px; }
            QLabel#metric { color: #111111; font-family: Consolas; font-weight: 850; }
            QLineEdit, QComboBox, QDoubleSpinBox { background: #ffffff; border: 1px solid #d6ddd1; border-radius: 8px; padding: 7px 9px; color: #111111; font-family: Consolas; font-size: 12px; }
            QLineEdit:focus, QComboBox:focus, QDoubleSpinBox:focus { border: 1px solid #111111; }
            QComboBox::drop-down { border: none; width: 24px; }
            QComboBox QAbstractItemView { background: #ffffff; color: #111111; border: 1px solid #d6ddd1; selection-background-color: #c9f8d1; }
            QPushButton#primaryButton { background: #111111; color: #ffffff; border: none; border-radius: 10px; padding: 10px 14px; font-weight: 900; }
            QPushButton#primaryButton:hover { background: #2b2b2b; }
            QPushButton#secondaryButton { background: #ecfff0; color: #111111; border: 1px solid #b7f7c2; border-radius: 10px; padding: 9px 12px; font-weight: 850; }
            QPushButton#secondaryButton:hover { background: #d9ffe0; }
            QPushButton#ghostButton { background: #ffffff; color: #111111; border: 1px solid #d6ddd1; border-radius: 8px; padding: 7px 10px; font-weight: 750; }
            QPushButton#ghostButton:hover { background: #f1f5ef; border-color: #111111; }
            QPushButton#dangerGhost { background: transparent; color: #ffb4ab; border: 1px solid rgba(255,180,171,90); border-radius: 8px; padding: 6px 10px; font-weight: 700; }
            QPushButton#dangerButton { background: #dc2626; color: #fff7f7; border: none; border-radius: 10px; padding: 10px 14px; font-weight: 900; }
            QPushButton#dangerButton:hover { background: #ef4444; }
            QPushButton#dangerButton:disabled { background: rgba(127,29,29,120); color: rgba(255,255,255,120); }
            QTextEdit#logs { background: #ffffff; color: #313831; border: none; font-family: Consolas; font-size: 12px; }
            QScrollArea#pageScroll { background: #f7f8f5; border: none; }
            QScrollArea#pageScroll > QWidget > QWidget { background: #f7f8f5; }
            QScrollBar:vertical { background: #eef2eb; width: 12px; margin: 2px; border-radius: 6px; }
            QScrollBar::handle:vertical { background: #111111; min-height: 34px; border-radius: 6px; }
            QScrollBar::handle:vertical:hover { background: #2b2b2b; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; background: transparent; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
            QScrollBar:horizontal { background: #eef2eb; height: 12px; margin: 2px; border-radius: 6px; }
            QScrollBar::handle:horizontal { background: #111111; min-width: 34px; border-radius: 6px; }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; background: transparent; }
            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background: transparent; }
            QFrame#logsPanel { background: #ffffff; border-top: 1px solid #e5e7df; }
            QFrame#logsHeader { background: #fafbf8; border-bottom: 1px solid #e5e7df; }
            QFrame#statusbar { background: #ffffff; border-top: 1px solid #e5e7df; }
            QLabel#statusText { font-family: Consolas; font-size: 11px; font-weight: 800; }
            QLabel#tiny { color: #667066; font-size: 11px; }
            QProgressBar { background: #eef2eb; border: 1px solid #d6ddd1; border-radius: 5px; height: 8px; text-align: center; color: #111111; font-size: 9px; }
            QProgressBar::chunk { background: #111111; border-radius: 4px; }
            QCheckBox { color: #313831; font-size: 12px; spacing: 8px; }
            QCheckBox::indicator { width: 15px; height: 15px; border-radius: 4px; border: 1px solid #9ca89c; background: #ffffff; }
            QCheckBox::indicator:checked { background: #111111; border: 1px solid #111111; }
            """
        )

    def _build(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_sidebar())
        root.addWidget(self._build_workspace(), 1)

    def _build_sidebar(self) -> QWidget:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(256)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        brand = QFrame()
        brand.setObjectName("brand")
        brand_layout = QVBoxLayout(brand)
        brand_layout.setContentsMargins(24, 22, 24, 22)
        title = QLabel("HERRAMIENTA DE\nANALISIS GENERAL")
        title.setObjectName("brandTitle")
        title.setWordWrap(True)
        version = QLabel("v1.10-native")
        version.setObjectName("brandVersion")
        brand_layout.addWidget(title)
        brand_layout.addWidget(version)
        layout.addWidget(brand)

        nav = QVBoxLayout()
        nav.setContentsMargins(0, 24, 0, 0)
        nav.setSpacing(6)
        items = [("1 - Conexion", 0), ("2 - Capas", 1), ("3 - Analisis", 2)]
        for label, index in items:
            btn = QPushButton(label)
            btn.setObjectName("navButton")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _checked=False, idx=index: self.set_tab(idx))
            self.nav_buttons.append(btn)
            nav.addWidget(btn)
        nav.addStretch(1)
        layout.addLayout(nav, 1)

        footer = QFrame()
        footer_layout = QVBoxLayout(footer)
        footer_layout.setContentsMargins(16, 14, 16, 16)
        footer_layout.setSpacing(8)
        self.sidebar_connect_btn = QPushButton("CONNECT DATABASE")
        self.sidebar_connect_btn.setObjectName("connectShortcut")
        self.sidebar_connect_btn.setCursor(Qt.PointingHandCursor)
        self.sidebar_connect_btn.clicked.connect(self._sidebar_connect_clicked)
        footer_layout.addWidget(self.sidebar_connect_btn)

        cfg = QPushButton("Configuracion")
        cfg.setObjectName("sideLink")
        cfg.clicked.connect(lambda: self.set_tab(0))
        update_btn = QPushButton("Buscar actualizaciones")
        update_btn.setObjectName("sideLink")
        update_btn.clicked.connect(self._check_for_updates)
        help_btn = QPushButton("?   Ayuda")
        help_btn.setObjectName("sideLink")
        help_btn.clicked.connect(lambda: self.add_log("Ayuda: revise README.md del complemento o la documentacion oficial de QGIS.", "info"))
        theory_btn = QPushButton("DOC Fundamento teorico")
        theory_btn.setObjectName("sideLink")
        theory_btn.clicked.connect(self._open_theory_html)
        footer_layout.addWidget(cfg)
        footer_layout.addWidget(update_btn)
        footer_layout.addWidget(theory_btn)
        footer_layout.addWidget(help_btn)
        layout.addWidget(footer)
        return sidebar

    def _build_workspace(self) -> QWidget:
        workspace = QFrame()
        workspace.setObjectName("workspace")
        layout = QVBoxLayout(workspace)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(self._build_topbar())
        self.stack = QStackedWidget()
        self.stack.addWidget(self._page_connection())
        self.stack.addWidget(self._page_layers())
        self.stack.addWidget(self._page_analysis())
        layout.addWidget(self.stack, 1)
        layout.addWidget(self._build_logs(), 0)
        layout.addWidget(self._build_statusbar())
        self.set_tab(0)
        return workspace

    def _build_topbar(self) -> QWidget:
        top = QFrame()
        top.setObjectName("topbar")
        top.setFixedHeight(56)
        layout = QHBoxLayout(top)
        layout.setContentsMargins(24, 0, 20, 0)
        self.top_title = QLabel("ANALISIS DE PLACAS")
        self.top_title.setObjectName("topTitle")
        self.top_subtitle = QLabel("Conexion y seleccion")
        self.top_subtitle.setObjectName("topSubtitle")
        layout.addWidget(self.top_title)
        sep = QFrame()
        sep.setFixedWidth(1)
        sep.setFixedHeight(20)
        sep.setStyleSheet("background: rgba(58,73,74,120);")
        layout.addWidget(sep)
        layout.addWidget(self.top_subtitle)
        layout.addStretch(1)
        db_btn = QPushButton("DB")
        db_btn.setObjectName("ghostButton")
        db_btn.clicked.connect(lambda: self.set_tab(0))
        settings_btn = QPushButton("Config")
        settings_btn.setObjectName("ghostButton")
        settings_btn.clicked.connect(lambda: self.add_log("Preferencias todavia no implementadas.", "warning"))
        layout.addWidget(db_btn)
        layout.addWidget(settings_btn)
        return top

    def _build_logs(self) -> QWidget:
        panel = QFrame()
        panel.setObjectName("logsPanel")
        panel.setFixedHeight(145)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        header = QFrame()
        header.setObjectName("logsHeader")
        h = QHBoxLayout(header)
        h.setContentsMargins(16, 7, 16, 7)
        label = QLabel("Logs de sistema / consola de salida")
        label.setObjectName("tiny")
        label.setStyleSheet("font-family: Consolas; font-weight: 800; letter-spacing: 1px;")
        h.addWidget(label)
        h.addStretch(1)
        copy_btn = QPushButton("Copiar")
        copy_btn.setObjectName("ghostButton")
        copy_btn.clicked.connect(self._copy_logs)
        clear_btn = QPushButton("Limpiar")
        clear_btn.setObjectName("dangerGhost")
        clear_btn.clicked.connect(self._clear_logs)
        h.addWidget(copy_btn)
        h.addWidget(clear_btn)
        layout.addWidget(header)
        self.logs_text = QTextEdit()
        self.logs_text.setObjectName("logs")
        self.logs_text.setReadOnly(True)
        layout.addWidget(self.logs_text, 1)
        return panel

    def _build_statusbar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("statusbar")
        bar.setFixedHeight(40)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(14)
        self.status_dot = QLabel("*")
        self.status_dot.setStyleSheet("color: #ffb4ab; font-size: 15px;")
        self.status_text = QLabel("Base de datos: Desconectado")
        self.status_text.setObjectName("statusText")
        self.status_text.setStyleSheet("color: #ffb4ab;")
        layout.addWidget(self.status_dot)
        layout.addWidget(self.status_text)
        self.epsg_label = QLabel("EPSG:4326 (WGS 84)")
        self.epsg_label.setObjectName("tiny")
        layout.addWidget(self.epsg_label)
        layout.addStretch(1)
        self.progress = QProgressBar()
        self.progress.setFixedWidth(250)
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        layout.addWidget(self.progress)
        self.last_log = QLabel("LOG: Esperando acciones...")
        self.last_log.setObjectName("tiny")
        self.last_log.setMinimumWidth(260)
        layout.addWidget(self.last_log)
        self.memory_label = QLabel("Mem: 41.8 MB")
        self.memory_label.setObjectName("tiny")
        layout.addWidget(self.memory_label)
        return bar

    def _card(self, title: str, accent: bool = False) -> Tuple[QFrame, QVBoxLayout]:
        card = QFrame()
        card.setObjectName("cardAccent" if accent else "card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(12)
        t = QLabel(title)
        t.setObjectName("cardTitle")
        layout.addWidget(t)
        return card, layout

    def _label(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("fieldLabel")
        return label

    def _line(self, text: str = "", password: bool = False) -> QLineEdit:
        edit = QLineEdit(text)
        if password:
            edit.setEchoMode(QLineEdit.Password)
        return edit

    def _primary(self, text: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setObjectName("primaryButton")
        btn.setCursor(Qt.PointingHandCursor)
        return btn

    def _secondary(self, text: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setObjectName("secondaryButton")
        btn.setCursor(Qt.PointingHandCursor)
        return btn

    def _ghost(self, text: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setObjectName("ghostButton")
        btn.setCursor(Qt.PointingHandCursor)
        return btn

    def _page_wrapper(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setObjectName("pageScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        page = QWidget()
        page.setObjectName("pageContent")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(18)
        scroll.setWidget(page)
        scroll.main_layout = layout  # type: ignore[attr-defined]
        scroll.content_widget = page  # type: ignore[attr-defined]
        return scroll

    # ------------------------------------------------------------------
    # Pages
    # ------------------------------------------------------------------
    def _page_connection(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        db_card, db = self._card("â–£ ConfiguraciÃ³n de Base de Datos", True)
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(11)
        self.host_edit = self._line("localhost")
        self.port_edit = self._line("5432")
        self.database_edit = self._line("gis_db")
        self.user_edit = self._line("postgres")
        self.password_edit = self._line("********", password=True)
        fields = [
            ("Host", self.host_edit),
            ("Puerto", self.port_edit),
            ("Base de datos", self.database_edit),
            ("Usuario", self.user_edit),
            ("ContraseÃ±a", self.password_edit),
        ]
        for r, (name, widget) in enumerate(fields):
            grid.addWidget(self._label(name), r, 0)
            grid.addWidget(widget, r, 1)
        db.addLayout(grid)
        self.connection_status_label = QLabel("Estado: sin conexiÃ³n activa")
        self.connection_status_label.setObjectName("hint")
        db.addWidget(self.connection_status_label)
        btn_row = QHBoxLayout()
        self.connect_btn = self._primary("Conectar")
        self.connect_btn.clicked.connect(self._toggle_connection)
        btn_row.addWidget(self.connect_btn)
        btn_row.addStretch(1)
        db.addLayout(btn_row)

        geo_card, geo = self._card("âŒ– Filtro GeogrÃ¡fico / Municipio", True)
        geo_grid = QGridLayout()
        geo_grid.setHorizontalSpacing(14)
        geo_grid.setVerticalSpacing(11)
        self.schema_combo = QComboBox()
        self.schema_combo.setEditable(True)
        self.schema_combo.addItems(["public", "analisis_espacial", "catastro_nacional", "infraestructura"])
        self.country_combo = QComboBox()
        self.country_combo.addItems(list(self.CITIES.keys()))
        self.country_combo.currentTextChanged.connect(self._update_cities)
        self.city_combo = QComboBox()
        self.city_combo.setEditable(True)
        self._update_cities("Colombia")
        self.municipality_table_edit = self._line("municipios")
        self.municipality_geom_edit = self._line("geom")
        self.municipality_filter_edit = self._line("nombre")
        geo_fields = [
            ("Esquema", self.schema_combo),
            ("PaÃ­s", self.country_combo),
            ("Ciudad / municipio", self.city_combo),
            ("Tabla lÃ­mite", self.municipality_table_edit),
            ("Geom", self.municipality_geom_edit),
            ("Campo filtro", self.municipality_filter_edit),
        ]
        for r, (name, widget) in enumerate(geo_fields):
            geo_grid.addWidget(self._label(name), r, 0)
            geo_grid.addWidget(widget, r, 1)
        geo.addLayout(geo_grid)
        hint = QLabel("Carga el lÃ­mite municipal como mÃ¡scara de anÃ¡lisis en el proyecto QGIS.")
        hint.setObjectName("hint")
        geo.addWidget(hint)
        self.load_municipality_btn = self._secondary("Cargar municipio")
        self.load_municipality_btn.clicked.connect(self._load_municipality)
        geo.addWidget(self.load_municipality_btn)

        row.addWidget(db_card, 1)
        row.addWidget(geo_card, 1)
        layout.addLayout(row)

        info_card, info = self._card("Resumen del flujo", False)
        bullets = QLabel(
            "1. Configura la conexiÃ³n PostGIS.\n"
            "2. Carga el municipio o mÃ¡scara de trabajo.\n"
            "3. Agrega capas desde QGIS o desde PostGIS.\n"
            "4. Ejecuta el modelo de densidad en la pestaÃ±a AnÃ¡lisis."
        )
        bullets.setObjectName("hint")
        info.addWidget(bullets)
        theory_row = QHBoxLayout()
        self.theory_btn = self._secondary("Consultar fundamento teorico")
        self.theory_btn.clicked.connect(self._open_theory_html)
        theory_row.addWidget(self.theory_btn)
        theory_row.addStretch(1)
        info.addLayout(theory_row)
        layout.addWidget(info_card)
        layout.addStretch(1)
        return page

    def _page_connection(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        db_defaults = self.runtime_config.get("db", {}) if isinstance(self.runtime_config, dict) else {}
        countries_with_cache = sorted(
            country for country, entries in self.city_entries_by_country.items() if entries
        )
        countries_without_cache = sorted(
            country for country in self.run_by_country.keys() if country not in countries_with_cache
        )
        countries = countries_with_cache + countries_without_cache or sorted(self.CITIES.keys())

        selector_card, selector = self._card("Area de analisis", True)
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(11)

        self.country_combo = QComboBox()
        self.country_combo.addItems(countries)
        self.country_combo.currentTextChanged.connect(self._update_cities)
        self.department_combo = QComboBox()
        self.department_combo.setEditable(False)
        self.department_combo.currentIndexChanged.connect(lambda _index: self._update_municipalities())
        self.city_combo = QComboBox()
        self.city_combo.setEditable(False)
        self.city_combo.currentIndexChanged.connect(lambda _index: (self._update_resolved_config_label(), self._update_analysis_summary()))
        self.host_edit = self._line(str(db_defaults.get("host") or "localhost"))
        self.port_edit = self._line(str(db_defaults.get("port") or "5432"))
        self.database_edit = self._line("")
        self.schema_combo = QComboBox()
        self.schema_combo.setEditable(True)
        self.schema_combo.addItems(["administrativo", "public"])
        self.host_edit.textChanged.connect(lambda _text: self._update_resolved_config_label())
        self.port_edit.textChanged.connect(lambda _text: self._update_resolved_config_label())
        self.database_edit.textChanged.connect(lambda _text: self._update_resolved_config_label())
        self.schema_combo.currentTextChanged.connect(lambda _text: self._update_resolved_config_label())
        self.user_edit = self._line(str(db_defaults.get("user") or "postgres"))
        self.password_edit = self._line("", password=True)
        self.password_edit.setPlaceholderText("Contrasena PostgreSQL")

        fields = [
            ("Pais", self.country_combo),
            ("Departamento / nivel 1", self.department_combo),
            ("Municipio / nivel 2", self.city_combo),
            ("Host PostgreSQL", self.host_edit),
            ("Puerto", self.port_edit),
            ("Base de datos", self.database_edit),
            ("Schema", self.schema_combo),
            ("Usuario", self.user_edit),
            ("Contrasena", self.password_edit),
        ]
        for r, (name, widget) in enumerate(fields):
            grid.addWidget(self._label(name), r, 0)
            grid.addWidget(widget, r, 1)
        selector.addLayout(grid)

        self.pg_schema_combo = QComboBox()
        self.pg_table_combo = QComboBox()
        self.pg_geom_edit = self._line("geom")
        self.municipality_table_edit = self._line("municipio")
        self.municipality_geom_edit = self._line("geom")
        self.municipality_filter_edit = self._line("nom_mun")

        self.connection_status_label = QLabel("Estado: sin conexion activa")
        self.connection_status_label.setObjectName("hint")
        selector.addWidget(self.connection_status_label)
        btn_row = QHBoxLayout()
        self.connect_btn = self._primary("Conectar con seleccion")
        self.connect_btn.clicked.connect(self._toggle_connection)
        btn_row.addWidget(self.connect_btn)
        self.load_municipality_btn = self._secondary("Cargar municipio")
        self.load_municipality_btn.clicked.connect(self._load_municipality)
        btn_row.addWidget(self.load_municipality_btn)
        btn_row.addStretch(1)
        selector.addLayout(btn_row)

        resolver_card, resolver = self._card("Configuracion automatica", False)
        self.resolved_config_label = QLabel("")
        self.resolved_config_label.setObjectName("hint")
        self.resolved_config_label.setWordWrap(True)
        resolver.addWidget(self.resolved_config_label)
        hint = QLabel("La base de datos y las tablas administrativas se resuelven desde core/json.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        resolver.addWidget(hint)
        self.manual_admin_mask_label = QLabel("Delimitacion administrativa local: ninguna")
        self.manual_admin_mask_label.setObjectName("hint")
        self.manual_admin_mask_label.setWordWrap(True)
        resolver.addWidget(self.manual_admin_mask_label)
        mask_btn_row = QHBoxLayout()
        self.load_admin_mask_file_btn = self._secondary("Importar delimitacion administrativa")
        self.load_admin_mask_file_btn.clicked.connect(self._load_admin_mask_from_file)
        mask_btn_row.addWidget(self.load_admin_mask_file_btn)
        self.clear_admin_mask_btn = self._ghost("Quitar delimitacion local")
        self.clear_admin_mask_btn.clicked.connect(self._clear_manual_admin_mask)
        mask_btn_row.addWidget(self.clear_admin_mask_btn)
        resolver.addLayout(mask_btn_row)
        self.manual_urban_footprint_label = QLabel("Huella urbana local: ninguna")
        self.manual_urban_footprint_label.setObjectName("hint")
        self.manual_urban_footprint_label.setWordWrap(True)
        resolver.addWidget(self.manual_urban_footprint_label)
        urban_btn_row = QHBoxLayout()
        self.load_urban_footprint_file_btn = self._secondary("Importar huella urbana")
        self.load_urban_footprint_file_btn.clicked.connect(self._load_urban_footprint_from_file)
        urban_btn_row.addWidget(self.load_urban_footprint_file_btn)
        self.clear_urban_footprint_btn = self._ghost("Quitar huella urbana")
        self.clear_urban_footprint_btn.clicked.connect(self._clear_manual_urban_footprint)
        urban_btn_row.addWidget(self.clear_urban_footprint_btn)
        resolver.addLayout(urban_btn_row)
        self.manual_constructions_label = QLabel("Construcciones locales: ninguna")
        self.manual_constructions_label.setObjectName("hint")
        self.manual_constructions_label.setWordWrap(True)
        resolver.addWidget(self.manual_constructions_label)
        constructions_btn_row = QHBoxLayout()
        self.load_constructions_file_btn = self._secondary("Importar construcciones")
        self.load_constructions_file_btn.clicked.connect(self._load_constructions_from_file)
        constructions_btn_row.addWidget(self.load_constructions_file_btn)
        self.clear_constructions_btn = self._ghost("Quitar construcciones")
        self.clear_constructions_btn.clicked.connect(self._clear_manual_constructions)
        constructions_btn_row.addWidget(self.clear_constructions_btn)
        resolver.addLayout(constructions_btn_row)
        local_hint = QLabel(
            "Flujo manual: importe delimitacion administrativa, huella urbana y construcciones. "
            "La mascara sera la interseccion administracion/huella urbana, y las construcciones locales alimentaran el KDE ponderado por area."
        )
        local_hint.setObjectName("hint")
        local_hint.setWordWrap(True)
        resolver.addWidget(local_hint)

        row.addWidget(selector_card, 1)
        row.addWidget(resolver_card, 1)
        layout.addLayout(row)

        info_card, info = self._card("Resumen del flujo", False)
        bullets = QLabel(
            "1. Flujo servidor: selecciona pais, departamento, municipio y conecta PostgreSQL.\n"
            "2. Flujo manual: importa delimitacion administrativa, huella urbana y construcciones.\n"
            "3. Confirma la capa de puntos en el panel de capas.\n"
            "4. Ejecuta el analisis de densidad."
        )
        bullets.setObjectName("hint")
        info.addWidget(bullets)
        theory_row = QHBoxLayout()
        self.theory_btn = self._secondary("Consultar fundamento teorico")
        self.theory_btn.clicked.connect(self._open_theory_html)
        theory_row.addWidget(self.theory_btn)
        theory_row.addStretch(1)
        info.addLayout(theory_row)
        layout.addWidget(info_card)
        layout.addStretch(1)

        if countries:
            self._update_cities(countries[0])
        return page

    def _page_layers(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        left_card, left = self._card("â–£ Capas activas en QGIS", True)
        qgis_grid = QGridLayout()
        qgis_grid.setVerticalSpacing(11)
        self.qgis_layer_combo = QComboBox()
        self.qgis_layer_combo.currentTextChanged.connect(self._on_qgis_layer_changed)
        self.refresh_layers_btn = self._ghost("Actualizar lista")
        self.refresh_layers_btn.clicked.connect(self._refresh_qgis_layers)
        self.confirm_analysis_layer_btn = self._secondary("Confirmar capa a analizar")
        self.confirm_analysis_layer_btn.clicked.connect(self._confirm_analysis_layer_from_layers_panel)
        qgis_grid.addWidget(self._label("Capa vectorial"), 0, 0)
        qgis_grid.addWidget(self.qgis_layer_combo, 0, 1)
        qgis_grid.addWidget(self.refresh_layers_btn, 1, 1)
        left.addLayout(qgis_grid)
        left.addWidget(self.confirm_analysis_layer_btn)
        self.layer_info_label = QLabel("Sin capa seleccionada")
        self.layer_info_label.setObjectName("hint")
        left.addWidget(self.layer_info_label)
        self.confirmed_layer_label = QLabel("Capa confirmada para analisis: ninguna")
        self.confirmed_layer_label.setObjectName("hint")
        self.confirmed_layer_label.setWordWrap(True)
        left.addWidget(self.confirmed_layer_label)
        self.mask_checkbox = QCheckBox("Usar mÃ¡scara municipal para recortar el anÃ¡lisis")
        self.mask_checkbox.setChecked(True)
        self.mask_checkbox.stateChanged.connect(lambda state: self._set_mask_enabled(state == Qt.Checked))
        left.addWidget(self.mask_checkbox)

        postgis_card, pg = self._card("â–£ Cargar capa desde PostGIS", True)
        pg_grid = QGridLayout()
        pg_grid.setVerticalSpacing(11)
        self.pg_schema_combo = QComboBox()
        self.pg_schema_combo.setEditable(True)
        self.pg_schema_combo.addItems(["public", "analisis_espacial", "catastro_nacional"])
        self.pg_schema_combo.currentTextChanged.connect(self._schema_changed)
        self.pg_table_combo = QComboBox()
        self.pg_table_combo.setEditable(True)
        self.pg_table_combo.addItems(["tbl_placas_georef", "manzanas_catastrales_v1", "sitios_interes"])
        self.pg_geom_edit = self._line("geom")
        pg_grid.addWidget(self._label("Esquema"), 0, 0)
        pg_grid.addWidget(self.pg_schema_combo, 0, 1)
        pg_grid.addWidget(self._label("Tabla"), 1, 0)
        pg_grid.addWidget(self.pg_table_combo, 1, 1)
        pg_grid.addWidget(self._label("Geom"), 2, 0)
        pg_grid.addWidget(self.pg_geom_edit, 2, 1)
        pg.addLayout(pg_grid)
        self.add_pg_layer_btn = self._secondary("Agregar al proyecto QGIS")
        self.add_pg_layer_btn.clicked.connect(self._add_postgis_layer)
        pg.addWidget(self.add_pg_layer_btn)
        self.pg_hint = QLabel("Al conectar la base de datos, esta lista se actualiza con geometry_columns.")
        self.pg_hint.setObjectName("hint")
        pg.addWidget(self.pg_hint)

        row.addWidget(left_card, 1)
        row.addWidget(postgis_card, 1)
        layout.addLayout(row)

        map_card, map_layout = self._card("â–£ Vista previa GIS", False)
        self.map_preview = MapPreviewWidget()
        map_layout.addWidget(self.map_preview, 1)
        map_footer = QHBoxLayout()
        self.heatmap_toggle_btn = self._ghost("Alternar heatmap")
        self.heatmap_toggle_btn.clicked.connect(self._toggle_heatmap)
        map_footer.addWidget(self.heatmap_toggle_btn)
        map_footer.addStretch(1)
        map_footer.addWidget(QLabel("Grid â€¢ MÃ¡scara â€¢ Puntos â€¢ Kernel preview"))
        map_layout.addLayout(map_footer)
        layout.addWidget(map_card, 1)
        return page

    def _page_layers(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        left_card, left = self._card("Capas activas en QGIS", True)
        qgis_grid = QGridLayout()
        qgis_grid.setVerticalSpacing(11)
        self.qgis_layer_combo = QComboBox()
        self.qgis_layer_combo.currentTextChanged.connect(self._on_qgis_layer_changed)
        self.refresh_layers_btn = self._ghost("Actualizar lista")
        self.refresh_layers_btn.clicked.connect(self._refresh_qgis_layers)
        self.load_vector_file_btn = self._secondary("Cargar archivo vectorial")
        self.load_vector_file_btn.clicked.connect(self._load_vector_layer_from_file)
        self.confirm_analysis_layer_btn = self._primary("Confirmar capa a analizar")
        self.confirm_analysis_layer_btn.clicked.connect(self._confirm_analysis_layer_from_layers_panel)
        qgis_grid.addWidget(self._label("Capa vectorial"), 0, 0)
        qgis_grid.addWidget(self.qgis_layer_combo, 0, 1)
        qgis_grid.addWidget(self.refresh_layers_btn, 1, 1)
        qgis_grid.addWidget(self.load_vector_file_btn, 2, 1)
        left.addLayout(qgis_grid)
        left.addWidget(self.confirm_analysis_layer_btn)
        self.layer_info_label = QLabel("Sin capa seleccionada")
        self.layer_info_label.setObjectName("hint")
        left.addWidget(self.layer_info_label)
        self.confirmed_layer_label = QLabel("Capa confirmada para analisis: ninguna")
        self.confirmed_layer_label.setObjectName("hint")
        self.confirmed_layer_label.setWordWrap(True)
        left.addWidget(self.confirmed_layer_label)
        self.mask_checkbox = QCheckBox("Usar ciudad seleccionada como mascara de analisis")
        self.mask_checkbox.setChecked(True)
        self.mask_checkbox.stateChanged.connect(lambda state: self._set_mask_enabled(state == Qt.Checked))
        left.addWidget(self.mask_checkbox)

        auto_card, auto = self._card("Carga automatica", False)
        self.auto_layer_hint = QLabel("El analisis usara la capa vectorial de puntos seleccionada en el panel de analisis.")
        self.auto_layer_hint.setObjectName("hint")
        self.auto_layer_hint.setWordWrap(True)
        auto.addWidget(self.auto_layer_hint)
        self.auto_load_city_btn = self._secondary("Cargar municipio seleccionado")
        self.auto_load_city_btn.clicked.connect(self._load_municipality)
        auto.addWidget(self.auto_load_city_btn)

        row.addWidget(left_card, 1)
        row.addWidget(auto_card, 1)
        layout.addLayout(row)

        map_card, map_layout = self._card("Vista previa GIS", False)
        self.map_preview = MapPreviewWidget()
        map_layout.addWidget(self.map_preview, 1)
        map_footer = QHBoxLayout()
        self.heatmap_toggle_btn = self._ghost("Alternar heatmap")
        self.heatmap_toggle_btn.clicked.connect(self._toggle_heatmap)
        map_footer.addWidget(self.heatmap_toggle_btn)
        map_footer.addStretch(1)
        map_footer.addWidget(QLabel("Grid - Mascara - Puntos - Kernel preview"))
        map_layout.addLayout(map_footer)
        layout.addWidget(map_card, 1)
        return page

    def _page_analysis(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        config_card, config = self._card("â–£ ParÃ¡metros del Modelo", True)
        grid = QGridLayout()
        grid.setVerticalSpacing(11)
        self.analysis_layer_combo = QComboBox()
        self.analysis_layer_combo.currentTextChanged.connect(
            lambda text: (self._on_qgis_layer_changed(text), self._update_analysis_summary())
        )
        self.analysis_method_combo = QComboBox()
        self.analysis_method_combo.addItems([
            "kde Â· Kernel Density",
            "dbscan Â· Cluster DBSCAN",
            "nearest_neighbor Â· Vecino mÃ¡s cercano",
            "getis_ord Â· Hot Spots Getis-Ord",
        ])
        self.radius_spin = QDoubleSpinBox()
        self.radius_spin.setRange(1, 999999)
        self.radius_spin.setValue(500)
        self.radius_spin.setSuffix(" m")
        self.pixel_spin = QDoubleSpinBox()
        self.pixel_spin.setRange(1, 999999)
        self.pixel_spin.setValue(50)
        self.pixel_spin.setSuffix(" m")
        self.weight_edit = self._line("")
        rows = [
            ("Capa de entrada", self.analysis_layer_combo),
            ("MÃ©todo", self.analysis_method_combo),
            ("Radio", self.radius_spin),
            ("TamaÃ±o pixel", self.pixel_spin),
            ("Campo peso", self.weight_edit),
        ]
        for r, (name, widget) in enumerate(rows):
            grid.addWidget(self._label(name), r, 0)
            grid.addWidget(widget, r, 1)
        config.addLayout(grid)
        self.run_analysis_btn = self._primary("Ejecutar AnÃ¡lisis")
        self.run_analysis_btn.clicked.connect(self._run_analysis)
        config.addWidget(self.run_analysis_btn)
        self.analysis_hint = QLabel("El KDE nativo se ejecuta si QGIS Processing lo tiene disponible; si no, se genera una capa resumen segura.")
        self.analysis_hint.setObjectName("hint")
        self.analysis_hint.setWordWrap(True)
        config.addWidget(self.analysis_hint)

        preview_card, preview = self._card("â–£ Modelo de Densidad Kernel", False)
        self.analysis_preview = MapPreviewWidget()
        self.analysis_preview.set_heatmap(True)
        preview.addWidget(self.analysis_preview, 1)
        metrics = QHBoxLayout()
        self.metric_method = QLabel("METHOD: KDE")
        self.metric_method.setObjectName("metric")
        self.metric_radius = QLabel("RADIUS: 500 m")
        self.metric_radius.setObjectName("metric")
        self.metric_pixel = QLabel("PIXEL: 50 m")
        self.metric_pixel.setObjectName("metric")
        metrics.addWidget(self.metric_method)
        metrics.addWidget(self.metric_radius)
        metrics.addWidget(self.metric_pixel)
        metrics.addStretch(1)
        preview.addLayout(metrics)

        row.addWidget(config_card, 1)
        row.addWidget(preview_card, 1)
        layout.addLayout(row, 1)
        return page

    # ------------------------------------------------------------------
    # UI state
    # ------------------------------------------------------------------
    def set_tab(self, index: int):
        self.active_tab = index
        self.stack.setCurrentIndex(index)
        subtitles = ["Conexion y seleccion", "Capas", "Analisis de densidad"]
        self.top_subtitle.setText(subtitles[index])
        for i, btn in enumerate(self.nav_buttons):
            btn.setProperty("active", "true" if i == index else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
        if index in (1, 2):
            self._refresh_qgis_layers(silent=True)

    def _set_connection_state(self, connected: bool):
        self.is_connected = connected
        self.connect_btn.setText("Desconectar" if connected else "Conectar")
        self.sidebar_connect_btn.setText("DISCONNECT DATABASE" if connected else "CONNECT DATABASE")
        self.sidebar_connect_btn.setProperty("connected", "true" if connected else "false")
        self.sidebar_connect_btn.style().unpolish(self.sidebar_connect_btn)
        self.sidebar_connect_btn.style().polish(self.sidebar_connect_btn)
        self.status_dot.setStyleSheet(f"color: {'#111111' if connected else '#dc2626'}; font-size: 15px;")
        self.status_text.setText(f"Base de datos: {'Conectado' if connected else 'Desconectado'}")
        self.status_text.setStyleSheet(f"color: {'#111111' if connected else '#dc2626'};")
        self.connection_status_label.setText("Estado: conexion activa" if connected else "Estado: sin conexion activa")

    def _set_processing_state(self, processing: bool, percent: int = 0):
        if processing:
            self.status_dot.setStyleSheet("color: #b45309; font-size: 15px;")
            self.status_text.setText("Engine: Processing")
            self.status_text.setStyleSheet("color: #b45309;")
        else:
            self._set_connection_state(self.is_connected)
        self.progress.setValue(percent)

    def _update_cities(self, country: str):
        if not hasattr(self, "city_combo"):
            return
        resolved_dbname = self._resolved_dbname_from_country()
        if hasattr(self, "database_edit") and resolved_dbname:
            self.database_edit.blockSignals(True)
            self.database_edit.setText(resolved_dbname)
            self.database_edit.blockSignals(False)
        if hasattr(self, "schema_combo"):
            mapping = self.column_mapping.get(resolved_dbname, {}) if isinstance(self.column_mapping, dict) else {}
            admin = mapping.get("administrativo", {}) if isinstance(mapping, dict) else {}
            schema = str(admin.get("schema") or "").strip() if isinstance(admin, dict) else ""
            if schema:
                if self.schema_combo.findText(schema) < 0:
                    self.schema_combo.addItem(schema)
                self.schema_combo.blockSignals(True)
                self.schema_combo.setCurrentText(schema)
                self.schema_combo.blockSignals(False)
        entries = self.city_entries_by_country.get(country, [])
        if hasattr(self, "department_combo"):
            self.department_combo.blockSignals(True)
            self.department_combo.clear()
            if entries:
                departments = sorted({entry.get("dep", "").strip() for entry in entries if entry.get("dep", "").strip()})
                self.department_combo.addItems(departments or [""])
            else:
                self.department_combo.addItem("Sin datos en cities_cache")
            self.department_combo.blockSignals(False)
        self._update_municipalities()
        self._update_resolved_config_label()
        self._update_analysis_summary()

    def _update_municipalities(self):
        if not hasattr(self, "city_combo"):
            return
        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        selected_dep = self.department_combo.currentText().strip() if hasattr(self, "department_combo") else ""
        self.city_combo.clear()
        entries = self.city_entries_by_country.get(country, [])
        if entries:
            for entry in entries:
                city = entry.get("ciudad", "")
                dep = entry.get("dep", "")
                if selected_dep and dep != selected_dep:
                    continue
                self.city_combo.addItem(city, entry)
        else:
            fallback_cities = self.CITIES.get(country, [])
            if fallback_cities:
                self.city_combo.addItems(fallback_cities)
            else:
                self.city_combo.addItem("Sin municipios en cities_cache")
        self._update_resolved_config_label()
        self._update_analysis_summary()

    def _selected_city_entry(self) -> Dict[str, str]:
        if not hasattr(self, "city_combo"):
            return {}
        data = self.city_combo.currentData()
        if isinstance(data, dict):
            return data
        return {"ciudad": self.city_combo.currentText().strip(), "dep": ""}

    def _selected_city_name(self) -> str:
        city = self._selected_city_entry().get("ciudad", "").strip()
        if city == "Sin municipios en cities_cache":
            return ""
        return city

    def _selected_department_name(self) -> str:
        dep = self._selected_city_entry().get("dep", "").strip()
        if dep:
            return dep
        if hasattr(self, "department_combo"):
            current = self.department_combo.currentText().strip()
            if current != "Sin datos en cities_cache":
                return current
        return ""

    def _selected_run(self) -> Dict[str, object]:
        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        return self.run_by_country.get(country, {})

    def _resolved_dbname_from_country(self) -> str:
        return str(self._selected_run().get("dbname") or "").strip()

    def _selected_dbname(self) -> str:
        if hasattr(self, "database_edit"):
            typed_dbname = self.database_edit.text().strip()
            if typed_dbname:
                return typed_dbname
        return self._resolved_dbname_from_country()

    def _selected_schema_name(self) -> str:
        if hasattr(self, "schema_combo"):
            schema = self.schema_combo.currentText().strip()
            if schema:
                return schema
        return "administrativo"

    def _has_valid_admin_selection(self) -> bool:
        if self._has_manual_admin_mask():
            return (
                self._manual_search_mask_gdf() is not None
                and self._has_manual_constructions()
                and self._manual_constructions_intersect_context()
            )
        return bool(self._selected_department_name() and self._selected_city_name())

    def _has_manual_admin_mask(self) -> bool:
        return bool(self.manual_admin_mask_layer_id)

    def _has_manual_urban_footprint(self) -> bool:
        return bool(self.manual_urban_footprint_layer_id)

    def _has_manual_constructions(self) -> bool:
        return bool(self.manual_constructions_layer_id)

    def _manual_layer_to_gdf(self, layer_id: str, cache_attr: str):
        cached = getattr(self, cache_attr, None)
        if cached is not None and not getattr(cached, "empty", True):
            return cached
        layer = self._layer_from_id(layer_id)
        if not isinstance(layer, QgsVectorLayer):
            raise ValueError("La capa manual ya no esta disponible en el proyecto QGIS.")
        gdf = qgis_layer_to_geodataframe(layer, force_points=False)
        setattr(self, cache_attr, gdf)
        return gdf

    def _manual_layer_to_gdf_filtered(self, layer_id: str, cache_attr: str, filter_gdf):
        cached = getattr(self, cache_attr, None)
        if cached is not None and not getattr(cached, "empty", True):
            return cached
        layer = self._layer_from_id(layer_id)
        if not isinstance(layer, QgsVectorLayer):
            raise ValueError("La capa manual ya no esta disponible en el proyecto QGIS.")
        gdf = qgis_layer_to_geodataframe(layer, force_points=False, filter_gdf=filter_gdf)
        setattr(self, cache_attr, gdf)
        return gdf

    def _manual_search_mask_gdf(self):
        if not self._has_manual_admin_mask() or not self._has_manual_urban_footprint():
            return None
        admin = self._manual_layer_to_gdf(self.manual_admin_mask_layer_id, "manual_admin_mask_gdf")
        urban = self._manual_layer_to_gdf_filtered(
            self.manual_urban_footprint_layer_id,
            "manual_urban_footprint_gdf",
            admin,
        )
        if admin is None or urban is None or getattr(admin, "empty", True) or getattr(urban, "empty", True):
            return None
        try:
            urban_in_admin_crs = urban.to_crs(admin.crs) if getattr(admin, "crs", None) is not None else urban
            admin_union = admin.geometry.unary_union
            urban_union = urban_in_admin_crs.geometry.unary_union
            intersection = admin_union.intersection(urban_union)
            if intersection is None or intersection.is_empty:
                return None
            import geopandas as gpd

            return gpd.GeoDataFrame(
                [{"source": "interseccion_admin_huella_urbana"}],
                geometry=[intersection],
                crs=admin.crs,
            )
        except Exception as exc:
            self.add_log("No se pudo calcular la interseccion administracion/huella urbana: " + str(exc), "error")
            return None

    def _selected_admin_mask_gdf(self):
        if self._has_manual_admin_mask():
            return self._manual_search_mask_gdf()
        return None

    def _selected_urban_footprint_gdf(self):
        if self._has_manual_urban_footprint():
            admin = self._manual_layer_to_gdf(self.manual_admin_mask_layer_id, "manual_admin_mask_gdf") if self._has_manual_admin_mask() else None
            return self._manual_layer_to_gdf_filtered(
                self.manual_urban_footprint_layer_id,
                "manual_urban_footprint_gdf",
                admin,
            )
        return None

    def _selected_constructions_gdf(self):
        if self._has_manual_constructions():
            return self._manual_layer_to_gdf_filtered(
                self.manual_constructions_layer_id,
                "manual_constructions_gdf",
                self._selected_admin_mask_gdf(),
            )
        return None

    def _gdf_intersects_gdf(self, source_gdf, target_gdf) -> bool:
        if source_gdf is None or target_gdf is None:
            return False
        if getattr(source_gdf, "empty", True) or getattr(target_gdf, "empty", True):
            return False
        try:
            source = source_gdf.to_crs(target_gdf.crs) if getattr(target_gdf, "crs", None) is not None else source_gdf
            target_union = target_gdf.geometry.unary_union
            return bool(source.geometry.intersects(target_union).any())
        except Exception:
            return False

    def _manual_constructions_intersect_context(self) -> bool:
        if not self._has_manual_constructions():
            return False
        try:
            constructions = self._selected_constructions_gdf()
            admin = self._manual_layer_to_gdf(self.manual_admin_mask_layer_id, "manual_admin_mask_gdf")
            urban = self._manual_layer_to_gdf(self.manual_urban_footprint_layer_id, "manual_urban_footprint_gdf")
            return (
                self._gdf_intersects_gdf(constructions, admin)
                and self._gdf_intersects_gdf(constructions, urban)
            )
        except Exception as exc:
            self.add_log("No se pudo validar la interseccion de construcciones: " + str(exc), "error")
            return False

    def _update_manual_admin_mask_label(self):
        if not hasattr(self, "manual_admin_mask_label"):
            return
        if self._has_manual_admin_mask():
            layer = self._layer_from_id(self.manual_admin_mask_layer_id)
            feature_count = layer.featureCount() if isinstance(layer, QgsVectorLayer) else 0
            self.manual_admin_mask_label.setText(
                f"Delimitacion administrativa local: {self.manual_admin_mask_name} ({feature_count:,} entidad(es))"
            )
        else:
            self.manual_admin_mask_label.setText("Delimitacion administrativa local: ninguna")

    def _update_manual_urban_footprint_label(self):
        if not hasattr(self, "manual_urban_footprint_label"):
            return
        if self._has_manual_urban_footprint():
            layer = self._layer_from_id(self.manual_urban_footprint_layer_id)
            feature_count = layer.featureCount() if isinstance(layer, QgsVectorLayer) else 0
            status = ""
            if self._has_manual_admin_mask():
                status = " - interseccion con delimitacion: se valida al ejecutar"
            self.manual_urban_footprint_label.setText(
                f"Huella urbana local: {self.manual_urban_footprint_name} ({feature_count:,} entidad(es)){status}"
            )
        else:
            self.manual_urban_footprint_label.setText("Huella urbana local: ninguna")

    def _update_manual_constructions_label(self):
        if not hasattr(self, "manual_constructions_label"):
            return
        if self._has_manual_constructions():
            layer = self._layer_from_id(self.manual_constructions_layer_id)
            feature_count = layer.featureCount() if isinstance(layer, QgsVectorLayer) else 0
            checks = []
            if self._has_manual_admin_mask():
                checks.append("interseccion con delimitacion: se valida al ejecutar")
            if self._has_manual_urban_footprint():
                checks.append("interseccion con huella: se valida al ejecutar")
            status = " - " + " / ".join(checks) if checks else ""
            self.manual_constructions_label.setText(
                f"Construcciones locales: {self.manual_constructions_name} ({feature_count:,} entidad(es)){status}"
            )
        else:
            self.manual_constructions_label.setText("Construcciones locales: ninguna")

    def _selected_mapping(self) -> Dict[str, object]:
        dbname = self._selected_dbname()
        mapping = self.column_mapping.get(dbname, {}) if isinstance(self.column_mapping, dict) else {}
        if not mapping:
            resolved_dbname = self._resolved_dbname_from_country()
            mapping = self.column_mapping.get(resolved_dbname, {}) if isinstance(self.column_mapping, dict) else {}
        return mapping if isinstance(mapping, dict) else {}

    def _admin_municipality_config(self) -> Tuple[str, str, str, str, str]:
        mapping = self._selected_mapping()
        admin = mapping.get("administrativo", {}) if isinstance(mapping, dict) else {}
        municipio = admin.get("municipio", {}) if isinstance(admin, dict) else {}
        if not isinstance(municipio, dict):
            municipio = {}
        schema = self._selected_schema_name() or str(admin.get("schema") or "administrativo")
        table = str(municipio.get("table") or "municipio")
        geom = str(municipio.get("geom_column") or "geom")
        city_col = str(municipio.get("city_column") or "nom_mun")
        dep_col = str(municipio.get("department_column") or "nom_dep")
        return schema, table, geom, city_col, dep_col

    def _runtime_mapping_path_for_analysis(self) -> str:
        original_path = self.json_dir / "column_mapping - DEF.json"
        dbname = self._selected_dbname()
        resolved_dbname = self._resolved_dbname_from_country()
        schema = self._selected_schema_name()

        if not dbname and not schema:
            return str(original_path)

        runtime_mapping = json.loads(json.dumps(self.column_mapping))
        source_key = dbname if dbname in runtime_mapping else resolved_dbname
        if not source_key or source_key not in runtime_mapping:
            return str(original_path)

        if dbname and dbname not in runtime_mapping:
            runtime_mapping[dbname] = json.loads(json.dumps(runtime_mapping[source_key]))
            source_key = dbname

        db_mapping = runtime_mapping.get(source_key, {})
        if isinstance(db_mapping, dict):
            admin = db_mapping.get("administrativo")
            if isinstance(admin, dict) and schema:
                admin["schema"] = schema

        runtime_dir = self.plugin_root / "reports" / "runtime"
        runtime_dir.mkdir(parents=True, exist_ok=True)
        runtime_path = runtime_dir / "column_mapping_runtime.json"
        runtime_path.write_text(
            json.dumps(runtime_mapping, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return str(runtime_path)

    def _update_resolved_config_label(self):
        if not hasattr(self, "resolved_config_label"):
            return
        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        city = self._selected_city_name()
        dep = self._selected_department_name()
        resolved_dbname = self._resolved_dbname_from_country()
        if hasattr(self, "database_edit") and not self.database_edit.text().strip() and resolved_dbname:
            self.database_edit.blockSignals(True)
            self.database_edit.setText(resolved_dbname)
            self.database_edit.blockSignals(False)
        dbname = self._selected_dbname() or "sin configurar"
        run = self._selected_run()
        cell_size = run.get("cell_size", "sin configurar") if isinstance(run, dict) else "sin configurar"
        admin_schema, admin_table, admin_geom, city_col, dep_col = self._admin_municipality_config()
        mask_source = (
            f"archivo local ({self.manual_admin_mask_name}) + huella urbana ({self.manual_urban_footprint_name}) + construcciones ({self.manual_constructions_name})"
            if self._has_manual_admin_mask()
            else f"{admin_schema}.{admin_table} ({admin_geom}, {city_col}, {dep_col})"
        )
        db_line = (
            "No requerida para mascara manual"
            if self._has_manual_admin_mask()
            else dbname
        )
        self.resolved_config_label.setText(
            f"Pais: {country or 'sin seleccionar'}\n"
            f"Departamento / nivel 1: {dep or 'sin seleccionar'}\n"
            f"Municipio / nivel 2: {city or 'sin seleccionar'}\n"
            f"Base: {db_line}\n"
            f"Host: {self.host_edit.text().strip() if hasattr(self, 'host_edit') else 'localhost'}\n"
            f"Mascara administrativa: {mask_source}\n"
            f"Tamano de celda: {cell_size} m"
        )
        self._update_manual_admin_mask_label()
        self._update_manual_urban_footprint_label()

    def _set_mask_enabled(self, enabled: bool):
        self.mask_enabled = enabled
        if hasattr(self, "map_preview"):
            self.map_preview.set_mask_enabled(enabled)
        if hasattr(self, "analysis_preview"):
            self.analysis_preview.set_mask_enabled(enabled)
        self.add_log(f"Mascara municipal {'activada' if enabled else 'desactivada'}.", "info")

    def _toggle_heatmap(self):
        self.show_heatmap = not self.show_heatmap
        self.map_preview.set_heatmap(self.show_heatmap)
        self.add_log(f"Vista heatmap {'activada' if self.show_heatmap else 'desactivada'} en preview.", "info")

    def _open_theory_html(self):
        html_path = (
            Path(__file__).resolve().parents[1]
            / "docs"
            / "fundamentos_teoricos_planchas_dinamico.html"
        )

        if not html_path.exists():
            self.add_log(f"No se encontro el fundamento teorico: {html_path}", "error")
            return

        opened = QDesktopServices.openUrl(QUrl.fromLocalFile(str(html_path)))
        if opened:
            self.add_log("Fundamento teorico abierto en el navegador.", "success")
        else:
            self.add_log(f"No fue posible abrir el HTML: {html_path}", "error")

    def _plugin_version(self) -> str:
        metadata_path = self.plugin_root / "metadata.txt"
        try:
            for line in metadata_path.read_text(encoding="utf-8").splitlines():
                if line.strip().startswith("version="):
                    return line.split("=", 1)[1].strip()
        except Exception:
            pass
        return "0.0.0"

    def _version_tuple(self, value: str) -> Tuple[int, ...]:
        parts = []
        for raw_part in str(value).replace("-", ".").split("."):
            digits = "".join(ch for ch in raw_part if ch.isdigit())
            parts.append(int(digits or 0))
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts[:4])

    def _read_update_config(self) -> Dict[str, Any]:
        config_path = self.json_dir / "update_config.json"
        config: Dict[str, Any] = {}

        if config_path.exists():
            try:
                config = json.loads(config_path.read_text(encoding="utf-8-sig"))
            except Exception as exc:
                raise RuntimeError(f"No se pudo leer update_config.json: {exc}")

        config.setdefault("provider", "local")
        return config

    def _github_token(self, config: Dict[str, Any]) -> str:
        token_env = str(config.get("token_env") or DEFAULT_GITHUB_TOKEN_ENV)
        token = str(os.environ.get(token_env, "")).strip()
        if token:
            return token

        token_file = Path(str(config.get("token_file") or DEFAULT_GITHUB_TOKEN_FILE)).expanduser()
        if token_file.exists():
            return token_file.read_text(encoding="utf-8-sig").strip()

        raise RuntimeError(
            "No se encontro token de GitHub. Configure la variable "
            f"{token_env} o cree el archivo {token_file} con el token en texto plano."
        )

    def _github_contents_url(self, config: Dict[str, Any], repo_path: str) -> str:
        repository = str(config.get("repository") or "").strip()
        branch = str(config.get("branch") or "main").strip()
        if not repository:
            raise RuntimeError("update_config.json no tiene el campo repository.")
        encoded_path = quote(str(repo_path).strip().replace("\\", "/"), safe="/")
        encoded_ref = quote(branch, safe="")
        return f"https://api.github.com/repos/{repository}/contents/{encoded_path}?ref={encoded_ref}"

    def _github_read_bytes(self, config: Dict[str, Any], repo_path: str) -> bytes:
        token = self._github_token(config)
        request = Request(
            self._github_contents_url(config, repo_path),
            headers={
                "Accept": "application/vnd.github.raw",
                "Authorization": f"Bearer {token}",
                "User-Agent": "qgis-plate-analyzer",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        try:
            with urlopen(request, timeout=30) as response:
                return response.read()
        except HTTPError as exc:
            if exc.code == 401:
                raise RuntimeError("GitHub rechazo el token. Revise que sea valido y tenga acceso al repo privado.")
            if exc.code == 403:
                raise RuntimeError("GitHub rechazo la descarga. Revise permisos del token o limite de API.")
            if exc.code == 404:
                raise RuntimeError(f"GitHub no encontro la ruta {repo_path} en el repo configurado.")
            raise RuntimeError(f"GitHub respondio HTTP {exc.code} al leer {repo_path}.")
        except URLError as exc:
            raise RuntimeError(f"No fue posible conectar con GitHub: {exc.reason}")

    def _version_from_metadata_text(self, text: str) -> str:
        for line in str(text).splitlines():
            if line.strip().startswith("version="):
                return line.split("=", 1)[1].strip()
        return ""

    def _load_local_update_manifest(self, config: Dict[str, Any]) -> Tuple[str, str, Dict[str, Any]]:
        version_file = Path(str(config.get("version_file") or DEFAULT_UPDATE_VERSION_FILE))
        zip_file = Path(str(config.get("zip_file") or DEFAULT_UPDATE_ZIP_FILE))
        if not version_file.exists():
            raise RuntimeError(
                "No existe el manifiesto de actualizacion: "
                f"{version_file}. Publique primero el ZIP con scripts/build_plugin.py."
            )

        try:
            manifest = json.loads(version_file.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            raise RuntimeError(f"No se pudo leer el manifiesto {version_file}: {exc}")

        latest_version = str(manifest.get("version") or "").strip()
        if not latest_version:
            raise RuntimeError(f"El manifiesto {version_file} no tiene el campo version.")

        zip_path = Path(str(manifest.get("zip_path") or manifest.get("zip_file") or zip_file))
        return latest_version, str(version_file), {"provider": "local", "zip_path": zip_path}

    def _load_github_update_manifest(self, config: Dict[str, Any]) -> Tuple[str, str, Dict[str, Any]]:
        metadata_path = str(
            config.get("metadata_path")
            or "Complemento-QGIS Ejecutable/qgis_plate_analyzer/metadata.txt"
        )
        zip_repo_path = str(
            config.get("zip_path")
            or "Complemento-QGIS Ejecutable/qgis_plate_analyzer_importar_qgis.zip"
        )
        metadata_text = self._github_read_bytes(config, metadata_path).decode("utf-8", errors="replace")
        latest_version = self._version_from_metadata_text(metadata_text)
        if not latest_version:
            raise RuntimeError(f"No se encontro version= en {metadata_path}.")
        return latest_version, metadata_path, {
            "provider": "github",
            "config": config,
            "zip_repo_path": zip_repo_path,
        }

    def _read_public_url_bytes(self, url: str) -> bytes:
        if not url:
            raise RuntimeError("No se configuro la URL publica de actualizacion.")
        request = Request(
            url,
            headers={
                "User-Agent": "qgis-plate-analyzer",
                "Accept": "application/vnd.github.raw, application/json, */*",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
            },
        )
        try:
            with urlopen(request, timeout=30) as response:
                return response.read()
        except HTTPError as exc:
            if exc.code == 404:
                raise RuntimeError(f"No se encontro la ruta publica: {url}")
            raise RuntimeError(f"El servidor respondio HTTP {exc.code} al leer {url}.")
        except URLError as exc:
            raise RuntimeError(f"No fue posible conectar con la URL publica: {exc.reason}")

    def _load_http_update_manifest(self, config: Dict[str, Any]) -> Tuple[str, str, Dict[str, Any]]:
        version_url = str(config.get("version_url") or "").strip()
        if not version_url:
            raise RuntimeError("update_config.json no tiene el campo version_url.")
        fetch_url = version_url
        separator = "&" if "?" in fetch_url else "?"
        fetch_url = f"{fetch_url}{separator}_qgis_plate_analyzer_ts={int(time.time())}"
        try:
            manifest = json.loads(self._read_public_url_bytes(fetch_url).decode("utf-8-sig"))
        except Exception as exc:
            raise RuntimeError(f"No se pudo leer el manifiesto publico {version_url}: {exc}")

        latest_version = str(manifest.get("version") or "").strip()
        if not latest_version:
            raise RuntimeError(f"El manifiesto publico {version_url} no tiene el campo version.")

        zip_url = str(
            manifest.get("zip_url")
            or config.get("zip_url")
            or manifest.get("versioned_zip_url")
            or manifest.get("download_url")
            or ""
        ).strip()
        if not zip_url:
            raise RuntimeError(f"El manifiesto publico {version_url} no tiene URL de ZIP.")

        return latest_version, version_url, {
            "provider": "http",
            "zip_url": zip_url,
        }

    def _fetch_latest_version(self) -> Tuple[str, str, Dict[str, Any]]:
        config = self._read_update_config()
        provider = str(config.get("provider") or "local").strip().lower()
        if provider == "github":
            return self._load_github_update_manifest(config)
        if provider in {"http", "pages", "github_pages"}:
            return self._load_http_update_manifest(config)
        if provider == "local":
            return self._load_local_update_manifest(config)
        raise RuntimeError(f"Proveedor de actualizacion no soportado: {provider}")

    def _update_download_dir(self) -> Path:
        try:
            qgis_settings_dir = Path(QgsApplication.qgisSettingsDirPath())
            if qgis_settings_dir.exists():
                return qgis_settings_dir / "qgis_plate_analyzer_updates"
        except Exception:
            pass
        return Path(tempfile.gettempdir()) / "qgis_plate_analyzer_updates"

    def _download_update_zip(self, latest_version: str, update_info: Dict[str, Any]) -> Path:
        target_dir = self._update_download_dir()
        target_dir.mkdir(parents=True, exist_ok=True)
        target_path = target_dir / f"qgis_plate_analyzer_update_{latest_version}.zip"

        provider = str(update_info.get("provider") or "local")
        if provider == "github":
            zip_bytes = self._github_read_bytes(update_info["config"], update_info["zip_repo_path"])
            target_path.write_bytes(zip_bytes)
            return target_path
        if provider in {"http", "pages", "github_pages"}:
            zip_bytes = self._read_public_url_bytes(str(update_info.get("zip_url") or ""))
            target_path.write_bytes(zip_bytes)
            return target_path

        zip_path = Path(str(update_info.get("zip_path") or DEFAULT_UPDATE_ZIP_FILE))
        if not zip_path.exists():
            raise RuntimeError(f"No existe el ZIP de actualizacion: {zip_path}")
        shutil.copy2(zip_path, target_path)
        return target_path

    def _install_update_zip(self, zip_path: Path) -> None:
        try:
            import pyplugin_installer
        except Exception as exc:
            raise RuntimeError(f"No se pudo cargar el instalador interno de QGIS: {exc}")

        installer = pyplugin_installer.instance()
        if installer is None or not hasattr(installer, "installFromZipFile"):
            raise RuntimeError("El instalador interno de QGIS no esta disponible.")

        installer.installFromZipFile(str(zip_path))

    def _check_for_updates(self):
        current_version = self._plugin_version()
        self.add_log(f"Buscando actualizaciones. Version instalada: {current_version}", "info")
        QApplication.processEvents()

        try:
            latest_version, source, update_info = self._fetch_latest_version()
        except Exception as exc:
            self.add_log("Error revisando actualizaciones: " + str(exc), "error")
            return

        if not latest_version:
            self.add_log("No se encontro version publicada.", "warning")
            return

        self.add_log(f"Version publicada detectada: v{latest_version}", "info")

        if self._version_tuple(latest_version) > self._version_tuple(current_version):
            self.add_log(
                f"Actualizacion disponible: v{latest_version}. Fuente: {source}",
                "success",
            )
            try:
                target_path = self._download_update_zip(latest_version, update_info)
            except Exception as exc:
                self.add_log("No fue posible descargar el ZIP de actualizacion: " + str(exc), "error")
                return
            self.add_log("ZIP de actualizacion descargado en carpeta temporal de QGIS.", "success")
            QApplication.processEvents()
            try:
                self._install_update_zip(target_path)
            except Exception as exc:
                self.add_log("No fue posible instalar automaticamente la actualizacion: " + str(exc), "error")
                self.add_log(
                    f"ZIP temporal disponible para diagnostico: {target_path}",
                    "warning",
                )
                return
            installed_version = self._plugin_version()
            if self._version_tuple(installed_version) < self._version_tuple(latest_version):
                self.add_log(
                    f"QGIS ejecuto el instalador, pero el metadata instalado sigue en v{installed_version}. Reinicie QGIS y revise nuevamente.",
                    "warning",
                )
                return
            self.add_log(
                f"Actualizacion v{latest_version} instalada. Reinicie QGIS para asegurar que todos los modulos queden recargados.",
                "success",
            )
        elif self._version_tuple(latest_version) == self._version_tuple(current_version):
            self.add_log(f"El complemento esta actualizado: v{current_version}.", "success")
        else:
            self.add_log(
                f"La version instalada v{current_version} es mas reciente que la publicada v{latest_version}.",
                "warning",
            )

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------
    def add_log(self, message: str, kind: str = "info"):
        timestamp = time.strftime("[%H:%M:%S]")
        color = {
            "info": "#111111",
            "success": "#2f8f4e",
            "warning": "#b45309",
            "error": "#dc2626",
        }.get(kind, "#313831")
        icon = {
            "info": "i",
            "success": "OK",
            "warning": "!",
            "error": "x",
        }.get(kind, "-")
        safe = str(message).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        self.logs_text.append(
            f'<span style="color:#8a9388;">{timestamp}</span> '
            f'<span style="color:{color}; font-weight:700;">{icon}</span> '
            f'<span style="color:{color};">{safe}</span>'
        )
        self.last_log_message = message
        self.last_log.setText("LOG: " + (message[:72] + "..." if len(message) > 72 else message))
        self.logs_text.verticalScrollBar().setValue(self.logs_text.verticalScrollBar().maximum())

    def _clear_logs(self):
        self.logs_text.clear()
        self.last_log.setText("LOG: Consola limpia")

    def _copy_logs(self):
        QApplication.clipboard().setText(self.logs_text.toPlainText())
        self.add_log("Logs copiados al portapapeles.", "success")

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def _sidebar_connect_clicked(self):
        if self.is_connected:
            self._toggle_connection()
        else:
            self.set_tab(0)
            self.add_log('Verifique credenciales y pulse "Conectar".', "info")

    def _toggle_connection(self):
        if self.is_connected:
            self.add_log("Cerrando conexion con la base de datos...", "info")
            self._set_connection_state(False)
            self.add_log("Conexion cerrada. Base de datos desconectada.", "warning")
            return

        country = self.country_combo.currentText().strip()
        dbname = self._selected_dbname()
        if not dbname:
            self.add_log(f"No existe base configurada para el pais seleccionado: {country}", "error")
            return

        password = self.password_edit.text()
        config = DBConfig(
            host=self.host_edit.text().strip() or "localhost",
            port=self.port_edit.text().strip() or "5432",
            database=dbname,
            user=self.user_edit.text().strip() or "postgres",
            password=password,
        )
        self.db.update_config(config)
        self.database_edit.setText(dbname)
        self.add_log(f"Intentando conectar a {config.user}@{config.host}:{config.port}/{config.database}...", "info")
        self._set_processing_state(True, 15)
        QApplication.processEvents()
        try:
            ok, msg = self.db.test_connection()
            self.progress.setValue(75)
            QApplication.processEvents()
            if ok:
                self._set_connection_state(True)
                self.progress.setValue(0)
                self.add_log("Conexion establecida con exito. Base de datos en linea.", "success")
                self.add_log("PostgreSQL responde: " + str(msg)[:120], "success")
                self._update_resolved_config_label()
                self._populate_schemas_and_tables()
            else:
                self._set_processing_state(False, 0)
                self.add_log("No fue posible conectar: " + str(msg), "error")
        except Exception as exc:
            self._set_processing_state(False, 0)
            self.add_log("Error inesperado al conectar: " + str(exc), "error")
            self.add_log(traceback.format_exc(), "error")

    def _populate_schemas_and_tables(self):
        try:
            schemas = self.db.list_schemas()
            if schemas:
                for combo in (self.schema_combo, self.pg_schema_combo):
                    current = combo.currentText()
                    combo.clear()
                    combo.addItems(schemas)
                    if current in schemas:
                        combo.setCurrentText(current)
                self.add_log(f"Esquemas detectados: {', '.join(schemas[:6])}", "success")
        except Exception as exc:
            self.add_log("No se pudieron listar esquemas: " + str(exc), "warning")
        self._schema_changed(self.pg_schema_combo.currentText())

    def _schema_changed(self, schema: str):
        if not self.is_connected:
            return
        try:
            tables = self.db.list_spatial_tables(schema or "public")
            self.table_meta_by_label.clear()
            self.pg_table_combo.clear()
            for t in tables:
                label = str(t.get("table") or t.get("name") or "")
                if not label:
                    continue
                self.table_meta_by_label[label] = t
                self.pg_table_combo.addItem(label)
            if tables:
                first = tables[0]
                geom = str(first.get("geometry_column") or first.get("geom") or "geom")
                self.pg_geom_edit.setText(geom)
                self.add_log(f"{len(tables)} tablas espaciales detectadas en el esquema {schema}.", "success")
        except Exception as exc:
            self.add_log("No se pudieron listar tablas espaciales: " + str(exc), "warning")

    def _load_municipality(self):
        if not self.is_connected:
            self.add_log("Primero conecte con las credenciales PostgreSQL.", "error")
            return

        schema, table, geom, city_col, dep_col = self._admin_municipality_config()
        city = self._selected_city_name()
        dep = self._selected_department_name()
        if not dep or not city:
            self.add_log("Seleccione un departamento y municipio validos desde cities_cache.", "error")
            return
        sql_filter = ""
        if city:
            safe_city = city.replace("'", "''")
            safe_city_col = city_col.replace('"', '""')
            sql_filter = f'"{safe_city_col}" ILIKE \'%{safe_city}%\''
            if dep:
                safe_dep = dep.replace("'", "''")
                safe_dep_col = dep_col.replace('"', '""')
                sql_filter += f' AND "{safe_dep_col}" ILIKE \'%{safe_dep}%\''
        self.add_log(f"Cargando geometria administrativa del municipio: {dep} / {city}...", "info")
        try:
            ok, msg, layer = self.db.load_postgis_layer(schema, table, geom, f"{city or table}_limite", sql_filter)
            if ok:
                self.add_log(msg, "success")
                self._refresh_qgis_layers(silent=True)
                self.set_tab(1)
            else:
                self.add_log(msg, "error")
        except Exception as exc:
            self.add_log("Error cargando municipio: " + str(exc), "error")

    def _load_admin_mask_from_file(self):
        path, _selected_filter = QFileDialog.getOpenFileName(
            self,
            "Importar delimitacion administrativa",
            "",
            "Delimitacion administrativa (*.gpkg *.shp *.geojson *.json *.kml *.sqlite);;GeoPackage (*.gpkg);;Shapefile (*.shp);;GeoJSON (*.geojson *.json);;Todos los archivos (*.*)",
        )
        if not path:
            return

        layer_name = f"{Path(path).stem}_mascara_administrativa"
        layer = QgsVectorLayer(path, layer_name, "ogr")
        if not layer.isValid():
            self.add_log(f"No se pudo cargar la delimitacion administrativa: {path}", "error")
            return

        if layer.geometryType() != 2:
            geom = {0: "puntos", 1: "lineas", 2: "poligonos"}.get(layer.geometryType(), "geometria")
            self.add_log(
                f"La delimitacion administrativa debe ser poligonal. Tipo detectado: {geom}.",
                "error",
            )
            return

        QgsProject.instance().addMapLayer(layer)
        self.manual_admin_mask_layer_id = layer.id()
        self.manual_admin_mask_name = layer.name()
        self.manual_admin_mask_gdf = None
        self.mask_enabled = True
        if hasattr(self, "mask_checkbox"):
            self.mask_checkbox.setChecked(True)
        if hasattr(self, "map_preview"):
            self.map_preview.set_mask_enabled(True)
        if hasattr(self, "analysis_preview"):
            self.analysis_preview.set_mask_enabled(True)

        self._refresh_qgis_layers(silent=True)
        self._update_manual_admin_mask_label()
        self._update_manual_urban_footprint_label()
        self._update_manual_constructions_label()
        self._update_resolved_config_label()
        self._update_analysis_summary()
        self.add_log(
            f"Delimitacion administrativa local cargada como mascara: {layer.name()} ({layer.featureCount():,} entidad(es)).",
            "success",
        )

    def _clear_manual_admin_mask(self):
        self.manual_admin_mask_layer_id = ""
        self.manual_admin_mask_name = ""
        self.manual_admin_mask_gdf = None
        self._update_manual_admin_mask_label()
        self._update_manual_urban_footprint_label()
        self._update_manual_constructions_label()
        self._update_resolved_config_label()
        self._update_analysis_summary()
        self.add_log("Delimitacion administrativa local retirada. Se usara la mascara resuelta desde base de datos.", "info")

    def _load_urban_footprint_from_file(self):
        path, _selected_filter = QFileDialog.getOpenFileName(
            self,
            "Importar huella urbana",
            "",
            "Huella urbana (*.gpkg *.shp *.geojson *.json *.kml *.sqlite);;GeoPackage (*.gpkg);;Shapefile (*.shp);;GeoJSON (*.geojson *.json);;Todos los archivos (*.*)",
        )
        if not path:
            return

        layer_name = f"{Path(path).stem}_huella_urbana"
        layer = QgsVectorLayer(path, layer_name, "ogr")
        if not layer.isValid():
            self.add_log(f"No se pudo cargar la huella urbana: {path}", "error")
            return

        if layer.geometryType() != 2:
            geom = {0: "puntos", 1: "lineas", 2: "poligonos"}.get(layer.geometryType(), "geometria")
            self.add_log(
                f"La huella urbana debe ser poligonal. Tipo detectado: {geom}.",
                "error",
            )
            return

        QgsProject.instance().addMapLayer(layer)
        self.manual_urban_footprint_layer_id = layer.id()
        self.manual_urban_footprint_name = layer.name()
        self.manual_urban_footprint_gdf = None
        self.mask_enabled = True
        if hasattr(self, "mask_checkbox"):
            self.mask_checkbox.setChecked(True)
        if hasattr(self, "map_preview"):
            self.map_preview.set_mask_enabled(True)
        if hasattr(self, "analysis_preview"):
            self.analysis_preview.set_mask_enabled(True)

        self._refresh_qgis_layers(silent=True)
        self._update_manual_admin_mask_label()
        self._update_manual_urban_footprint_label()
        self._update_manual_constructions_label()
        self._update_resolved_config_label()
        self._update_analysis_summary()
        self.add_log(
            f"Huella urbana local cargada: {layer.name()} ({layer.featureCount():,} entidad(es)).",
            "success",
        )

    def _clear_manual_urban_footprint(self):
        self.manual_urban_footprint_layer_id = ""
        self.manual_urban_footprint_name = ""
        self.manual_urban_footprint_gdf = None
        self._update_manual_admin_mask_label()
        self._update_manual_urban_footprint_label()
        self._update_manual_constructions_label()
        self._update_resolved_config_label()
        self._update_analysis_summary()
        self.add_log("Huella urbana local retirada.", "info")

    def _load_constructions_from_file(self):
        path, _selected_filter = QFileDialog.getOpenFileName(
            self,
            "Importar construcciones",
            "",
            "Construcciones (*.gpkg *.shp *.geojson *.json *.kml *.sqlite);;GeoPackage (*.gpkg);;Shapefile (*.shp);;GeoJSON (*.geojson *.json);;Todos los archivos (*.*)",
        )
        if not path:
            return

        layer_name = f"{Path(path).stem}_construcciones"
        layer = QgsVectorLayer(path, layer_name, "ogr")
        if not layer.isValid():
            self.add_log(f"No se pudo cargar la capa de construcciones: {path}", "error")
            return

        if layer.geometryType() != 2:
            geom = {0: "puntos", 1: "lineas", 2: "poligonos"}.get(layer.geometryType(), "geometria")
            self.add_log(
                f"Las construcciones deben ser poligonales para ponderar por area. Tipo detectado: {geom}.",
                "error",
            )
            return

        QgsProject.instance().addMapLayer(layer)
        self.manual_constructions_layer_id = layer.id()
        self.manual_constructions_name = layer.name()
        self.manual_constructions_gdf = None
        self._refresh_qgis_layers(silent=True)
        self._update_manual_admin_mask_label()
        self._update_manual_urban_footprint_label()
        self._update_manual_constructions_label()
        self._update_resolved_config_label()
        self._update_analysis_summary()
        self.add_log(
            f"Construcciones locales cargadas: {layer.name()} ({layer.featureCount():,} entidad(es)).",
            "success",
        )

    def _clear_manual_constructions(self):
        self.manual_constructions_layer_id = ""
        self.manual_constructions_name = ""
        self.manual_constructions_gdf = None
        self._update_manual_constructions_label()
        self._update_resolved_config_label()
        self._update_analysis_summary()
        self.add_log("Construcciones locales retiradas.", "info")

    def _add_postgis_layer(self):
        schema = self.pg_schema_combo.currentText().strip() or "public"
        table = self.pg_table_combo.currentText().strip()
        geom = self.pg_geom_edit.text().strip() or "geom"
        if not table:
            self.add_log("Seleccione una tabla PostGIS.", "error")
            return
        self.add_log(f"Conectando al catÃ¡logo PostGIS. Leyendo tabla: {schema}.{table}...", "info")
        try:
            ok, msg, layer = self.db.load_postgis_layer(schema, table, geom, f"{schema}.{table}")
            if ok:
                self.add_log("Detectando columnas de geometrÃ­a... OK", "success")
                self.add_log(msg, "success")
                self._refresh_qgis_layers(silent=True)
            else:
                self.add_log(msg, "error")
        except Exception as exc:
            self.add_log("Error cargando capa PostGIS: " + str(exc), "error")

    def _load_vector_layer_from_file(self):
        path, _selected_filter = QFileDialog.getOpenFileName(
            self,
            "Cargar archivo vectorial para analisis",
            "",
            "Capas vectoriales (*.gpkg *.shp *.geojson *.json *.kml *.sqlite);;GeoPackage (*.gpkg);;Shapefile (*.shp);;GeoJSON (*.geojson *.json);;Todos los archivos (*.*)",
        )
        if not path:
            return

        layer_name = Path(path).stem
        layer = QgsVectorLayer(path, layer_name, "ogr")
        if not layer.isValid():
            self.add_log(f"No se pudo cargar el archivo vectorial: {path}", "error")
            return

        QgsProject.instance().addMapLayer(layer)
        self.add_log(f"Capa vectorial cargada desde archivo: {layer.name()}", "success")
        self._refresh_qgis_layers(silent=True)

        if hasattr(self, "qgis_layer_combo"):
            self._set_combo_by_layer_id(self.qgis_layer_combo, layer.id())
        if hasattr(self, "analysis_layer_combo"):
            self._set_combo_by_layer_id(self.analysis_layer_combo, layer.id())
        self._on_qgis_layer_changed(self.qgis_layer_combo.currentText() if hasattr(self, "qgis_layer_combo") else "")

        if layer.geometryType() == 0:
            self._confirm_analysis_layer_from_layers_panel()
        else:
            geom = {1: "lineas", 2: "poligonos"}.get(layer.geometryType(), "geometria")
            self.add_log(
                f"La capa se cargo correctamente, pero el analisis de densidad requiere puntos. Tipo detectado: {geom}.",
                "warning",
            )

    def _refresh_qgis_layers(self, silent: bool = False):
        self.layer_id_by_label.clear()
        current_qgis_id = self.qgis_layer_combo.currentData() if hasattr(self, "qgis_layer_combo") else ""
        current_analysis_id = self.analysis_layer_combo.currentData() if hasattr(self, "analysis_layer_combo") else ""
        active_layer = self.iface.activeLayer() if self.iface is not None else None
        active_layer_id = active_layer.id() if isinstance(active_layer, QgsVectorLayer) else ""
        items: List[Tuple[str, str]] = []
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer) and layer.isValid():
                geom = {0: "Point", 1: "LineString", 2: "Polygon"}.get(layer.geometryType(), "Geometry")
                crs = layer.crs().authid() if layer.crs().isValid() else "Sin CRS"
                label = f"{layer.name()}  Â·  {geom}  Â·  {crs}  Â·  {layer.featureCount()} feat"
                self.layer_id_by_label[label] = layer.id()
                items.append((label, layer.id()))
        if hasattr(self, "qgis_layer_combo"):
            self.qgis_layer_combo.blockSignals(True)
            self.qgis_layer_combo.clear()
            if items:
                for label, layer_id in items:
                    self.qgis_layer_combo.addItem(label, layer_id)
                self._set_combo_by_layer_id(
                    self.qgis_layer_combo,
                    str(current_qgis_id or self.confirmed_analysis_layer_id or active_layer_id or ""),
                )
            else:
                self.qgis_layer_combo.addItem("No hay capas vectoriales activas", "")
            self.qgis_layer_combo.blockSignals(False)
        if hasattr(self, "analysis_layer_combo"):
            self.analysis_layer_combo.blockSignals(True)
            self.analysis_layer_combo.clear()
            if items:
                for label, layer_id in items:
                    self.analysis_layer_combo.addItem(label, layer_id)
                self._set_combo_by_layer_id(
                    self.analysis_layer_combo,
                    str(self.confirmed_analysis_layer_id or current_analysis_id or active_layer_id or ""),
                )
            else:
                self.analysis_layer_combo.addItem("No hay capas vectoriales activas", "")
            self.analysis_layer_combo.blockSignals(False)
        if hasattr(self, "analysis_layer_combo"):
            self._on_analysis_layer_changed(self.analysis_layer_combo.currentText())
        elif hasattr(self, "qgis_layer_combo"):
            self._on_qgis_layer_changed(self.qgis_layer_combo.currentText())
        if not silent:
            self.add_log(f"Lista de capas QGIS actualizada: {len(items)} capa(s) vectorial(es).", "info")

    def _set_combo_by_layer_id(self, combo: QComboBox, layer_id: str) -> bool:
        if not layer_id:
            return False
        for index in range(combo.count()):
            if str(combo.itemData(index) or "") == layer_id:
                combo.setCurrentIndex(index)
                return True
        return False

    def _layer_from_combo(self, combo: QComboBox):
        layer_id = str(combo.currentData() or "")
        if not layer_id:
            layer_id = self.layer_id_by_label.get(combo.currentText().strip(), "")
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None
        if isinstance(layer, QgsVectorLayer) and layer.isValid():
            return layer
        return None

    def _layer_from_id(self, layer_id: str):
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None
        if isinstance(layer, QgsVectorLayer) and layer.isValid():
            return layer
        return None

    def _confirm_analysis_layer_from_layers_panel(self):
        if not hasattr(self, "qgis_layer_combo"):
            self.add_log("No esta disponible la lista de capas activas.", "error")
            return

        layer = self._layer_from_combo(self.qgis_layer_combo)
        if layer is None:
            self.add_log("No se pudo confirmar la capa seleccionada.", "error")
            return

        self.confirmed_analysis_layer_id = layer.id()
        self.confirmed_analysis_layer_name = layer.name()

        if hasattr(self, "analysis_layer_combo"):
            self._set_combo_by_layer_id(self.analysis_layer_combo, layer.id())
        if hasattr(self, "analysis_preview"):
            self.analysis_preview.set_layer_name(layer.name())
        if hasattr(self, "confirmed_layer_label"):
            self.confirmed_layer_label.setText(f"Capa confirmada para analisis: {layer.name()}")

        geom = {0: "puntos", 1: "lineas", 2: "poligonos"}.get(layer.geometryType(), "geometria")
        self.add_log(f"Capa confirmada para analisis: {layer.name()} ({geom}).", "success")
        self._update_analysis_summary()

    def _on_analysis_layer_changed(self, label: str):
        self._on_qgis_layer_changed(label)
        layer = self._layer_from_combo(self.analysis_layer_combo) if hasattr(self, "analysis_layer_combo") else None
        if isinstance(layer, QgsVectorLayer):
            geom = {0: "puntos", 1: "lineas", 2: "poligonos"}.get(layer.geometryType(), "geometria")
            self.add_log(f"Capa seleccionada para analisis: {layer.name()} ({geom}).", "info")

    def _on_qgis_layer_changed(self, label: str):
        layer_id = self.layer_id_by_label.get(label)
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None
        if layer is None and hasattr(self, "analysis_layer_combo") and self.analysis_layer_combo.currentText() == label:
            layer = self._layer_from_combo(self.analysis_layer_combo)
        if layer is None and hasattr(self, "qgis_layer_combo") and self.qgis_layer_combo.currentText() == label:
            layer = self._layer_from_combo(self.qgis_layer_combo)
        if isinstance(layer, QgsVectorLayer):
            geom = {0: "Point", 1: "LineString", 2: "Polygon"}.get(layer.geometryType(), "Geometry")
            crs = layer.crs().authid() if layer.crs().isValid() else "Sin CRS"
            self.layer_info_label.setText(
                f"Nombre: {layer.name()}\nTipo: Vectorial / {geom}\nCRS: {crs}\nEntidades: {layer.featureCount()}\nExtent: {layer.extent().toString()}"
            )
            if hasattr(self, "map_preview"):
                self.map_preview.set_layer_name(layer.name())
            if hasattr(self, "analysis_preview"):
                self.analysis_preview.set_layer_name(layer.name())
        else:
            if hasattr(self, "layer_info_label"):
                self.layer_info_label.setText("Sin capa vectorial seleccionada.")

    def _selected_analysis_layer(self):
        confirmed_layer = self._layer_from_id(self.confirmed_analysis_layer_id)
        if confirmed_layer is not None:
            return confirmed_layer
        if hasattr(self, "analysis_layer_combo"):
            return self._layer_from_combo(self.analysis_layer_combo)
        return None

    def _safe_metric_gdf(self, gdf):
        if gdf is None or getattr(gdf, "empty", True):
            return gdf
        if getattr(gdf, "crs", None) is None:
            return gdf
        try:
            if gdf.crs.is_geographic:
                metric_crs = gdf.estimate_utm_crs()
                if metric_crs is not None:
                    return gdf.to_crs(metric_crs)
                return gdf.to_crs(epsg=3857)
        except Exception:
            try:
                return gdf.to_crs(epsg=3857)
            except Exception:
                return gdf
        return gdf

    def _geometry_area_m2(self, gdf) -> float:
        if gdf is None or getattr(gdf, "empty", True):
            return 0.0
        try:
            metric = self._safe_metric_gdf(gdf)
            union = metric.geometry.unary_union
            return float(union.area)
        except Exception:
            try:
                return float(self._safe_metric_gdf(gdf).geometry.area.sum())
            except Exception:
                return 0.0

    def _format_area(self, area_m2: float) -> str:
        area_m2 = float(area_m2 or 0.0)
        return f"{area_m2 / 1_000_000:,.3f} km2 ({area_m2:,.0f} m2)"

    def _report_value(self, value: object) -> str:
        return html.escape(str(value if value is not None else ""))

    def _generate_density_report(self):
        result = self.last_analysis_result
        if not result:
            self.add_log("Ejecute primero un analisis de densidad para generar el informe.", "error")
            return

        mask = result.get("mask")
        zones = result.get("density_zones")
        if zones is None or getattr(zones, "empty", True):
            zones = result.get("voronoi")
        points = result.get("points")
        kde_surface = result.get("kde_surface")
        params = result.get("parameters") or {}

        if zones is None or getattr(zones, "empty", True):
            self.add_log("No hay capa final de cobertura disponible para generar el informe.", "error")
            return

        if "cobertura" not in zones.columns:
            self.add_log("El resultado no contiene el campo cobertura.", "error")
            return

        total_area_m2 = self._geometry_area_m2(mask)
        if total_area_m2 <= 0:
            total_area_m2 = self._geometry_area_m2(zones)

        coverage_frame = kde_surface if kde_surface is not None and not getattr(kde_surface, "empty", True) else zones

        def _area_by_value(gdf, column, preferred_order):
            summary = {label: 0.0 for label in preferred_order}
            if gdf is None or getattr(gdf, "empty", True) or column not in gdf.columns:
                return summary
            try:
                metric = self._safe_metric_gdf(gdf)
                grouped = metric.assign(_area_m2=metric.geometry.area).groupby(column, dropna=False)["_area_m2"].sum()
                for key, value in grouped.items():
                    summary[str(key)] = float(value)
            except Exception:
                pass
            return summary

        def _svg_pie(summary, colors):
            total = sum(max(0.0, float(value)) for value in summary.values())
            if total <= 0:
                return "<p class=\"muted\">Sin datos suficientes para graficar cobertura.</p>"
            radius = 76.0
            circumference = 2.0 * 3.141592653589793 * radius
            offset = 0.0
            circles = []
            legend = []
            for label, value in summary.items():
                pct = max(0.0, float(value)) / total
                dash = pct * circumference
                color = colors.get(label, "#6b7280")
                circles.append(
                    f'<circle r="{radius}" cx="100" cy="100" fill="transparent" stroke="{color}" '
                    f'stroke-width="34" stroke-dasharray="{dash:.4f} {circumference - dash:.4f}" '
                    f'stroke-dashoffset="{-offset:.4f}" transform="rotate(-90 100 100)" />'
                )
                offset += dash
                legend.append(
                    f'<div><span class="swatch" style="background:{color}"></span>'
                    f'{self._report_value(label)} · {pct * 100.0:,.2f}%</div>'
                )
            return (
                '<div class="chart-wrap"><svg viewBox="0 0 200 200" class="pie-chart">'
                + "".join(circles)
                + '<circle r="48" cx="100" cy="100" fill="#ffffff" /></svg>'
                + '<div class="chart-legend">'
                + "".join(legend)
                + "</div></div>"
            )

        def _svg_bars(summary, colors):
            max_value = max([float(value) for value in summary.values()] + [0.0])
            if max_value <= 0:
                return "<p class=\"muted\">Sin datos suficientes para graficar categorias.</p>"
            bars = []
            for label, value in summary.items():
                pct = (float(value) / max_value) * 100.0
                total_pct = (float(value) / sum(summary.values()) * 100.0) if sum(summary.values()) > 0 else 0.0
                color = colors.get(label, "#111827")
                bars.append(
                    f'<div class="vbar-item"><div class="vbar-track">'
                    f'<div class="vbar-fill" style="height:{pct:.4f}%; background:{color};"></div>'
                    f'</div><strong>{self._report_value(label)}</strong><span>{total_pct:,.2f}%</span></div>'
                )
            return '<div class="vbar-chart">' + "".join(bars) + "</div>"

        coverage_order = ["No cubierto", "Cubierto", "Sin construcciones"]
        category_order = ["Bajo", "Medio", "Alto"]
        coverage_area = _area_by_value(coverage_frame, "cobertura", coverage_order)
        category_area = _area_by_value(coverage_frame, "categoria_busqueda", category_order)

        high_area_m2 = coverage_area.get("No cubierto", 0.0)
        low_area_m2 = coverage_area.get("Cubierto", 0.0)
        no_construction_area_m2 = coverage_area.get("Sin construcciones", 0.0)
        mapped_area_m2 = low_area_m2
        high_pct = (high_area_m2 / total_area_m2 * 100.0) if total_area_m2 > 0 else 0.0
        mapped_pct = (mapped_area_m2 / total_area_m2 * 100.0) if total_area_m2 > 0 else 0.0
        low_pct = (low_area_m2 / total_area_m2 * 100.0) if total_area_m2 > 0 else 0.0
        no_construction_pct = (no_construction_area_m2 / total_area_m2 * 100.0) if total_area_m2 > 0 else 0.0
        low_count = int((coverage_frame["cobertura"] == "Cubierto").sum()) if "cobertura" in coverage_frame.columns else 0
        high_count = int((coverage_frame["cobertura"] == "No cubierto").sum()) if "cobertura" in coverage_frame.columns else 0
        no_construction_count = int((coverage_frame["cobertura"] == "Sin construcciones").sum()) if "cobertura" in coverage_frame.columns else 0
        total_count = int(len(coverage_frame))
        points_count = int(len(points)) if points is not None and not getattr(points, "empty", True) else 0
        samples_count = int(len(kde_surface)) if kde_surface is not None and not getattr(kde_surface, "empty", True) else 0

        kde = None
        if "kde_superficie_raw" in coverage_frame.columns:
            kde = coverage_frame["kde_superficie_raw"]
        kde_min = float(kde.min()) if kde is not None and len(kde) else 0.0
        kde_mean = float(kde.mean()) if kde is not None and len(kde) else 0.0
        kde_max = float(kde.max()) if kde is not None and len(kde) else 0.0
        threshold = float(coverage_frame["umbral_kde_baja_densidad"].iloc[0]) if "umbral_kde_baja_densidad" in coverage_frame.columns and len(coverage_frame) else 0.0
        no_construction_threshold = float(coverage_frame["umbral_kde_sin_construcciones"].iloc[0]) if "umbral_kde_sin_construcciones" in coverage_frame.columns and len(coverage_frame) else 0.0
        criterion = (
            str(coverage_frame["criterio_prioridad_sin_placas"].iloc[0])
            if "criterio_prioridad_sin_placas" in coverage_frame.columns and len(coverage_frame)
            else "No disponible"
        )

        coverage_chart = _svg_pie(
            coverage_area,
            {
                "No cubierto": "#dc2626",
                "Cubierto": "#0f766e",
                "Sin construcciones": "#6b7280",
            },
        )
        category_chart = _svg_bars(
            category_area,
            {
                "Bajo": "#94a3b8",
                "Medio": "#f59e0b",
                "Alto": "#dc2626",
            },
        )

        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        dep = self._selected_department_name()
        city = self._selected_city_name()
        layer_name = self.confirmed_analysis_layer_name or (
            self._selected_analysis_layer().name() if self._selected_analysis_layer() else ""
        )
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        slug_base = "_".join(part for part in [country, dep, city] if part).replace(" ", "_")
        safe_slug = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in slug_base) or "analisis"
        report_dir = self.plugin_root / "reports"
        report_dir.mkdir(parents=True, exist_ok=True)
        report_path = report_dir / f"informe_prioridad_sin_placas_{safe_slug}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"

        rows_html = ""
        no_covered_rows = coverage_frame[coverage_frame["cobertura"] == "No cubierto"].copy() if "cobertura" in coverage_frame.columns else None
        if no_covered_rows is not None and not no_covered_rows.empty:
            cols = [
                c for c in [
                    "kde_cell_id",
                    "zona_kde_id",
                    "kde_superficie_raw",
                    "kde_superficie_pct",
                    "score_sin_placas",
                    "cobertura",
                    "categoria_busqueda",
                ]
                if c in no_covered_rows.columns
            ]
            preview_rows = no_covered_rows[cols].head(25)
            for _, row in preview_rows.iterrows():
                rows_html += "<tr>" + "".join(f"<td>{self._report_value(row[col])}</td>" for col in cols) + "</tr>\n"
            header_html = "".join(f"<th>{self._report_value(col)}</th>" for col in cols)
            high_table = f"""
            <table>
              <thead><tr>{header_html}</tr></thead>
              <tbody>{rows_html}</tbody>
            </table>
            """
        else:
            high_table = "<p>No se detectaron celdas o zonas no cubiertas bajo el umbral actual.</p>"

        document = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Informe ejecutivo de cobertura de placas</title>
  <style>
    :root {{
      --ink: #15202b;
      --muted: #667085;
      --line: #d8dee8;
      --paper: #fbfcff;
      --panel: #ffffff;
      --mapped: #0f766e;
      --missing: #dc2626;
      --empty: #6b7280;
      --gold: #b45309;
      --navy: #111827;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      color: var(--ink);
      font-family: Aptos, Segoe UI, Arial, sans-serif;
      line-height: 1.55;
      background:
        linear-gradient(135deg, rgba(15, 118, 110, .10), transparent 34%),
        linear-gradient(225deg, rgba(220, 38, 38, .08), transparent 38%),
        #eef2f7;
    }}
    main {{ max-width: 1180px; margin: 0 auto; padding: 30px 24px 56px; }}
    .hero {{
      position: relative;
      overflow: hidden;
      min-height: 270px;
      border-radius: 22px;
      padding: 34px;
      color: white;
      background:
        linear-gradient(135deg, rgba(17, 24, 39, .96), rgba(31, 41, 55, .92)),
        radial-gradient(circle at 85% 10%, rgba(20, 184, 166, .36), transparent 28rem);
      box-shadow: 0 24px 70px rgba(15, 23, 42, .22);
    }}
    .hero::after {{
      content: "";
      position: absolute;
      right: -110px;
      bottom: -110px;
      width: 360px;
      height: 360px;
      border-radius: 50%;
      border: 52px solid rgba(255, 255, 255, .06);
    }}
    .eyebrow {{
      display: inline-flex;
      gap: 8px;
      align-items: center;
      padding: 7px 11px;
      border: 1px solid rgba(255,255,255,.18);
      border-radius: 999px;
      color: #ccfbf1;
      font-size: 12px;
      font-weight: 800;
      letter-spacing: .08em;
      text-transform: uppercase;
    }}
    h1 {{ max-width: 820px; margin: 18px 0 10px; font-size: 42px; line-height: 1.05; letter-spacing: -.02em; }}
    h2 {{ margin: 0 0 14px; font-size: 24px; letter-spacing: -.01em; }}
    h3 {{ margin: 0 0 8px; font-size: 16px; }}
    p {{ margin: 0 0 12px; }}
    .hero p {{ max-width: 780px; color: #dbeafe; }}
    .meta {{
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 10px;
      margin-top: 24px;
      max-width: 920px;
    }}
    .meta div {{
      padding: 11px 12px;
      border-radius: 12px;
      background: rgba(255,255,255,.08);
      border: 1px solid rgba(255,255,255,.14);
    }}
    .meta span {{ display: block; color: #9ca3af; font-size: 11px; text-transform: uppercase; font-weight: 800; }}
    section {{
      margin-top: 22px;
      padding: 24px;
      border: 1px solid var(--line);
      border-radius: 18px;
      background: rgba(255,255,255,.88);
      box-shadow: 0 14px 36px rgba(15, 23, 42, .07);
    }}
    .split {{ display: grid; grid-template-columns: 1.1fr .9fr; gap: 18px; }}
    .grid {{ display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; margin-top: 16px; }}
    .card {{
      background: var(--panel);
      border: 1px solid #e4e9f2;
      border-radius: 16px;
      padding: 17px;
      box-shadow: 0 10px 28px rgba(15, 23, 42, .06);
    }}
    .metric {{ font-size: 25px; font-weight: 900; color: var(--navy); line-height: 1.1; }}
    .metric.missing {{ color: var(--missing); }}
    .metric.mapped {{ color: var(--mapped); }}
    .metric.gold {{ color: var(--gold); }}
    .label {{ margin-top: 7px; color: var(--muted); font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: .04em; }}
    .statement {{
      padding: 20px;
      border-radius: 16px;
      background: linear-gradient(135deg, #fff1f2, #ffffff);
      border: 1px solid #fecdd3;
      color: #7f1d1d;
    }}
    .statement.mapped {{
      background: linear-gradient(135deg, #ecfdf5, #ffffff);
      border-color: #a7f3d0;
      color: #064e3b;
    }}
    .bar {{
      height: 18px;
      display: flex;
      overflow: hidden;
      border-radius: 999px;
      background: #e5e7eb;
      border: 1px solid #d1d5db;
      margin: 16px 0 8px;
    }}
    .bar .mapped {{ width: {mapped_pct:.6f}%; background: linear-gradient(90deg, #0f766e, #14b8a6); }}
    .bar .missing {{ width: {high_pct:.6f}%; background: linear-gradient(90deg, #ef4444, #b91c1c); }}
    .bar .empty {{ width: {no_construction_pct:.6f}%; background: linear-gradient(90deg, #6b7280, #374151); }}
    .legend {{ display: flex; gap: 16px; flex-wrap: wrap; color: var(--muted); font-size: 13px; }}
    .dot {{ display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 6px; }}
    .dot.mapped {{ background: var(--mapped); }}
    .dot.missing {{ background: var(--missing); }}
    .dot.empty {{ background: var(--empty); }}
    .chart-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-top: 16px; }}
    .chart-wrap {{ display: flex; align-items: center; gap: 18px; min-height: 220px; }}
    .pie-chart {{ width: 210px; height: 210px; flex: 0 0 auto; }}
    .chart-legend {{ display: grid; gap: 10px; color: var(--muted); font-size: 13px; }}
    .swatch {{ display: inline-block; width: 12px; height: 12px; border-radius: 3px; margin-right: 8px; vertical-align: -1px; }}
    .vbar-chart {{ display: flex; align-items: end; justify-content: center; gap: 26px; min-height: 230px; padding: 18px 8px 4px; }}
    .vbar-item {{ display: grid; justify-items: center; gap: 7px; min-width: 72px; color: var(--muted); font-size: 12px; }}
    .vbar-track {{ display: flex; align-items: end; width: 54px; height: 150px; border-radius: 14px 14px 7px 7px; overflow: hidden; background: #eef2f7; border: 1px solid #d8dee8; }}
    .vbar-fill {{ width: 100%; border-radius: 14px 14px 0 0; }}
    .vbar-item strong {{ color: var(--navy); font-size: 13px; }}
    .formula {{
      background: #111827;
      color: #e0f2fe;
      padding: 16px;
      border-radius: 14px;
      font-family: Consolas, ui-monospace, monospace;
      overflow-x: auto;
      border: 1px solid #1f2937;
    }}
    table {{ width: 100%; border-collapse: collapse; overflow: hidden; border-radius: 14px; background: white; }}
    th, td {{ text-align: left; padding: 12px 13px; border-bottom: 1px solid #edf0f5; font-size: 13px; }}
    th {{ background: #f8fafc; color: #475467; text-transform: uppercase; letter-spacing: .04em; font-size: 11px; }}
    .muted {{ color: var(--muted); }}
    @media (max-width: 920px) {{
      .split, .meta {{ grid-template-columns: 1fr; }}
      .chart-grid {{ grid-template-columns: 1fr; }}
      .grid {{ grid-template-columns: 1fr 1fr; }}
      h1 {{ font-size: 32px; }}
    }}
  </style>
</head>
<body>
  <main>
    <header class="hero">
      <div class="eyebrow">Informe ejecutivo · KDE hexagonal</div>
      <h1>Balance de cobertura y zonas pendientes por mapear</h1>
      <p>
        Este informe resume la lectura territorial del analisis: que parte del municipio ya presenta densidad de placas suficiente y que parte debe priorizarse porque muestra baja densidad de placas.
      </p>
      <div class="meta">
        <div><span>Generado</span>{self._report_value(now)}</div>
        <div><span>Territorio</span>{self._report_value(country)} / {self._report_value(dep)} / {self._report_value(city)}</div>
        <div><span>Capa analizada</span>{self._report_value(layer_name)}</div>
      </div>
    </header>

    <section>
      <h2>Lectura principal</h2>
      <div class="split">
        <div class="statement mapped">
          <h3>Realmente lo que se tiene mapeado es esto</h3>
          <p>
            El analisis estima <strong>{self._format_area(mapped_area_m2)}</strong> como area con construcciones y densidad suficiente o no prioritaria para busqueda de faltantes. Esto equivale a <strong>{mapped_pct:,.2f}%</strong> de la mascara de busqueda.
          </p>
        </div>
        <div class="statement">
          <h3>Lo que hace falta por mapear o revisar</h3>
          <p>
            La prioridad alta suma <strong>{self._format_area(high_area_m2)}</strong>, equivalente a <strong>{high_pct:,.2f}%</strong> del area total. Estas zonas tienen baja densidad KDE de placas.
          </p>
        </div>
      </div>
      <div class="bar">
        <div class="mapped"></div>
        <div class="missing"></div>
        <div class="empty"></div>
      </div>
      <div class="legend">
        <span><i class="dot mapped"></i>Area mapeada estimada: {mapped_pct:,.2f}%</span>
        <span><i class="dot missing"></i>Area faltante por mapear/revisar: {high_pct:,.2f}%</span>
        <span><i class="dot empty"></i>Sin construcciones: {no_construction_pct:,.2f}%</span>
      </div>
    </section>

    <section>
      <h2>Indicadores territoriales</h2>
      <div class="grid">
        <div class="card"><div class="metric mapped">{self._format_area(mapped_area_m2)}</div><div class="label">Area mapeada estimada</div></div>
        <div class="card"><div class="metric missing">{self._format_area(high_area_m2)}</div><div class="label">Area no cubierta</div></div>
        <div class="card"><div class="metric">{self._format_area(no_construction_area_m2)}</div><div class="label">Area sin construcciones</div></div>
        <div class="card"><div class="metric">{self._format_area(total_area_m2)}</div><div class="label">Area total search_mask</div></div>
        <div class="card"><div class="metric gold">{high_count:,}</div><div class="label">Hexagonos no cubiertos</div></div>
        <div class="card"><div class="metric mapped">{low_count:,}</div><div class="label">Hexagonos cubiertos</div></div>
        <div class="card"><div class="metric">{no_construction_count:,}</div><div class="label">Hexagonos sin construcciones</div></div>
        <div class="card"><div class="metric">{points_count:,}</div><div class="label">Puntos de placas</div></div>
        <div class="card"><div class="metric">{samples_count:,}</div><div class="label">Muestras KDE</div></div>
        <div class="card"><div class="metric">{total_count:,}</div><div class="label">Elementos evaluados</div></div>
      </div>
      <p class="muted">Control de consistencia: el area cubierta suma {self._format_area(low_area_m2)} ({low_pct:,.2f}% de la mascara) y el area sin construcciones queda separada para no inflar artificialmente la cobertura.</p>
    </section>

    <section>
      <h2>Distribucion de resultados</h2>
      <div class="chart-grid">
        <div class="card">
          <h3>Area por cobertura</h3>
          {coverage_chart}
        </div>
        <div class="card">
          <h3>Area por categoria_busqueda</h3>
          {category_chart}
        </div>
      </div>
    </section>

    <section>
      <h2>Criterio de decision</h2>
      <p>
        La cobertura separa primero las zonas sin soporte constructivo. Luego, solo sobre zonas con construcciones, la clase No cubierto se asigna por baja relacion KDE placas / KDE construcciones.
      </p>
      <div class="formula">
        cobertura = "Sin construcciones" si kde_construcciones_raw &lt;= umbral_kde_sin_construcciones<br />
        umbral_kde_baja_densidad = max(0, mediana(kde_superficie_raw) - desviacion_estandar(kde_superficie_raw))<br />
        cobertura = "No cubierto" si existe construccion y kde_superficie_raw &lt;= umbral_kde_baja_densidad<br />
        cobertura = "Cubierto" si existe construccion y el ratio es normal, medio o alto
      </div>
      <div class="grid">
        <div class="card"><div class="metric gold">{threshold:,.6f}</div><div class="label">Umbral KDE baja densidad</div></div>
        <div class="card"><div class="metric">{no_construction_threshold:,.6f}</div><div class="label">Umbral sin construcciones</div></div>
        <div class="card"><div class="metric">{kde_min:,.6f}</div><div class="label">KDE minimo</div></div>
        <div class="card"><div class="metric">{kde_mean:,.6f}</div><div class="label">KDE promedio</div></div>
        <div class="card"><div class="metric">{kde_max:,.6f}</div><div class="label">KDE maximo</div></div>
      </div>
      <p class="muted">Criterio aplicado: {self._report_value(criterion)}</p>
    </section>

    <section>
      <h2>Parametros del modelo</h2>
      <table>
        <tbody>
          <tr><th>Parametro</th><th>Valor</th></tr>
          <tr><td>Base de datos</td><td>{self._report_value(params.get("dbname"))}</td></tr>
          <tr><td>SRID de analisis</td><td>{self._report_value(params.get("analysis_srid"))}</td></tr>
          <tr><td>Ancho de banda</td><td>{self._report_value(params.get("bandwidth_m"))} m</td></tr>
          <tr><td>Radio de busqueda</td><td>{self._report_value(params.get("search_radius_m"))} m</td></tr>
          <tr><td>Funcion kernel</td><td>{self._report_value(params.get("kernel_type"))}</td></tr>
          <tr><td>Asignacion KDE</td><td>{self._report_value(params.get("kde_assignment"))}</td></tr>
        </tbody>
      </table>
    </section>

    <section>
      <h2>Celdas que explican las zonas no cubiertas</h2>
      {high_table}
    </section>
  </main>
</body>
</html>
"""
        report_path.write_text(document, encoding="utf-8")
        self.last_report_path = report_path
        self.add_log(f"Informe HTML generado: {report_path}", "success")
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(report_path)))

    def _run_analysis(self):
        if not self.confirmed_analysis_layer_id:
            self.add_log("Primero confirme la capa a analizar en el panel 2 - Capas.", "error")
            return

        layer = self._selected_analysis_layer()

        if layer is None or not isinstance(layer, QgsVectorLayer):
            self.add_log(
                "La capa confirmada ya no esta disponible. Actualice la lista y confirmela de nuevo.",
                "error",
            )
            return

        if layer.geometryType() != 0:
            self.add_log("La capa seleccionada para analisis debe ser una capa de puntos.", "error")
            return

        if not self._has_valid_admin_selection():
            if self._has_manual_admin_mask() and not self._has_manual_urban_footprint():
                self.add_log(
                    "Para el flujo manual debe importar tambien la huella urbana. La mascara sera la interseccion entre delimitacion administrativa y huella urbana.",
                    "error",
                )
                return
            if self._has_manual_admin_mask() and not self._has_manual_constructions():
                self.add_log(
                    "Para el flujo manual debe importar tambien las construcciones. Estas alimentan el KDE de construcciones ponderado por area.",
                    "error",
                )
                return
            if self._has_manual_admin_mask() and not self._manual_constructions_intersect_context():
                self.add_log(
                    "Las construcciones deben intersectar tanto la delimitacion administrativa como la huella urbana.",
                    "error",
                )
                return
            self.add_log(
                "Seleccione departamento / municipio validos o importe delimitacion administrativa, huella urbana y construcciones locales con interseccion.",
                "error",
            )
            return

        method = "kde"
        radius = float(self.radius_spin.value())
        search_radius = float(self.search_radius_spin.value())
        kernel_type = self.kernel_combo.currentText().split("-")[0].strip()
        weight = self.weight_edit.text().strip()
        self.metric_method.setText(f"METHOD: {method.upper()}")
        self.metric_radius.setText(f"BANDWIDTH: {radius:g} m")
        self.metric_kernel.setText(f"KERNEL: {kernel_type}")
        self.analysis_preview.set_layer_name(layer.name())
        self.analysis_preview.set_heatmap(True)
        self.last_analysis_result = None
        if hasattr(self, "generate_report_btn"):
            self.generate_report_btn.setEnabled(False)

        self.add_log(f"Ejecutando analisis {method} sobre capa '{layer.name()}'...", "info")
        self._set_processing_state(True, 12)
        QApplication.processEvents()
        try:
            self.progress.setValue(45)
            QApplication.processEvents()
            analysis = DensityAnalysis(
                feedback=lambda msg: self.add_log(msg, "info"),
                db_manager=self.db,
            )
            ok, msg, result = analysis.run(
                layer,
                method=method,
                radius=radius,
                weight_field=weight,
                country=self.country_combo.currentText().strip(),
                nivel_1=self._selected_department_name(),
                nivel_2=self._selected_city_name(),
                dbname=self._selected_dbname(),
                config_path=str(self.json_dir / "config_Sincontra.json"),
                mapping_path=self._runtime_mapping_path_for_analysis(),
                mask_gdf=self._selected_admin_mask_gdf(),
                construction_context_gdf=self._selected_constructions_gdf(),
                search_radius_m=search_radius,
                kernel_type=kernel_type,
                pixel_size=radius,
            )
            self.progress.setValue(100)
            QApplication.processEvents()
            if ok:
                self.last_analysis_result = result
                if hasattr(self, "generate_report_btn"):
                    self.generate_report_btn.setEnabled(True)
                self.add_log(msg, "success")
                self.add_log("Renderizando resultado y refrescando capas del proyecto...", "info")
                self._refresh_qgis_layers(silent=True)
                self.map_preview.set_heatmap(True)
            else:
                self.add_log(msg, "error")
        except Exception as exc:
            self.add_log("Error ejecutando analisis: " + str(exc), "error")
            self.add_log(traceback.format_exc(), "error")
        finally:
            QTimer.singleShot(650, lambda: self._set_processing_state(False, 0))

    def _page_analysis(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        config_card, config = self._card("Analisis de densidad", True)
        self.analysis_layer_combo = QComboBox()
        self.analysis_layer_combo.currentTextChanged.connect(
            lambda text: (self._on_analysis_layer_changed(text), self._update_analysis_summary())
        )
        self.analysis_method_combo = QComboBox()
        self.analysis_method_combo.addItems(["kde - Densidad Kernel"])
        self.radius_spin = QDoubleSpinBox()
        self.radius_spin.setRange(1, 999999)
        self.radius_spin.setValue(500)
        self.radius_spin.setSuffix(" m")
        self.radius_spin.valueChanged.connect(lambda _value: self._update_analysis_summary())
        self.search_radius_spin = QDoubleSpinBox()
        self.search_radius_spin.setRange(1, 999999)
        self.search_radius_spin.setValue(500)
        self.search_radius_spin.setSuffix(" m")
        self.search_radius_spin.valueChanged.connect(lambda _value: self._update_analysis_summary())
        self.kernel_combo = QComboBox()
        self.kernel_combo.addItems([
            "epanechnikov - Epanechnikov",
            "gaussian - Gaussiano",
            "triangular - Triangular",
            "quartic - Cuartico",
        ])
        self.kernel_combo.currentTextChanged.connect(lambda _text: self._update_analysis_summary())
        self.weight_edit = self._line("")

        self.analysis_hint = QLabel(
            "El complemento usara el departamento y municipio seleccionados, la base del pais, "
            "la capa de puntos seleccionada en esta lista y los parametros KDE definidos aqui."
        )
        self.analysis_hint.setObjectName("hint")
        self.analysis_hint.setWordWrap(True)
        config.addWidget(self.analysis_hint)

        params_grid = QGridLayout()
        params_grid.setHorizontalSpacing(14)
        params_grid.setVerticalSpacing(11)
        params = [
            ("Ancho de banda KDE", self.radius_spin),
            ("Radio de busqueda", self.search_radius_spin),
            ("Funcion kernel", self.kernel_combo),
        ]
        for row_idx, (label, widget) in enumerate(params):
            params_grid.addWidget(self._label(label), row_idx, 0)
            params_grid.addWidget(widget, row_idx, 1)
        config.addLayout(params_grid)

        self.run_analysis_btn = self._primary("Ejecutar analisis de densidad")
        self.run_analysis_btn.clicked.connect(self._run_analysis)
        config.addWidget(self.run_analysis_btn)
        self.auto_analysis_summary = QLabel("")
        self.auto_analysis_summary.setObjectName("hint")
        self.auto_analysis_summary.setWordWrap(True)
        config.addWidget(self.auto_analysis_summary)

        preview_card, preview = self._card("Modelo de Densidad Kernel", False)
        self.generate_report_btn = QPushButton("Generar informe HTML")
        self.generate_report_btn.setObjectName("dangerButton")
        self.generate_report_btn.setCursor(Qt.PointingHandCursor)
        self.generate_report_btn.setEnabled(False)
        self.generate_report_btn.clicked.connect(self._generate_density_report)
        preview.addWidget(self.generate_report_btn)
        self.analysis_preview = MapPreviewWidget()
        self.analysis_preview.set_heatmap(True)
        preview.addWidget(self.analysis_preview, 1)
        metrics = QHBoxLayout()
        self.metric_method = QLabel("METHOD: KDE")
        self.metric_method.setObjectName("metric")
        self.metric_radius = QLabel("BANDWIDTH: 500 m")
        self.metric_radius.setObjectName("metric")
        self.metric_kernel = QLabel("KERNEL: epanechnikov")
        self.metric_kernel.setObjectName("metric")
        metrics.addWidget(self.metric_method)
        metrics.addWidget(self.metric_radius)
        metrics.addWidget(self.metric_kernel)
        metrics.addStretch(1)
        preview.addLayout(metrics)

        row.addWidget(config_card, 1)
        row.addWidget(preview_card, 1)
        layout.addLayout(row, 1)
        self._update_analysis_summary()
        return page

    def _update_analysis_summary(self):
        if not hasattr(self, "auto_analysis_summary"):
            return
        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        city = self._selected_city_name()
        dep = self._selected_department_name()
        dbname = self._selected_dbname()
        run = self._selected_run()
        selected_layer = self._selected_analysis_layer()
        selected_name = selected_layer.name() if isinstance(selected_layer, QgsVectorLayer) else "sin capa seleccionada"
        confirmation_state = "confirmada" if self.confirmed_analysis_layer_id else "pendiente de confirmar en panel 2 - Capas"
        mask_source = (
            f"manual: {self.manual_admin_mask_name} ∩ {self.manual_urban_footprint_name or 'huella urbana pendiente'} | construcciones: {self.manual_constructions_name or 'pendientes'}"
            if self._has_manual_admin_mask()
            else "base de datos / seleccion administrativa"
        )
        db_source = "no requerida en flujo manual" if self._has_manual_admin_mask() else dbname
        self.auto_analysis_summary.setText(
            f"Pais: {country}\n"
            f"Departamento / nivel 1: {dep}\n"
            f"Municipio / nivel 2: {city}\n"
            f"Mascara: {mask_source}\n"
            f"Base: {db_source}\n"
            f"Capa que se ejecutara: {selected_name}\n"
            f"Estado de capa: {confirmation_state}\n"
            f"Ancho de banda: {self.radius_spin.value():g} m\n"
            f"Radio de busqueda: {self.search_radius_spin.value():g} m\n"
            f"Kernel: {self.kernel_combo.currentText().split('-')[0].strip()}"
        )
