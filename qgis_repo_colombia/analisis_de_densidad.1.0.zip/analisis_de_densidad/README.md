# Analisis de densidad

Complemento QGIS para ejecutar el flujo de analisis de densidad KDE desde una interfaz nativa PyQt.

## Cambio importante de esta version

Esta rama usa un identificador tecnico propio: `analisis_de_densidad`. Eso permite instalarla en QGIS junto a la alternativa cuyo paquete se llama `qgis_plate_analyzer`, sin que una herramienta reemplace a la otra.

## Instalacion

1. Abrir QGIS.
2. Ir a **Complementos -> Administrar e instalar complementos -> Instalar desde ZIP**.
3. Seleccionar `analisis_de_densidad_importar_qgis.zip`.
4. Activar **Analisis de densidad**.

## Estructura

```text
analisis_de_densidad/
|-- metadata.txt
|-- __init__.py
|-- analisis_de_densidad.py
|-- core/
|   |-- db_manager.py
|   |-- admin_mask.py
|   `-- density_analysis.py
|-- ui/
|   `-- main_dialog.py
|-- web/
|   |-- index.html
|   |-- styles.css
|   `-- app.js
`-- docs/
    `-- fundamentos_teoricos_planchas_dinamico.html
```

La carpeta `web/` queda como respaldo de la interfaz HTML, pero QGIS carga la interfaz nativa para evitar depender de QtWebEngine.
