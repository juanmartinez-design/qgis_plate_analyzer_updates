# -*- coding: utf-8 -*-
"""Entry point required by QGIS for the Analisis de densidad plugin."""


def classFactory(iface):  # pylint: disable=invalid-name
    """QGIS calls this function to instantiate the plugin."""
    from .analisis_de_densidad import AnalisisDeDensidad
    return AnalisisDeDensidad(iface)
