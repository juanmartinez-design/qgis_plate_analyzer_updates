# -*- coding: utf-8 -*-
"""Core helpers for Analisis de densidad."""
