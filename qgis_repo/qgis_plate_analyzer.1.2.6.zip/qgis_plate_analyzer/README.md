# QGIS Plate Analyzer

Complemento QGIS corregido para instalarse desde ZIP.

## Cambio importante de esta versión

Esta versión **no depende de QtWebEngine**. El ZIP original tenía una interfaz React/Vite, pero algunas instalaciones de QGIS no incluyen `PyQt5.QtWebEngineWidgets` / `qgis.PyQt.QtWebEngineWidgets`. Por eso se reconstruyó la interfaz con widgets nativos PyQt, manteniendo el diseño del front: sidebar, header, cards oscuras, pestañas, consola, status bar y vista previa GIS.

## Instalación

1. Abrir QGIS.
2. Ir a **Complementos → Administrar e instalar complementos → Instalar desde ZIP**.
3. Seleccionar este ZIP.
4. Activar **QGIS Plate Analyzer**.

## Estructura

```text
qgis_plate_analyzer/
├── metadata.txt
├── __init__.py
├── qgis_plate_analyzer.py
├── core/
│   ├── db_manager.py
│   └── density_analysis.py
├── ui/
│   └── main_dialog.py
├── web/
│   ├── index.html
│   ├── styles.css
│   └── app.js
└── docs/
    └── original_react_src/
```

La carpeta `web/` queda como respaldo de la interfaz HTML, pero QGIS carga la interfaz nativa para evitar el error de QtWebEngine.
