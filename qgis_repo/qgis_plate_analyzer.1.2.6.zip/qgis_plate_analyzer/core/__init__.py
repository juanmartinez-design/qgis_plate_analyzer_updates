# -*- coding: utf-8 -*-
"""Core helpers for QGIS Plate Analyzer."""
