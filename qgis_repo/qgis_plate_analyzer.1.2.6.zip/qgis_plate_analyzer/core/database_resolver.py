"""
database_resolver.py
====================

Resuelve automáticamente a qué base de datos conectarse
según el país y, opcionalmente, la ciudad/municipio recibidos
desde el frontend.

Este módulo NO descubre capas.
Solo decide la conexión correcta.

Flujo:
    país + ciudad
    ↓
    config_Sincontra.json
    ↓
    dbname
    ↓
    psycopg2.connect(...)
"""

import json
import unicodedata
from pathlib import Path

import psycopg2


BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parents[1]

DEFAULT_CONFIG_PATH = BASE_DIR / "json" / "config_Sincontra.json"


def normalize_text(value):
    """
    Normaliza texto para comparar país/ciudad sin problemas de:
    - mayúsculas/minúsculas
    - espacios dobles
    - tildes
    """

    if value is None:
        return ""

    value = str(value).strip().upper()

    value = unicodedata.normalize("NFKD", value)
    value = "".join(c for c in value if not unicodedata.combining(c))

    value = " ".join(value.split())

    return value
#=====================================================================================================================================================================#=====================================================================================================================================================================
#=====================================================================================================================================================================

def load_config(config_path=DEFAULT_CONFIG_PATH):
    """
    Carga config_Sincontra.json.

    Busca el archivo en varias rutas posibles:
    1. Ruta absoluta si se pasa absoluta.
    2. Ruta relativa al directorio actual.
    3. Ruta relativa a modules/location.
    4. Ruta relativa a modules/location/json.
    5. Ruta relativa a la raíz del proyecto.
    6. Ruta relativa a la raíz del proyecto/json.
    """

    config_path = Path(config_path)

    candidate_paths = []

    if config_path.is_absolute():
        candidate_paths.append(config_path)
    else:
        candidate_paths.extend([
            Path.cwd() / config_path,
            BASE_DIR / config_path,
            BASE_DIR / "json" / config_path.name,
            PROJECT_ROOT / config_path,
            PROJECT_ROOT / "json" / config_path.name,
        ])

    for path in candidate_paths:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)

    checked = "\n".join(str(p) for p in candidate_paths)

    raise FileNotFoundError(
        "No se encontró el archivo de configuración.\n"
        f"Nombre solicitado: {config_path}\n\n"
        "Rutas revisadas:\n"
        f"{checked}"
    )

#=====================================================================================================================================================================
#=====================================================================================================================================================================

def get_db_credentials(config):
    """
    Extrae las credenciales generales de conexión.

    En tu config están en:

        config["db"]

    Ejemplo:
        host
        port
        user
        password
    """

    if "db" not in config:
        raise KeyError("El archivo config no tiene la sección 'db'.")

    db = config["db"]

    required = ["host", "port", "user", "password"]

    missing = [k for k in required if k not in db]

    if missing:
        raise KeyError(
            f"Faltan campos obligatorios en config['db']: {missing}"
        )

    return db
#=====================================================================================================================================================================
#=====================================================================================================================================================================

def get_runs(config, only_enabled=False):
    """
    Retorna la lista de runs configurados.

    Si only_enabled=True, solo devuelve los runs habilitados.
    """

    runs = config.get("runs", [])

    if not isinstance(runs, list):
        raise TypeError("La sección 'runs' debe ser una lista.")

    if only_enabled:
        runs = [r for r in runs if r.get("enabled") is True]

    return runs

#=====================================================================================================================================================================
#=====================================================================================================================================================================

def resolve_run_by_country_city(
    config,
    country,
    nivel_1=None,
    nivel_2=None
):
    """
    Busca el run correspondiente según el país.

    IMPORTANTE:
    Este módulo solo decide la conexión a la base de datos.

    El país define:
        country -> dbname

    Los niveles administrativos:
        nivel_1 -> departamento / provincia / estado
        nivel_2 -> municipio / cantón / distrito / ciudad

    NO se usan para decidir la conexión.
    Solo quedan guardados como contexto en run["selected_admin"].
    """

    runs = get_runs(config, only_enabled=False)

    country_norm = normalize_text(country)

    if not country_norm:
        enabled_runs = get_runs(config, only_enabled=True)

        if not enabled_runs:
            raise ValueError(
                "El país es obligatorio para resolver la base de datos "
                "o debe existir un run con enabled=true en config_Sincontra.json."
            )

        run = enabled_runs[0]

    else:
        country_matches = [
            r for r in runs
            if normalize_text(r.get("country")) == country_norm
            or normalize_text(r.get("country_code")) == country_norm
        ]

        if not country_matches:
            available = sorted({
                str(r.get("country"))
                for r in runs
                if r.get("country")
            })

            available_codes = sorted({
                str(r.get("country_code"))
                for r in runs
                if r.get("country_code")
            })

            raise RuntimeError(
                f"No existe configuración para el país '{country}'.\n"
                f"Países disponibles: {available}\n"
                f"Códigos disponibles: {available_codes}"
            )

        run = country_matches[0]

    selected_admin = {
        "country": country,
        "nivel_1": nivel_1,
        "nivel_2": nivel_2
    }

    run = dict(run)
    run["selected_admin"] = selected_admin

    return run

# =====================================================================================================================================================================
# =====================================================================================================================================================================

def get_dbname_from_run(run_config):
    """
    Obtiene dbname desde el run seleccionado.
    """

    dbname = run_config.get("dbname")

    if not dbname:
        raise KeyError(
            f"El run seleccionado no tiene 'dbname': {run_config}"
        )

    return dbname


# =====================================================================================================================================================================
# =====================================================================================================================================================================

def open_connection_from_config(config, dbname):
    """
    Abre conexión psycopg2 usando las credenciales generales
    y la dbname resuelta desde el país.
    """

    db = get_db_credentials(config)

    return psycopg2.connect(
        host=db["host"],
        port=db.get("port", 5432),
        dbname=dbname,
        user=db["user"],
        password=db["password"],
    )


# =====================================================================================================================================================================
# =====================================================================================================================================================================

def resolve_database(
    country,
    nivel_1=None,
    nivel_2=None,
    config_path=DEFAULT_CONFIG_PATH
):
    """
    Resuelve la base de datos correspondiente al país.

    Retorna:
        {
            "dbname": "...",
            "run": {...},
            "config": {...}
        }

    Esta función NO abre conexión.
    Solo resuelve metadata.

    Lógica:
        country -> decide la base de datos
        nivel_1 -> contexto administrativo
        nivel_2 -> contexto administrativo
    """

    config = load_config(config_path)

    run = resolve_run_by_country_city(
        config=config,
        country=country,
        nivel_1=nivel_1,
        nivel_2=nivel_2
    )

    dbname = get_dbname_from_run(run)

    return {
        "dbname": dbname,
        "run": run,
        "config": config,
    }

# =====================================================================================================================================================================
# =====================================================================================================================================================================

def resolve_connection(
    country,
    nivel_1=None,
    nivel_2=None,
    config_path=DEFAULT_CONFIG_PATH
):
    """
    Resuelve país y abre conexión a la base correcta.

    Retorna:
        conn, dbname, run_config

    Uso recomendado:

        conn, dbname, run = resolve_connection(
            country=PAIS_SELECCIONADO,
            nivel_1=NIVEL_1_SELECCIONADO,
            nivel_2=NIVEL_2_SELECCIONADO,
            config_path=CONFIG_PATH
        )

    Donde:
        country  -> país seleccionado
        nivel_1  -> departamento / provincia / estado
        nivel_2  -> municipio / cantón / distrito / ciudad

    Importante:
        Solo country decide la conexión.
        nivel_1 y nivel_2 NO deciden la conexión.
        Solo quedan guardados en run["selected_admin"].
    """

    resolved = resolve_database(
        country=country,
        nivel_1=nivel_1,
        nivel_2=nivel_2,
        config_path=config_path,
    )

    dbname = resolved["dbname"]
    run = resolved["run"]
    config = resolved["config"]

    conn = open_connection_from_config(
        config=config,
        dbname=dbname
    )

    return conn, dbname, run