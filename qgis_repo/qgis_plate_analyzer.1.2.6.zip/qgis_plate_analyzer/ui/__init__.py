# -*- coding: utf-8 -*-
"""User interface package for QGIS Plate Analyzer."""
