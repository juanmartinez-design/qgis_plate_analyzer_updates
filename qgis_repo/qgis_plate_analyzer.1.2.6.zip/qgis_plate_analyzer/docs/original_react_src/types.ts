/**
 * Types and interfaces for the QGIS Plate Analyzer application
 */

export interface DbConfig {
  host: string;
  port: string;
  database: string;
  user: string;
  password?: string;
}

export interface GeoFilter {
  schema: string;
  country: string;
  city: string;
}

export interface QgisLayer {
  id: string;
  name: string;
  srid: string;
  type: 'Vectorial' | 'Raster';
  geometryType: 'Polygon' | 'Point' | 'LineString';
  featureCount: number;
  extent: string;
}

export interface PostgisTable {
  schema: string;
  name: string;
  geometryColumn: string;
  srid: number;
  type: string;
}

export type AnalysisMethod = 'kde' | 'dbscan' | 'nearest_neighbor' | 'getis_ord';

export interface AnalysisConfig {
  method: AnalysisMethod;
  radius: number;
  pixelSize: number;
  weightField: string;
}

export interface LogEntry {
  timestamp: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
}
