import React, { useState, useEffect } from 'react';
import { Database, HelpCircle, Settings, Terminal, MapPin, RefreshCw, Layers } from 'lucide-react';
import Sidebar from './components/Sidebar';
import StatusBar from './components/StatusBar';
import ConnectionTab from './components/ConnectionTab';
import LayersTab from './components/LayersTab';
import AnalysisTab from './components/AnalysisTab';
import SystemLogs from './components/SystemLogs';
import { DbConfig, GeoFilter, AnalysisConfig, LogEntry } from './types';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<number>(1);

  // States
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [systemStatus, setSystemStatus] = useState<string>('Disconnected');
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [showHeatmap, setShowHeatmap] = useState<boolean>(false);

  // Configurations
  const [dbConfig, setDbConfig] = useState<DbConfig>({
    host: 'localhost',
    port: '5432',
    database: 'gis_db',
    user: 'postgres',
  });

  const [geoFilter, setGeoFilter] = useState<GeoFilter>({
    schema: 'public',
    country: 'Colombia',
    city: 'Bogotá D.C.',
  });

  const [activeQgisLayer, setActiveQgisLayer] = useState<string>('manzanas_catastrales_v1');
  const [maskEnabled, setMaskEnabled] = useState<boolean>(true);

  const [analysisConfig, setAnalysisConfig] = useState<AnalysisConfig>({
    method: 'kde',
    radius: 500,
    pixelSize: 50,
    weightField: '',
  });

  // Logs Engine
  const [logs, setLogs] = useState<LogEntry[]>([
    { timestamp: '[14:22:01]', message: "Inicializando plugin de QGIS 'Análisis de Placas'...", type: 'info' },
    { timestamp: '[14:22:02]', message: "Comprobando dependencias del sistema Python (GDAL, Psycopg2, Pandas)... OK", type: 'success' },
    { timestamp: '[14:22:03]', message: "Esperando conexión a base de datos externa de PostGIS...", type: 'warning' },
  ]);

  const addLog = (message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const timestamp = `[${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}]`;
    
    setLogs((prev) => [...prev, { timestamp, message, type }]);
  };

  const handleClearLogs = () => {
    setLogs([]);
  };

  // Sync isConnected with systemStatus
  useEffect(() => {
    if (systemStatus === 'PROCESSING') return; // Don't override processing
    setSystemStatus(isConnected ? 'Connected' : 'Disconnected');
  }, [isConnected]);

  // Handler when Municipality Layer gets loaded in Connection tab
  const handleLoadMunicipality = () => {
    addLog(`Cargando capa vectorial de límites del municipio: ${geoFilter.city} (${geoFilter.country})...`, 'info');
    
    // Simulate loading
    setTimeout(() => {
      addLog(`Extrayendo geometrías administrativas para SRID:4326...`, 'info');
    }, 400);

    setTimeout(() => {
      addLog(`¡Capa vectorial '${geoFilter.city.toLowerCase().replace(/\s/g, '_')}_limite' agregada correctamente al proyecto QGIS!`, 'success');
      // Switch to layer tab so user can see it active
      setActiveTab(2);
    }, 900);
  };

  // Handler when layer is added from PostGIS
  const handleAddPostgisLayer = (schema: string, tableName: string) => {
    addLog(`Conectando al catálogo PostGIS. Leyendo tabla: ${schema}.${tableName}...`, 'info');
    
    setTimeout(() => {
      addLog(`Detectando columnas de geometría... Encontrada columna 'geom' de tipo MULTIPOLYGON (SRID:4326).`, 'success');
      setActiveQgisLayer(tableName);
      addLog(`Capa '${tableName}' agregada al proyecto QGIS con éxito.`, 'success');
    }, 700);
  };

  // Shortcut connect database from sidebar
  const handleSidebarConnectClick = () => {
    if (isConnected) {
      addLog('Desconectando base de datos a petición del usuario...', 'warning');
      setIsConnected(false);
    } else {
      setActiveTab(1);
      addLog('Por favor, verifique sus credenciales de PostGIS y pulse el botón "Conectar".', 'info');
    }
  };

  // Get last message for bottom ticker
  const getLastLogMessage = () => {
    if (logs.length === 0) return 'Esperando acciones...';
    return logs[logs.length - 1].message;
  };

  return (
    <div className="flex h-screen bg-surface-lowest text-on-surface font-sans overflow-hidden">
      
      {/* Left Sidebar Menu */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isConnected={isConnected}
        onConnectClick={handleSidebarConnectClick}
      />

      {/* Main Workspace Frame */}
      <main className="flex-1 flex flex-col h-full min-w-0 bg-[#070708]">
        
        {/* Top Header */}
        <header className="h-14 border-b border-outline-variant/35 bg-surface/85 backdrop-blur-md px-6 flex items-center justify-between shrink-0 select-none z-30">
          <div className="flex items-center gap-3">
            <h2 className="text-sm font-extrabold uppercase tracking-widest text-[#00f5ff]">
              Análisis de Placas
            </h2>
            <div className="h-4 w-px bg-outline-variant/40" />
            <span className="text-xs font-semibold text-on-surface-variant">
              {activeTab === 1 ? 'Handshake & Configuración' : activeTab === 2 ? 'Gestión de Capas' : 'Modelo de Densidad Kernel'}
            </span>
          </div>

          {/* Quick Toolbar icons */}
          <div className="flex items-center gap-4 text-on-surface-variant">
            <button
              onClick={() => setActiveTab(1)}
              className="hover:text-primary transition-colors cursor-pointer"
              title="Base de datos"
            >
              <Database className="w-4 h-4" />
            </button>
            <button
              className="hover:text-primary transition-colors cursor-pointer"
              title="Preferencias"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Tab content area (Scrollable) */}
        <div className="flex-1 overflow-y-auto px-6 py-6 scrollbar-thin">
          <div className="pb-12">
            {activeTab === 1 && (
              <ConnectionTab
                dbConfig={dbConfig}
                setDbConfig={setDbConfig}
                geoFilter={geoFilter}
                setGeoFilter={setGeoFilter}
                isConnected={isConnected}
                setIsConnected={setIsConnected}
                addLog={addLog}
                onLoadMunicipality={handleLoadMunicipality}
                maskEnabled={maskEnabled}
              />
            )}

            {activeTab === 2 && (
              <LayersTab
                isConnected={isConnected}
                activeQgisLayer={activeQgisLayer}
                setActiveQgisLayer={setActiveQgisLayer}
                maskEnabled={maskEnabled}
                setMaskEnabled={setMaskEnabled}
                addLog={addLog}
                onAddPostgisLayer={handleAddPostgisLayer}
              />
            )}

            {activeTab === 3 && (
              <AnalysisTab
                analysisConfig={analysisConfig}
                setAnalysisConfig={setAnalysisConfig}
                isConnected={isConnected}
                activeQgisLayer={activeQgisLayer}
                addLog={addLog}
                setProgressPercent={setProgressPercent}
                setSystemStatus={setSystemStatus}
                onShowHeatmap={setShowHeatmap}
              />
            )}
          </div>
        </div>

        {/* Console / Output logs area */}
        <div className="h-32 shrink-0 border-t border-outline-variant/35 bg-surface/60 backdrop-blur-md">
          <SystemLogs logs={logs} onClear={handleClearLogs} />
        </div>

        {/* Bottom footer status */}
        <StatusBar
          systemStatus={systemStatus}
          epsg="EPSG:4326 (WGS 84)"
          lastLogMessage={getLastLogMessage()}
          progressPercent={progressPercent}
        />
      </main>
    </div>
  );
}
