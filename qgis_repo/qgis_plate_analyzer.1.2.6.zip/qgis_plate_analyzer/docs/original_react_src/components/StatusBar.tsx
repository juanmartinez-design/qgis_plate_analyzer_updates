import React, { useState, useEffect } from 'react';
import { Cpu, RotateCw, ExternalLink, HelpCircle } from 'lucide-react';

interface StatusBarProps {
  systemStatus: string; // 'Connected' | 'PROCESSING' | 'Disconnected'
  epsg: string;
  lastLogMessage: string;
  progressPercent: number;
}

export default function StatusBar({
  systemStatus = 'Connected',
  epsg = 'EPSG:4326 (WGS 84)',
  lastLogMessage = "Capa 'tbl_placas_georef' cargada correctamente desde el esquema 'public'...",
  progressPercent = 0,
}: StatusBarProps) {
  const [memoryUsage, setMemoryUsage] = useState<number>(41.8);

  // Slow dynamic memory oscillation simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setMemoryUsage((prev) => {
        const delta = (Math.random() - 0.5) * 0.8;
        return parseFloat(Math.max(38.0, Math.min(46.0, prev + delta)).toFixed(1));
      });
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <footer className="h-10 bg-surface-container-lowest border-t border-outline-variant flex items-center justify-between px-4 select-none shrink-0 z-40 text-[11px]">
      
      {/* Left items - Status & Coordinate Systems */}
      <div className="flex items-center gap-5">
        <div className="flex items-center gap-2 cursor-pointer group">
          <span className={`w-2.5 h-2.5 rounded-full status-pulse ${
            systemStatus === 'PROCESSING'
              ? 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)] animate-spin border border-amber-600'
              : systemStatus === 'Connected'
              ? 'bg-secondary shadow-[0_0_8px_rgba(78,222,163,0.6)]'
              : 'bg-error shadow-[0_0_8px_rgba(255,180,171,0.6)]'
          }`} />
          <span className={`font-mono font-bold tracking-wide uppercase transition-colors group-hover:text-white ${
            systemStatus === 'PROCESSING'
              ? 'text-amber-400'
              : systemStatus === 'Connected'
              ? 'text-secondary'
              : 'text-error'
          }`}>
            {systemStatus === 'PROCESSING' ? 'Engine: Processing' : `Base de datos: ${systemStatus === 'Connected' ? 'Conectado' : 'Desconectado'}`}
          </span>
        </div>

        <div className="h-3.5 w-px bg-outline-variant/50" />

        <div className="flex items-center gap-1 text-on-surface-variant font-mono">
          <span className="font-semibold text-white/90">{epsg}</span>
        </div>
      </div>

      {/* Middle item - Live Log Ticker / Progress bar */}
      <div className="flex-1 flex justify-center max-w-xl mx-auto px-6">
        {systemStatus === 'PROCESSING' || progressPercent > 0 ? (
          /* Show active processing bar if executing */
          <div className="w-full flex items-center gap-3">
            <span className="font-mono text-[10px] text-amber-400 font-bold shrink-0 uppercase tracking-widest animate-pulse">
              Running
            </span>
            <div className="flex-1 h-1.5 bg-surface-container-high rounded-full overflow-hidden border border-outline-variant/20">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-[#00f5ff] transition-all duration-300 shadow-[0_0_8px_rgba(0,245,255,0.6)]"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="font-mono text-white/90 font-bold w-10 text-right shrink-0">
              {progressPercent}%
            </span>
          </div>
        ) : (
          /* Show log ticker */
          <div className="bg-black/35 border border-outline-variant/30 rounded px-3 py-1 w-full overflow-hidden flex items-center gap-2 select-text font-mono">
            <span className="text-[9px] font-bold text-[#00f5ff]/60 uppercase shrink-0 tracking-wider">LOG:</span>
            <span className="text-on-surface-variant text-[11px] font-mono truncate" title={lastLogMessage}>
              {lastLogMessage}
            </span>
          </div>
        )}
      </div>

      {/* Right items - Memory, Documentation */}
      <div className="flex items-center gap-4">
        {/* Memory Readout */}
        <div className="flex items-center gap-1.5 text-on-surface-variant/80 font-mono">
          <Cpu className="w-3.5 h-3.5 text-on-surface-variant/50 shrink-0" />
          <span>Mem: <b className="text-white/90 font-mono font-bold">{memoryUsage} MB</b></span>
        </div>

        <div className="h-3.5 w-px bg-outline-variant/50" />

        {/* Resources Links */}
        <div className="flex items-center gap-3 text-on-surface-variant">
          <a
            href="https://qgis.org/es/site/"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-primary transition-all flex items-center gap-0.5 font-sans font-semibold cursor-pointer"
          >
            Documentation
            <ExternalLink className="w-2.5 h-2.5 text-on-surface-variant/40" />
          </a>
          <span className="text-outline-variant/40">•</span>
          <a
            href="https://github.com/qgis/QGIS/issues"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-primary transition-all font-sans font-semibold cursor-pointer"
          >
            Issue Tracker
          </a>
        </div>
      </div>
    </footer>
  );
}
