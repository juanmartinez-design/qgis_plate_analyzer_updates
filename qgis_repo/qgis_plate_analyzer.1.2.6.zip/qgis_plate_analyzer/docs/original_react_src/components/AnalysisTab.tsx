import React, { useState, useEffect } from 'react';
import { Sliders, Scale, Play, CheckCircle2, TrendingUp, Cpu, Award } from 'lucide-react';
import { AnalysisConfig, AnalysisMethod } from '../types';

interface AnalysisTabProps {
  analysisConfig: AnalysisConfig;
  setAnalysisConfig: React.Dispatch<React.SetStateAction<AnalysisConfig>>;
  isConnected: boolean;
  activeQgisLayer: string;
  addLog: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  setProgressPercent: React.Dispatch<React.SetStateAction<number>>;
  setSystemStatus: React.Dispatch<React.SetStateAction<string>>;
  onShowHeatmap: (show: boolean) => void;
}

export default function AnalysisTab({
  analysisConfig,
  setAnalysisConfig,
  isConnected,
  activeQgisLayer,
  addLog,
  setProgressPercent,
  setSystemStatus,
  onShowHeatmap,
}: AnalysisTabProps) {
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [showResults, setShowResults] = useState<boolean>(false);

  const methods = [
    { value: 'kde', label: 'Densidad Kernel (KDE)', hint: 'Recomendado para interpolación de puntos con decaimiento suave.' },
    { value: 'dbscan', label: 'Agrupamiento Espacial (DBSCAN)', hint: 'Algoritmo basado en densidad para agrupar puntos con ruido.' },
    { value: 'nearest_neighbor', label: 'Vecino más Cercano (NN)', hint: 'Mide distancia promedio entre puntos para analizar dispersión.' },
    { value: 'getis_ord', label: 'Puntos Calientes (Getis-Ord Gi*)', hint: 'Identifica agrupamientos de valores altos/bajos con significancia estadística.' },
  ];

  const weightFields = [
    { value: '', label: 'Sin campo de peso' },
    { value: 'intensidad_placas', label: 'intensidad_placas' },
    { value: 'poblacion_afectada', label: 'poblacion_afectada' },
    { value: 'antiguedad_anos', label: 'antiguedad_anos' },
  ];

  const handleMethodChange = (val: string) => {
    setAnalysisConfig((prev) => ({ ...prev, method: val as AnalysisMethod }));
    const hint = methods.find((m) => m.value === val)?.hint;
    if (hint) {
      addLog(`Cambiado método de análisis a: ${val.toUpperCase()} (${hint})`, 'info');
    }
  };

  const handleConfigChange = (field: keyof AnalysisConfig, val: any) => {
    setAnalysisConfig((prev) => ({ ...prev, [field]: val }));
  };

  const executeAnalysis = () => {
    if (!isConnected) {
      addLog('Error: Debe establecer conexión con PostGIS antes de ejecutar el análisis.', 'error');
      return;
    }
    if (!activeQgisLayer) {
      addLog('Error: Por favor, seleccione una capa activa de QGIS en la pestaña "2 · Capas".', 'error');
      return;
    }

    setIsExecuting(true);
    setShowResults(false);
    setProgressPercent(0);
    setSystemStatus('PROCESSING');
    onShowHeatmap(false);

    addLog('--- INICIANDO PROCESAMIENTO GEOPROCESAL ---', 'info');
    addLog(`Ejecutando algoritmo: ${analysisConfig.method.toUpperCase()} sobre la capa vectorial '${activeQgisLayer}'`, 'info');
    addLog(`Parámetros: Radio de búsqueda=${analysisConfig.radius}m, Celda Raster=${analysisConfig.pixelSize}m, Ponderación=${analysisConfig.weightField || 'Ninguna'}`, 'info');

    const steps = [
      { progress: 10, log: 'Inicializando KDE Kernel Provider en el hilo de procesamiento primario...', type: 'info' },
      { progress: 20, log: "Cargando índice espacial 'R-Tree' para búsqueda de vecindades acelerada...", type: 'info' },
      { progress: 35, log: `Filtrando geometrías vectoriales válidas... Encontrados 1,482,901 puntos dentro del límite municipal.`, type: 'success' },
      { progress: 50, log: `Calculando campo de peso ponderado: [${analysisConfig.weightField || 'Uniforme'}]`, type: 'info' },
      { progress: 65, log: 'Procesando interpolación en paralelo (8 Hilos de CPU activos)... [######################----] 65%', type: 'info' },
      { progress: 80, log: 'Generando grid matricial de densidades (Interpolación Cuártica bi-dimensional)...', type: 'info' },
      { progress: 90, log: 'Guardando datos matriciales comprimidos en formato GeoTIFF temporal...', type: 'info' },
      { progress: 100, log: 'Análisis completado. Generando mapa de calor raster en el Canvas de QGIS.', type: 'success' },
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        const step = steps[currentStep];
        setProgressPercent(step.progress);
        addLog(step.log, step.type as any);
        currentStep++;
      } else {
        clearInterval(interval);
        setIsExecuting(false);
        setShowResults(true);
        setSystemStatus('Connected');
        onShowHeatmap(true);
        addLog('¡Ejecución de geoprocesamiento finalizada con éxito! Capa raster agregada al panel de QGIS.', 'success');
      }
    }, 600);
  };

  // Dynamically calculate Bell Curve width based on Search Radius to visually react to input changes
  const radiusScale = Math.max(0.3, Math.min(2.0, (analysisConfig.radius || 500) / 500));
  const bellPath = `M 10 90 Q ${50} ${90 - 75 * radiusScale}, 100 ${90 - 75 * radiusScale} Q ${150} ${90 - 75 * radiusScale}, 190 90`;

  return (
    <div className="space-y-lg animate-fade-in max-w-6xl">
      {/* Configuration Panel */}
      <section className="bg-surface border border-outline-variant rounded-xl p-md shadow-lg relative overflow-hidden group">
        <div className="absolute top-0 left-0 w-1.5 h-full bg-[#00f5ff] opacity-40 group-hover:opacity-100 transition-opacity"></div>
        
        <div className="flex items-center gap-2 mb-md border-b border-outline-variant/30 pb-3">
          <span className="w-1.5 h-4 bg-primary-container rounded-full"></span>
          <div>
            <h2 className="text-md font-bold text-primary">Configuración del Algoritmo</h2>
            <p className="text-[11px] text-on-surface-variant">Defina los parámetros clave para la ejecución del modelo espacial vectorial</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-lg items-start">
          {/* Form Side - 8 Cols */}
          <div className="lg:col-span-8 space-y-md">
            {/* Metodo de Analisis */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">Método de Análisis</label>
              <div className="relative">
                <select
                  value={analysisConfig.method}
                  onChange={(e) => handleMethodChange(e.target.value)}
                  className="w-full bg-[#09090b] border border-outline-variant rounded-lg px-4 py-2.5 text-xs text-on-surface focus:border-[#00f5ff] focus:ring-1 focus:ring-[#00f5ff]/35 outline-none font-sans font-medium cursor-pointer transition-all appearance-none"
                >
                  {methods.map((m) => (
                    <option key={m.value} value={m.value}>{m.label}</option>
                  ))}
                </select>
                <span className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-on-surface-variant text-xs">
                  expand_more
                </span>
              </div>
              <p className="text-[11px] text-on-surface-variant/70 italic leading-relaxed">
                {methods.find((m) => m.value === analysisConfig.method)?.hint}
              </p>
            </div>

            {/* Inputs grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-lg">
              {/* Radio de Influencia */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">Radio de Influencia (m)</label>
                <div className="relative flex items-center">
                  <input
                    type="number"
                    value={analysisConfig.radius || ''}
                    onChange={(e) => handleConfigChange('radius', parseInt(e.target.value) || 0)}
                    min="10"
                    max="10000"
                    className="w-full bg-[#09090b] border border-outline-variant rounded-lg px-4 py-2.5 text-xs font-mono text-on-surface focus:border-[#00f5ff] outline-none transition-all pr-14"
                  />
                  <span className="absolute right-3 text-[10px] font-mono font-bold text-on-surface-variant uppercase tracking-wider select-none">
                    Meters
                  </span>
                </div>
              </div>

              {/* Tamano de Pixel */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">Tamaño de Píxel (m)</label>
                <div className="relative flex items-center">
                  <input
                    type="number"
                    value={analysisConfig.pixelSize || ''}
                    onChange={(e) => handleConfigChange('pixelSize', parseInt(e.target.value) || 0)}
                    min="1"
                    max="1000"
                    className="w-full bg-[#09090b] border border-outline-variant rounded-lg px-4 py-2.5 text-xs font-mono text-on-surface focus:border-[#00f5ff] outline-none transition-all pr-12"
                  />
                  <span className="absolute right-3 text-[10px] font-mono font-bold text-on-surface-variant uppercase tracking-wider select-none">
                    Res
                  </span>
                </div>
              </div>
            </div>

            {/* Campo de Peso */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">Campo de Peso (Atributo)</label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <select
                    value={analysisConfig.weightField}
                    onChange={(e) => handleConfigChange('weightField', e.target.value)}
                    className="w-full bg-[#09090b] border border-outline-variant rounded-lg px-4 py-2.5 text-xs text-on-surface focus:border-[#00f5ff] focus:ring-1 focus:ring-[#00f5ff]/35 outline-none font-mono cursor-pointer transition-all appearance-none"
                  >
                    {weightFields.map((f) => (
                      <option key={f.value} value={f.value}>{f.label}</option>
                    ))}
                  </select>
                  <span className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-on-surface-variant text-xs">
                    expand_more
                  </span>
                </div>
                <button
                  className="bg-surface-container-high border border-outline-variant rounded-lg px-3 hover:bg-surface-container-highest transition-all text-on-surface-variant hover:text-primary-container"
                  title="Estadísticas de Ponderación"
                >
                  <Scale className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Visualization Side - 4 Cols */}
          <div className="lg:col-span-4 bg-[#09090b] border border-outline-variant rounded-xl p-4 flex flex-col justify-between h-full min-h-[220px]">
            <div>
              <h3 className="text-xs font-bold text-[#00f5ff] tracking-wide uppercase">Vista Previa de Influencia</h3>
              <p className="text-[10px] text-on-surface-variant mt-1 leading-relaxed">
                Muestra el decaimiento de la influencia del punto según la distancia del radio de búsqueda de {analysisConfig.radius} metros.
              </p>
            </div>

            {/* Dynamic Curve */}
            <div className="h-24 w-full flex items-center justify-center relative mt-2 border border-outline-variant/30 rounded bg-black/30">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 200 100">
                {/* Axes */}
                <line x1="10" y1="90" x2="190" y2="90" stroke="rgba(58, 73, 74, 0.4)" strokeWidth="1.5" />
                <line x1="10" y1="10" x2="10" y2="90" stroke="rgba(58, 73, 74, 0.4)" strokeWidth="1.5" />

                {/* Dynamic Bell curve path */}
                <path
                  d={bellPath}
                  fill="none"
                  stroke="#00f5ff"
                  strokeWidth="2.5"
                  className="transition-all duration-300"
                />

                {/* Shading fill */}
                <path
                  d={`${bellPath} L 190 90 L 10 90 Z`}
                  fill="url(#glow-gradient)"
                  className="transition-all duration-300"
                />

                <defs>
                  <linearGradient id="glow-gradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#00f5ff" stopOpacity="0.25" />
                    <stop offset="100%" stopColor="#00f5ff" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Label text */}
                <text x="100" y="98" fill="rgba(185,202,202,0.4)" fontSize="8" textAnchor="middle" fontFamily="monospace">
                  Decaimiento Kernel
                </text>
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* Button Row */}
      <div className="flex flex-col items-center justify-center py-2">
        <button
          onClick={executeAnalysis}
          disabled={isExecuting}
          className={`relative max-w-lg w-full bg-gradient-to-r from-blue-600 to-[#00f5ff] text-white font-bold text-sm py-3.5 px-8 rounded-xl shadow-2xl transition-all active:scale-95 select-none tracking-wide cursor-pointer flex items-center justify-center gap-2.5 hover:shadow-[#00f5ff]/20 ${
            isExecuting ? 'animate-pulse opacity-75 cursor-wait' : ''
          }`}
        >
          {isExecuting ? (
            <>
              <Cpu className="w-4.5 h-4.5 animate-spin" />
              Procesando Capas Vectoriales...
            </>
          ) : (
            <>
              <Play className="w-4.5 h-4.5" />
              Ejecutar Análisis Espacial
            </>
          )}
        </button>
        <span className="text-[10px] text-on-surface-variant font-mono uppercase tracking-widest mt-2 select-none">
          Tiempo estimado: ~4.2s para 1.5M de registros vectoriales
        </span>
      </div>

      {/* Results Card after finish */}
      {showResults && (
        <div className="bg-surface border border-[#4edea3]/30 rounded-xl p-md shadow-2xl animate-fade-in border-t-4 border-t-[#4edea3] max-w-6xl">
          <div className="flex items-start gap-4">
            <div className="p-2 bg-[#4edea3]/15 border border-[#4edea3]/35 text-[#4edea3] rounded-lg shrink-0">
              <Award className="w-6 h-6 animate-bounce" />
            </div>

            <div className="space-y-md flex-1">
              <div>
                <h3 className="text-md font-bold text-primary flex items-center gap-2">
                  Análisis Completado Exitosamente
                  <CheckCircle2 className="w-4.5 h-4.5 text-secondary" />
                </h3>
                <p className="text-xs text-on-surface-variant mt-1">
                  El procesamiento de densidad Kernel ha culminado y la capa raster resultante ha sido inyectada directamente en el proyecto QGIS.
                </p>
              </div>

              {/* Key Statistics Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-md pt-2 border-t border-outline-variant/30">
                <div className="bg-[#09090b] border border-outline-variant/30 rounded-lg p-2.5 text-center">
                  <span className="text-[10px] text-on-surface-variant uppercase font-mono tracking-wider">Puntos Analizados</span>
                  <p className="text-sm font-extrabold text-white mt-1 font-mono">1,482,901</p>
                </div>
                <div className="bg-[#09090b] border border-outline-variant/30 rounded-lg p-2.5 text-center">
                  <span className="text-[10px] text-on-surface-variant uppercase font-mono tracking-wider">Dimensiones Raster</span>
                  <p className="text-sm font-extrabold text-white mt-1 font-mono">2400 x 3600 px</p>
                </div>
                <div className="bg-[#09090b] border border-outline-variant/30 rounded-lg p-2.5 text-center">
                  <span className="text-[10px] text-on-surface-variant uppercase font-mono tracking-wider">Densidad Promedio</span>
                  <p className="text-sm font-extrabold text-[#00f5ff] mt-1 font-mono">4.18 placas/km²</p>
                </div>
                <div className="bg-[#09090b] border border-outline-variant/30 rounded-lg p-2.5 text-center">
                  <span className="text-[10px] text-on-surface-variant uppercase font-mono tracking-wider">Tiempo Empleado</span>
                  <p className="text-sm font-extrabold text-secondary mt-1 font-mono">4.12 segundos</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
