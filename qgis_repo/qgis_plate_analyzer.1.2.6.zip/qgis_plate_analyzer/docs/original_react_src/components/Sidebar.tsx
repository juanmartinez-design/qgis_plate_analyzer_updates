import React from 'react';
import { Cable, Layers, LineChart, Sliders, HelpCircle, Database, LogIn, LogOut, Terminal } from 'lucide-react';

interface SidebarProps {
  activeTab: number;
  setActiveTab: (tab: number) => void;
  isConnected: boolean;
  onConnectClick: () => void;
}

export default function Sidebar({ activeTab, setActiveTab, isConnected, onConnectClick }: SidebarProps) {
  const menuItems = [
    { id: 1, label: '1 · Conexión', icon: <Cable className="w-4.5 h-4.5" /> },
    { id: 2, label: '2 · Capas', icon: <Layers className="w-4.5 h-4.5" /> },
    { id: 3, label: '3 · Análisis', icon: <LineChart className="w-4.5 h-4.5" /> },
  ];

  return (
    <aside className="w-64 h-full flex flex-col bg-surface-container-low border-r border-outline-variant shrink-0 select-none">
      {/* Branding Header */}
      <div className="p-6 border-b border-outline-variant/30">
        <h1 className="text-md font-extrabold text-white uppercase tracking-wider font-sans">
          QGIS Plate Analyzer
        </h1>
        <p className="text-[10px] text-on-surface-variant/70 font-mono tracking-widest mt-1">
          v1.2.0-stable
        </p>
      </div>

      {/* Primary Navigation Options */}
      <nav className="flex-1 py-6 flex flex-col gap-1.5">
        {menuItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-3.5 px-6 py-3 border-r-2 transition-all duration-200 cursor-pointer text-left select-none ${
                isActive
                  ? 'bg-secondary-container/10 text-secondary border-secondary font-bold scale-[0.98]'
                  : 'text-on-surface-variant hover:bg-surface-container-high/60 border-transparent hover:text-primary transition-colors'
              }`}
            >
              <span className={`transition-transform duration-200 ${isActive ? 'scale-110 text-secondary' : 'text-on-surface-variant'}`}>
                {item.icon}
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider font-sans">
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Footer / Shortcuts */}
      <div className="p-4 border-t border-outline-variant/30 space-y-3 mt-auto bg-[#0d0d0e]/40">
        {/* Quick Connect Database button */}
        <button
          onClick={onConnectClick}
          className={`w-full py-2.5 rounded-lg font-bold text-[10px] tracking-wider uppercase transition-all duration-300 shadow-md ${
            isConnected
              ? 'bg-gradient-to-r from-red-600 to-amber-600 hover:shadow-red-600/10 text-white cursor-pointer hover:scale-[1.01]'
              : 'bg-gradient-to-r from-primary-container to-blue-500 hover:shadow-primary-container/20 text-on-primary-fixed cursor-pointer hover:scale-[1.01]'
          }`}
        >
          {isConnected ? 'Disconnect Database' : 'Connect Database'}
        </button>

        {/* Configurations & Help */}
        <div className="flex flex-col gap-0.5 pt-2 border-t border-outline-variant/20">
          <button
            onClick={() => setActiveTab(1)}
            className="flex items-center gap-3 text-on-surface-variant hover:text-primary hover:bg-surface-container-high/40 px-3 py-2 rounded-lg transition-all text-left text-xs font-semibold cursor-pointer"
          >
            <Sliders className="w-3.5 h-3.5" />
            Configuración
          </button>
          <a
            href="https://qgis.org"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 text-on-surface-variant hover:text-primary hover:bg-surface-container-high/40 px-3 py-2 rounded-lg transition-all text-xs font-semibold"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            Ayuda
          </a>
        </div>
      </div>
    </aside>
  );
}
