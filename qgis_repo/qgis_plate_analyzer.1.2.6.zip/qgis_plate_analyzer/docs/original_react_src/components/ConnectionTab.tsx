import React, { useState } from 'react';
import { Database, MapPin, Map, DatabaseZap, Lock, HelpCircle } from 'lucide-react';
import { DbConfig, GeoFilter, LogEntry } from '../types';

interface ConnectionTabProps {
  dbConfig: DbConfig;
  setDbConfig: React.Dispatch<React.SetStateAction<DbConfig>>;
  geoFilter: GeoFilter;
  setGeoFilter: React.Dispatch<React.SetStateAction<GeoFilter>>;
  isConnected: boolean;
  setIsConnected: React.Dispatch<React.SetStateAction<boolean>>;
  addLog: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  onLoadMunicipality: () => void;
  maskEnabled: boolean;
}

export default function ConnectionTab({
  dbConfig,
  setDbConfig,
  geoFilter,
  setGeoFilter,
  isConnected,
  setIsConnected,
  addLog,
  onLoadMunicipality,
  maskEnabled,
}: ConnectionTabProps) {
  const [connecting, setConnecting] = useState<boolean>(false);
  const [dbPassword, setDbPassword] = useState<string>('********');

  const schemas = ['public', 'analisis_espacial', 'catastro_nacional', 'infraestructura'];
  const countries = ['Colombia', 'México', 'España', 'Chile', 'Argentina'];
  const citiesByCountry: Record<string, string[]> = {
    Colombia: ['Bogotá D.C.', 'Medellín', 'Cali', 'Barranquilla', 'Bucaramanga', 'Cartagena'],
    México: ['Ciudad de México', 'Guadalajara', 'Monterrey', 'Puebla', 'Tijuana'],
    España: ['Madrid', 'Barcelona', 'Valencia', 'Sevilla', 'Zaragoza'],
    Chile: ['Santiago', 'Valparaíso', 'Concepción', 'La Serena'],
    Argentina: ['Buenos Aires', 'Córdoba', 'Rosario', 'Mendoza'],
  };

  const handleInputChange = (field: keyof DbConfig, value: string) => {
    setDbConfig((prev) => ({ ...prev, [field]: value }));
  };

  const handleGeoChange = (field: keyof GeoFilter, value: string) => {
    setGeoFilter((prev) => {
      const updated = { ...prev, [field]: value };
      // Reset city if country changed
      if (field === 'country') {
        updated.city = '';
      }
      return updated;
    });
  };

  const toggleConnection = () => {
    if (isConnected) {
      // Disconnecting
      addLog('Cerrando conexión con la base de datos...', 'info');
      setIsConnected(false);
      addLog('Conexión cerrada. Base de datos desconectada.', 'warning');
    } else {
      // Connecting process
      setConnecting(true);
      addLog(`Intentando conectar a ${dbConfig.user}@${dbConfig.host}:${dbConfig.port}/${dbConfig.database || 'gis_db'}...`, 'info');
      
      let step = 0;
      const interval = setInterval(() => {
        step++;
        if (step === 1) {
          addLog('Estableciendo Handshake TCP con el servidor remoto...', 'info');
        } else if (step === 2) {
          addLog('Autenticando credenciales de PostgreSQL...', 'info');
        } else if (step === 3) {
          addLog('Verificando disponibilidad de la extensión PostGIS (POSTGIS="3.4.1")...', 'success');
        } else if (step === 4) {
          addLog('Handshake completo. Inicializando catálogo de esquemas y tablas espaciales.', 'info');
        } else if (step === 5) {
          clearInterval(interval);
          setConnecting(false);
          setIsConnected(true);
          addLog('¡Conexión establecida con éxito! Base de datos en línea.', 'success');
        }
      }, 500);
    }
  };

  const triggerLoadMunicipality = () => {
    if (!geoFilter.city) {
      addLog('Por favor, seleccione una ciudad/municipio para cargar.', 'error');
      return;
    }
    onLoadMunicipality();
  };

  return (
    <div className="space-y-lg animate-fade-in">
      {/* Two column configuration panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-lg max-w-6xl">
        
        {/* Panel 1: Database Configuration */}
        <section className="bg-surface border border-outline-variant rounded-xl p-md shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1.5 h-full bg-primary-container opacity-40 group-hover:opacity-100 transition-opacity"></div>
          
          <div className="flex items-center justify-between mb-lg">
            <h2 className="text-lg font-bold text-primary flex items-center gap-2">
              <Database className="w-5 h-5 text-primary-container" />
              Configuración de Base de Datos
            </h2>
            <DatabaseZap className="w-4 h-4 text-[#00f5ff]/70" />
          </div>

          <div className="space-y-md">
            {/* Host */}
            <div className="grid grid-cols-3 gap-md items-center">
              <label className="text-xs font-semibold text-on-surface-variant font-sans uppercase tracking-wider">Host</label>
              <input
                className="col-span-2 bg-surface-container-lowest border border-outline-variant rounded-lg px-3 py-2 text-on-surface font-mono text-xs focus:border-primary-container focus:ring-1 focus:ring-primary-container/30 outline-none transition-all"
                type="text"
                value={dbConfig.host}
                onChange={(e) => handleInputChange('host', e.target.value)}
                placeholder="localhost"
                disabled={connecting || isConnected}
              />
            </div>

            {/* Puerto */}
            <div className="grid grid-cols-3 gap-md items-center">
              <label className="text-xs font-semibold text-on-surface-variant font-sans uppercase tracking-wider">Puerto</label>
              <input
                className="col-span-2 bg-surface-container-lowest border border-outline-variant rounded-lg px-3 py-2 text-on-surface font-mono text-xs focus:border-primary-container focus:ring-1 focus:ring-primary-container/30 outline-none transition-all"
                type="text"
                value={dbConfig.port}
                onChange={(e) => handleInputChange('port', e.target.value)}
                placeholder="5432"
                disabled={connecting || isConnected}
              />
            </div>

            {/* Base de datos */}
            <div className="grid grid-cols-3 gap-md items-center">
              <label className="text-xs font-semibold text-on-surface-variant font-sans uppercase tracking-wider">Base de Datos</label>
              <input
                className="col-span-2 bg-surface-container-lowest border border-outline-variant rounded-lg px-3 py-2 text-on-surface font-mono text-xs focus:border-primary-container focus:ring-1 focus:ring-primary-container/30 outline-none transition-all"
                type="text"
                value={dbConfig.database}
                onChange={(e) => handleInputChange('database', e.target.value)}
                placeholder="gis_db"
                disabled={connecting || isConnected}
              />
            </div>

            {/* Usuario */}
            <div className="grid grid-cols-3 gap-md items-center">
              <label className="text-xs font-semibold text-on-surface-variant font-sans uppercase tracking-wider">Usuario</label>
              <input
                className="col-span-2 bg-surface-container-lowest border border-outline-variant rounded-lg px-3 py-2 text-on-surface font-mono text-xs focus:border-primary-container focus:ring-1 focus:ring-primary-container/30 outline-none transition-all"
                type="text"
                value={dbConfig.user}
                onChange={(e) => handleInputChange('user', e.target.value)}
                placeholder="postgres"
                disabled={connecting || isConnected}
              />
            </div>

            {/* Contraseña */}
            <div className="grid grid-cols-3 gap-md items-center">
              <label className="text-xs font-semibold text-on-surface-variant font-sans uppercase tracking-wider">Contraseña</label>
              <input
                className="col-span-2 bg-surface-container-lowest border border-outline-variant rounded-lg px-3 py-2 text-on-surface font-mono text-xs focus:border-primary-container focus:ring-1 focus:ring-primary-container/30 outline-none transition-all"
                type="password"
                value={dbPassword}
                onChange={(e) => setDbPassword(e.target.value)}
                disabled={connecting || isConnected}
              />
            </div>
          </div>

          <div className="mt-xl pt-4 border-t border-outline-variant/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className={`w-3 h-3 rounded-full status-pulse ${
                isConnected ? 'bg-secondary shadow-[0_0_8px_rgba(78,222,163,0.5)]' : 'bg-error shadow-[0_0_8px_rgba(255,180,171,0.5)]'
              }`} />
              <span className={`text-xs font-mono font-bold uppercase tracking-wider ${isConnected ? 'text-secondary' : 'text-error'}`}>
                {connecting ? 'Conectando...' : isConnected ? 'Conectado (PostGIS Activo)' : 'Desconectado'}
              </span>
            </div>

            <button
              onClick={toggleConnection}
              disabled={connecting}
              className={`font-semibold text-sm px-6 py-2.5 rounded-lg active:scale-95 hover:scale-[1.02] transition-all cursor-pointer font-sans select-none tracking-wide ${
                isConnected
                  ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-lg hover:shadow-red-600/20'
                  : 'bg-gradient-to-r from-primary-container to-secondary-container text-on-secondary-container font-extrabold neon-glow-primary'
              }`}
            >
              {connecting ? 'Conectando...' : isConnected ? 'Desconectar' : 'Conectar'}
            </button>
          </div>
        </section>

        {/* Panel 2: Geographic Filter */}
        <section className={`bg-surface border border-outline-variant rounded-xl p-md shadow-lg relative transition-all duration-500 overflow-hidden ${
          !isConnected ? 'opacity-40 grayscale pointer-events-none' : 'opacity-100'
        }`}>
          {!isConnected && (
            <div className="absolute inset-0 bg-surface-lowest/40 backdrop-blur-[1.5px] flex items-center justify-center z-10">
              <div className="bg-surface-container border border-outline-variant/70 px-4 py-3 rounded-lg flex items-center gap-3 shadow-2xl">
                <Lock className="w-4 h-4 text-primary-container animate-bounce" />
                <span className="text-xs font-bold tracking-wide uppercase text-on-surface-variant font-mono">
                  Conectar base de datos primero
                </span>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between mb-lg">
            <h2 className="text-lg font-bold text-secondary flex items-center gap-2">
              <MapPin className="w-5 h-5 text-secondary" />
              Filtro Geográfico
            </h2>
            <Map className="w-4 h-4 text-secondary/70" />
          </div>

          <div className="space-y-md">
            {/* Esquema */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">Esquema</label>
              <select
                value={geoFilter.schema}
                onChange={(e) => handleGeoChange('schema', e.target.value)}
                className="w-full bg-surface-container-lowest border border-outline-variant rounded-lg px-3 py-2 text-on-surface focus:border-secondary focus:ring-1 focus:ring-secondary/30 outline-none text-xs font-mono cursor-pointer"
              >
                <option value="">Seleccionar esquema...</option>
                {schemas.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Pais */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">País</label>
              <select
                value={geoFilter.country}
                onChange={(e) => handleGeoChange('country', e.target.value)}
                className="w-full bg-surface-container-lowest border border-outline-variant rounded-lg px-3 py-2 text-on-surface focus:border-secondary focus:ring-1 focus:ring-secondary/30 outline-none text-xs font-mono cursor-pointer"
              >
                <option value="">Seleccionar país...</option>
                {countries.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {/* Ciudad */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">Ciudad / Municipio</label>
              <select
                value={geoFilter.city}
                onChange={(e) => handleGeoChange('city', e.target.value)}
                className="w-full bg-surface-container-lowest border border-outline-variant rounded-lg px-3 py-2 text-on-surface focus:border-secondary focus:ring-1 focus:ring-secondary/30 outline-none text-xs font-mono cursor-pointer"
                disabled={!geoFilter.country}
              >
                <option value="">{geoFilter.country ? 'Seleccionar ciudad...' : 'Seleccione un país primero...'}</option>
                {geoFilter.country &&
                  citiesByCountry[geoFilter.country]?.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
              </select>
            </div>
          </div>

          <div className="mt-xl">
            <button
              onClick={triggerLoadMunicipality}
              className="w-full border-2 border-secondary/50 text-secondary font-bold text-xs py-3 rounded-lg hover:bg-secondary/15 active:scale-[0.98] transition-all select-none uppercase tracking-wider cursor-pointer shadow-md"
            >
              Cargar Capa de Municipio
            </button>
          </div>
        </section>
      </div>

      {/* Info Card at bottom */}
      <div className="bg-surface-container border border-outline-variant/50 rounded-xl p-5 max-w-6xl flex items-start gap-4">
        <div className="w-16 h-16 bg-surface-container-high rounded-lg flex items-center justify-center border border-outline-variant shrink-0 overflow-hidden select-none">
          <div
            className="w-full h-full bg-cover"
            style={{
              backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXuDkuZ3arai70dJHqowwsmWsLRjTwhBIc0hI7Uyvp3huD9gY3ihKA0CtxrXfJ8b9suJINtm-BYdDip9mOpypoROgvSGP9KZKISY1EQF_zc9n21iynNe3kTYhQNKH4uKVN2LpTpnPDReMr4c7ofttXQ7rSrJgypvHeZ-JDsl1FeqBbou_FzYEfv8wKoe3IwCv-W7EG0K1DQF8pB0rtjfLOyYfxtezWCje-p3-c5kM_3IEpnFJjtEp6lJdoMjWtAX3--3wbmXnoUr18MZM')`,
            }}
          />
        </div>
        <div>
          <h3 className="text-sm font-bold text-on-surface flex items-center gap-1.5">
            Visualización de Datos de Placas
            <HelpCircle className="w-3.5 h-3.5 text-on-surface-variant/60" />
          </h3>
          <p className="text-xs text-on-surface-variant leading-relaxed mt-1 max-w-2xl">
            Una vez establecida la conexión con PostgreSQL / PostGIS, podrá visualizar, filtrar y procesar las geometrías de las placas municipales georeferenciadas de manera vectorial. El sistema detecta y utiliza el sistema de referencia espacial <span className="text-[#00f5ff] font-mono">EPSG:4326</span> (WGS 84) de forma predeterminada para evitar desajustes de reproyección.
          </p>
        </div>
      </div>
    </div>
  );
}
