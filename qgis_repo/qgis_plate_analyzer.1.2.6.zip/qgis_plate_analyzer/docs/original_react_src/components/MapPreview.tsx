import React, { useRef, useEffect, useState } from 'react';
import { Layers, ZoomIn, ZoomOut, Maximize2, Compass, Move } from 'lucide-react';

interface MapPreviewProps {
  layerName?: string;
  pointsCount?: number;
  showHeatmap?: boolean;
  maskEnabled?: boolean;
}

interface GisPoint {
  x: number;
  y: number;
  id: string;
  intensity: number;
  type: string;
}

interface GisBoundary {
  points: { x: number; y: number }[];
  name: string;
}

export default function MapPreview({
  layerName = 'tbl_placas_georef',
  pointsCount = 120,
  showHeatmap = false,
  maskEnabled = true,
}: MapPreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState<number>(1.0);
  const [offset, setOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [hoveredPoint, setHoveredPoint] = useState<GisPoint | null>(null);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [scanLine, setScanLine] = useState<number>(0);
  const [mockPoints, setMockPoints] = useState<GisPoint[]>([]);
  const [mockBoundaries, setMockBoundaries] = useState<GisBoundary[]>([]);

  // Generate random stable mock points representing plates
  useEffect(() => {
    const points: GisPoint[] = [];
    const prefixes = ['MED', 'BOG', 'CAL', 'BAR', 'CAR', 'BUC'];
    const types = ['Residencial', 'Comercial', 'Oficial', 'Industrial'];
    
    // Fixed seed generator
    let seed = 42;
    const random = () => {
      const x = Math.sin(seed++) * 10000;
      return x - Math.floor(x);
    };

    for (let i = 0; i < pointsCount; i++) {
      const angle = random() * Math.PI * 2;
      const radius = random() * 150 + 20;
      // Clusters
      const clusterX = random() > 0.6 ? 100 : random() > 0.5 ? -120 : 0;
      const clusterY = random() > 0.6 ? -80 : random() > 0.5 ? 90 : 0;

      points.push({
        x: clusterX + Math.cos(angle) * radius,
        y: clusterY + Math.sin(angle) * radius,
        id: `PL-${prefixes[Math.floor(random() * prefixes.length)]}-${Math.floor(10000 + random() * 90000)}`,
        intensity: Math.floor(1 + random() * 9),
        type: types[Math.floor(random() * types.length)],
      });
    }
    setMockPoints(points);

    // Generate polygonal boundaries representing municipality zones
    const boundaries: GisBoundary[] = [];
    const zoneCount = 4;
    for (let z = 0; z < zoneCount; z++) {
      const center = {
        x: (random() - 0.5) * 200,
        y: (random() - 0.5) * 200,
      };
      const bPoints = [];
      const sides = 5 + Math.floor(random() * 4);
      for (let s = 0; s < sides; s++) {
        const theta = (s / sides) * Math.PI * 2;
        const r = 50 + random() * 40;
        bPoints.push({
          x: center.x + Math.cos(theta) * r,
          y: center.y + Math.sin(theta) * r,
        });
      }
      boundaries.push({
        points: bPoints,
        name: `Zona Administrativa ${String.fromCharCode(65 + z)}`,
      });
    }
    setMockBoundaries(boundaries);
  }, [pointsCount]);

  // Scanline animation effect
  useEffect(() => {
    let animationId: number;
    const animate = () => {
      setScanLine((prev) => (prev + 1.5) % 320);
      animationId = requestAnimationFrame(animate);
    };
    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, []);

  // Drawing logic
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear and match high-DPI scaling
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    const centerX = rect.width / 2 + offset.x;
    const centerY = rect.height / 2 + offset.y;

    // Dark slate background
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, rect.width, rect.height);

    // Draw coordinate grid lines
    if (showGrid) {
      ctx.strokeStyle = 'rgba(58, 73, 74, 0.15)';
      ctx.lineWidth = 1;
      
      const gridSpacing = 40 * zoom;
      const startX = (offset.x % gridSpacing) - gridSpacing;
      const startY = (offset.y % gridSpacing) - gridSpacing;

      for (let x = startX; x < rect.width; x += gridSpacing) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, rect.height);
        ctx.stroke();
      }

      for (let y = startY; y < rect.height; y += gridSpacing) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(rect.width, y);
        ctx.stroke();
      }
    }

    // Draw Municipal Mask boundaries if enabled
    if (maskEnabled) {
      ctx.save();
      ctx.strokeStyle = 'rgba(78, 222, 163, 0.4)';
      ctx.fillStyle = 'rgba(78, 222, 163, 0.03)';
      ctx.lineWidth = 1.5;
      
      mockBoundaries.forEach((boundary) => {
        if (boundary.points.length === 0) return;
        ctx.beginPath();
        const startX = centerX + boundary.points[0].x * zoom;
        const startY = centerY + boundary.points[0].y * zoom;
        ctx.moveTo(startX, startY);
        for (let i = 1; i < boundary.points.length; i++) {
          ctx.lineTo(centerX + boundary.points[i].x * zoom, centerY + boundary.points[i].y * zoom);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      });
      ctx.restore();
    }

    // Heatmap/Kernel Density representation
    if (showHeatmap) {
      mockPoints.forEach((pt) => {
        const px = centerX + pt.x * zoom;
        const py = centerY + pt.y * zoom;
        const radius = pt.intensity * 12 * zoom;

        const grad = ctx.createRadialGradient(px, py, 2 * zoom, px, py, radius);
        grad.addColorStop(0, 'rgba(0, 245, 255, 0.35)');
        grad.addColorStop(0.3, 'rgba(0, 245, 255, 0.12)');
        grad.addColorStop(1, 'rgba(0, 245, 255, 0)');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(px, py, radius, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // Vector connections / Voronoi triangulation effect
    ctx.strokeStyle = 'rgba(0, 245, 255, 0.06)';
    ctx.lineWidth = 1;
    for (let i = 0; i < mockPoints.length; i += 5) {
      if (i + 1 < mockPoints.length) {
        ctx.beginPath();
        ctx.moveTo(centerX + mockPoints[i].x * zoom, centerY + mockPoints[i].y * zoom);
        ctx.lineTo(centerX + mockPoints[i + 1].x * zoom, centerY + mockPoints[i + 1].y * zoom);
        ctx.stroke();
      }
    }

    // Draw Vector Points representing Municipal Plates
    mockPoints.forEach((pt) => {
      const px = centerX + pt.x * zoom;
      const py = centerY + pt.y * zoom;

      // Skip rendering if point falls far off-screen to improve performance
      if (px < -20 || px > rect.width + 20 || py < -20 || py > rect.height + 20) return;

      // Outer glow for points with higher intensity
      if (pt.intensity > 7) {
        ctx.fillStyle = 'rgba(0, 245, 255, 0.2)';
        ctx.beginPath();
        ctx.arc(px, py, 5 * zoom, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.fillStyle = pt.intensity > 7 ? '#00f5ff' : pt.intensity > 4 ? '#4edea3' : '#3a494a';
      ctx.beginPath();
      ctx.arc(px, py, (2.5 + pt.intensity * 0.15) * zoom, 0, Math.PI * 2);
      ctx.fill();

      // Highlight the hovered point
      if (hoveredPoint && hoveredPoint.id === pt.id) {
        ctx.strokeStyle = '#00f5ff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(px, py, 10 * zoom, 0, Math.PI * 2);
        ctx.stroke();
        
        // Dynamic crosshair
        ctx.strokeStyle = 'rgba(0, 245, 255, 0.4)';
        ctx.beginPath();
        ctx.moveTo(px - 15, py); ctx.lineTo(px + 15, py);
        ctx.moveTo(px, py - 15); ctx.lineTo(px, py + 15);
        ctx.stroke();
      }
    });

    // Scanner Sweep Effect
    ctx.strokeStyle = 'rgba(0, 245, 255, 0.15)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, scanLine);
    ctx.lineTo(rect.width, scanLine);
    ctx.stroke();

    // Corner decoration frames (GIS look)
    ctx.strokeStyle = 'rgba(132, 148, 149, 0.3)';
    ctx.lineWidth = 1.5;
    const padding = 12;
    const lineLen = 10;
    
    // Top-Left corner
    ctx.beginPath();
    ctx.moveTo(padding + lineLen, padding); ctx.lineTo(padding, padding); ctx.lineTo(padding, padding + lineLen);
    ctx.stroke();

    // Top-Right corner
    ctx.beginPath();
    ctx.moveTo(rect.width - padding - lineLen, padding); ctx.lineTo(rect.width - padding, padding); ctx.lineTo(rect.width - padding, padding + lineLen);
    ctx.stroke();

    // Bottom-Left corner
    ctx.beginPath();
    ctx.moveTo(padding + lineLen, rect.height - padding); ctx.lineTo(padding, rect.height - padding); ctx.lineTo(padding, rect.height - padding + lineLen);
    ctx.stroke();

    // Bottom-Right corner
    ctx.beginPath();
    ctx.moveTo(rect.width - padding - lineLen, rect.height - padding); ctx.lineTo(rect.width - padding, rect.height - padding); ctx.lineTo(rect.width - padding, rect.height - padding + lineLen);
    ctx.stroke();

    // Compass Overlay / North Arrow
    ctx.save();
    ctx.translate(rect.width - 35, 45);
    ctx.strokeStyle = '#b9caca';
    ctx.fillStyle = 'rgba(185, 202, 202, 0.2)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(0, 0, 16, 0, Math.PI * 2);
    ctx.stroke();
    
    // Draw pointer
    ctx.fillStyle = '#00f5ff';
    ctx.beginPath();
    ctx.moveTo(0, -12);
    ctx.lineTo(4, 0);
    ctx.lineTo(-4, 0);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#b9caca';
    ctx.beginPath();
    ctx.moveTo(0, 12);
    ctx.lineTo(4, 0);
    ctx.lineTo(-4, 0);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#b9caca';
    ctx.font = '8px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('N', 0, -18);
    ctx.restore();

  }, [offset, zoom, mockPoints, mockBoundaries, hoveredPoint, showGrid, scanLine, showHeatmap, maskEnabled]);

  // Handle zooming
  const handleZoomIn = () => setZoom((prev) => Math.min(prev * 1.2, 5.0));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev / 1.2, 0.3));
  const handleReset = () => {
    setZoom(1.0);
    setOffset({ x: 0, y: 0 });
  };

  // Mouse drag triggers
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();

    if (isDragging) {
      setOffset({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    } else {
      // Find point near cursor
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;
      const centerX = rect.width / 2 + offset.x;
      const centerY = rect.height / 2 + offset.y;

      const tolerance = 8;
      let matched: GisPoint | null = null;

      for (const pt of mockPoints) {
        const px = centerX + pt.x * zoom;
        const py = centerY + pt.y * zoom;
        const distance = Math.hypot(mouseX - px, mouseY - py);
        if (distance < tolerance) {
          matched = pt;
          break;
        }
      }
      setHoveredPoint(matched);
    }
  };

  const handleMouseUp = () => setIsDragging(false);

  return (
    <div ref={containerRef} className="relative w-full h-full border border-outline-variant/60 rounded-xl overflow-hidden bg-[#09090b] shadow-inner group">
      {/* Top Controls Overlay */}
      <div className="absolute top-3 left-3 z-10 flex gap-2">
        <div className="bg-surface-container/90 border border-outline-variant rounded-lg p-1 flex items-center gap-1 shadow-xl backdrop-blur-md">
          <button
            onClick={handleZoomIn}
            className="p-1.5 rounded-md hover:bg-surface-container-highest text-on-surface-variant hover:text-primary transition-all"
            title="Acercar (Zoom In)"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={handleZoomOut}
            className="p-1.5 rounded-md hover:bg-surface-container-highest text-on-surface-variant hover:text-primary transition-all"
            title="Alejar (Zoom Out)"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={handleReset}
            className="p-1.5 rounded-md hover:bg-surface-container-highest text-on-surface-variant hover:text-primary transition-all"
            title="Centrar"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={() => setShowGrid(!showGrid)}
          className={`px-2 py-1.5 rounded-lg border text-xs font-mono backdrop-blur-md flex items-center gap-1.5 transition-all shadow-xl ${
            showGrid
              ? 'bg-primary-container/10 border-primary-container/30 text-primary-container'
              : 'bg-surface-container/90 border-outline-variant text-on-surface-variant'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          GRID
        </button>
      </div>

      {/* Info label */}
      <div className="absolute bottom-3 left-3 z-10 bg-surface/90 border border-outline-variant/40 rounded-lg px-2.5 py-1.5 text-xs font-mono text-on-surface-variant/80 backdrop-blur-md pointer-events-none shadow-md">
        <span className="text-secondary font-bold">● Layer:</span> {layerName} | <span className="text-[#00f5ff]">Zoom:</span> {zoom.toFixed(1)}x
      </div>

      {/* Compass / indicator */}
      <div className="absolute top-3 right-3 z-10 text-on-surface-variant/40 select-none pointer-events-none">
        <Compass className="w-8 h-8 opacity-0 group-hover:opacity-10 pointer-events-none transition-opacity" />
      </div>

      {/* Main interactive Canvas */}
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="w-full h-full cursor-grab active:cursor-grabbing block"
      />

      {/* Dynamic Hover Tooltip inside canvas container */}
      {hoveredPoint && (
        <div
          className="absolute z-20 pointer-events-none bg-surface-container-high/95 border border-[#00f5ff]/40 rounded-xl p-3 shadow-2xl backdrop-blur-lg w-52 text-xs transition-all duration-150 animate-fade-in"
          style={{
            left: `${rectifyTooltipX(hoveredPoint.x, hoveredPoint.y)}px`,
            top: `${rectifyTooltipY(hoveredPoint.x, hoveredPoint.y)}px`,
          }}
        >
          <div className="flex items-center justify-between border-b border-outline-variant/55 pb-1 mb-1.5">
            <span className="font-mono text-primary-container font-bold">{hoveredPoint.id}</span>
            <span className="px-1.5 py-0.5 bg-surface-lowest text-[9px] font-bold rounded uppercase tracking-wider text-secondary">
              Placa GPS
            </span>
          </div>
          <div className="space-y-1 text-[11px] text-on-surface-variant">
            <div className="flex justify-between">
              <span>Tipo:</span>
              <span className="text-on-surface font-semibold">{hoveredPoint.type}</span>
            </div>
            <div className="flex justify-between">
              <span>Intensidad:</span>
              <span className="text-[#00f5ff] font-bold">{hoveredPoint.intensity} / 10</span>
            </div>
            <div className="flex justify-between">
              <span>Coords (X,Y):</span>
              <span className="font-mono text-on-surface">{(4.711 + hoveredPoint.x / 10000).toFixed(4)}, {(-74.072 + hoveredPoint.y / 10000).toFixed(4)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Navigation overlay helper when dragging */}
      {isDragging && (
        <div className="absolute inset-0 bg-transparent flex items-center justify-center pointer-events-none">
          <div className="bg-black/55 backdrop-blur-sm border border-outline-variant/40 rounded-full p-2 text-primary-container">
            <Move className="w-5 h-5 animate-pulse" />
          </div>
        </div>
      )}
    </div>
  );

  // Helper coordinate transforms to position tooltip cleanly inside the container relative to mock coordinate origin
  function rectifyTooltipX(x: number, y: number) {
    if (!canvasRef.current) return 0;
    const rect = canvasRef.current.getBoundingClientRect();
    const cx = rect.width / 2 + offset.x + x * zoom;
    return Math.max(10, Math.min(cx + 15, rect.width - 220));
  }

  function rectifyTooltipY(x: number, y: number) {
    if (!canvasRef.current) return 0;
    const rect = canvasRef.current.getBoundingClientRect();
    const cy = rect.height / 2 + offset.y + y * zoom;
    return Math.max(10, Math.min(cy - 120, rect.height - 120));
  }
}
