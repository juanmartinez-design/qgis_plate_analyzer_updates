import React, { useState } from 'react';
import { Monitor, RefreshCw, Layers, Sliders, Server, PlusSquare, Info, ShieldAlert } from 'lucide-react';
import { QgisLayer, PostgisTable, LogEntry } from '../types';
import MapPreview from './MapPreview';

interface LayersTabProps {
  isConnected: boolean;
  activeQgisLayer: string;
  setActiveQgisLayer: React.Dispatch<React.SetStateAction<string>>;
  maskEnabled: boolean;
  setMaskEnabled: React.Dispatch<React.SetStateAction<boolean>>;
  addLog: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  onAddPostgisLayer: (schema: string, tableName: string) => void;
}

export default function LayersTab({
  isConnected,
  activeQgisLayer,
  setActiveQgisLayer,
  maskEnabled,
  setMaskEnabled,
  addLog,
  onAddPostgisLayer,
}: LayersTabProps) {
  const [selectedPostgisSchema, setSelectedPostgisSchema] = useState<string>('public');
  const [selectedPostgisTable, setSelectedPostgisTable] = useState<string>('');
  const [refreshing, setRefreshing] = useState<boolean>(false);

  const qgisLayers = [
    { id: '1', name: 'manzanas_catastrales_v1', srid: 'EPSG:4326', type: 'Vectorial', geom: 'Polygon' },
    { id: '2', name: 'red_vial_urbana', srid: 'EPSG:4326', type: 'Vectorial', geom: 'LineString' },
    { id: '3', name: 'limites_administrativos', srid: 'EPSG:4326', type: 'Vectorial', geom: 'Polygon' },
    { id: '4', name: 'puntos_interes_comercial', srid: 'EPSG:4326', type: 'Vectorial', geom: 'Point' },
  ];

  const postgisTables = ['tbl_placas_georef', 'historico_analisis_2023', 'temp_buffer_results'];

  const triggerRefreshLayers = () => {
    setRefreshing(true);
    addLog('Escaneando árbol de capas del proyecto QGIS...', 'info');
    setTimeout(() => {
      setRefreshing(false);
      addLog('Lectura de capas del Canvas de QGIS completada. (4 capas detectadas)', 'success');
    }, 600);
  };

  const handleAddLayer = () => {
    if (!selectedPostgisTable) {
      addLog('Por favor, seleccione una tabla de PostGIS para importar.', 'error');
      return;
    }
    onAddPostgisLayer(selectedPostgisSchema, selectedPostgisTable);
  };

  const getActiveLayerGeom = () => {
    const matched = qgisLayers.find((l) => l.name === activeQgisLayer);
    return matched ? matched.geom : 'POLYGON';
  };

  return (
    <div className="space-y-lg animate-fade-in max-w-6xl">
      {/* Header Section */}
      <header className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="text-[#00F5FF] text-[11px] font-mono tracking-widest uppercase font-bold">
            Workspace Architecture
          </span>
          <div className="h-px flex-1 bg-gradient-to-r from-outline-variant/60 to-transparent"></div>
        </div>
        <h2 className="text-2xl font-bold text-primary">Gestión de Capas</h2>
      </header>

      {/* Bento Grid Layout */}
      <div className="grid grid-cols-12 gap-lg">
        
        {/* Section A: Capas Activas en QGIS */}
        <section className="col-span-12 lg:col-span-7 space-y-md">
          <div className="bg-surface/95 border border-outline-variant rounded-xl p-md space-y-md shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Monitor className="w-5 h-5 text-secondary" />
                <h3 className="text-md font-bold text-on-surface">Capas Activas en QGIS</h3>
              </div>
              <button
                onClick={triggerRefreshLayers}
                disabled={refreshing}
                className="flex items-center gap-1.5 px-3 py-1.5 text-secondary border border-secondary/30 rounded-lg hover:bg-secondary/10 transition-all text-xs font-semibold cursor-pointer select-none"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
                Actualizar
              </button>
            </div>

            <div className="space-y-sm">
              <div className="relative">
                <select
                  value={activeQgisLayer}
                  onChange={(e) => {
                    setActiveQgisLayer(e.target.value);
                    if (e.target.value) {
                      addLog(`Capa activa de trabajo cambiada a: ${e.target.value}`, 'info');
                    }
                  }}
                  className="w-full bg-surface-container-lowest border border-outline-variant text-on-surface rounded-lg px-4 py-3 appearance-none focus:ring-1 focus:ring-primary-container focus:border-primary-container outline-none font-mono text-xs cursor-pointer transition-all"
                >
                  <option value="">Seleccione una capa cargada...</option>
                  {qgisLayers.map((l) => (
                    <option key={l.id} value={l.name}>
                      {l.name}
                    </option>
                  ))}
                </select>
                <span className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-on-surface-variant text-xs">
                  expand_more
                </span>
              </div>

              {activeQgisLayer && (
                <div className="flex flex-wrap gap-1.5">
                  <span className="px-2 py-0.5 bg-surface-container-high border border-outline-variant text-[10px] uppercase font-mono font-bold text-on-surface-variant rounded">
                    EPSG:4326
                  </span>
                  <span className="px-2 py-0.5 bg-surface-container-high border border-outline-variant text-[10px] uppercase font-mono font-bold text-on-surface-variant rounded">
                    Vectorial
                  </span>
                  <span className="px-2 py-0.5 bg-surface-container-high border border-outline-variant text-[10px] uppercase font-mono font-bold text-[#4edea3] rounded">
                    {getActiveLayerGeom()}
                  </span>
                </div>
              )}
            </div>

            {/* Interactive map embedded */}
            <div className="h-44 w-full">
              <MapPreview
                layerName={activeQgisLayer || 'Vista de Selección'}
                pointsCount={activeQgisLayer === 'manzanas_catastrales_v1' ? 140 : activeQgisLayer === 'red_vial_urbana' ? 60 : 100}
                showHeatmap={false}
                maskEnabled={maskEnabled}
              />
            </div>
          </div>
        </section>

        {/* Section B: Opciones de Máscara */}
        <section className="col-span-12 lg:col-span-5">
          <div className="bg-surface/95 border border-outline-variant rounded-xl p-md space-y-md border-primary-container/20 h-full flex flex-col justify-between shadow-lg">
            <div className="space-y-md">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-primary-container" />
                <h3 className="text-md font-bold text-on-surface">Opciones de Máscara</h3>
              </div>
              <p className="text-xs text-on-surface-variant leading-relaxed">
                Configuración avanzada de recortes espaciales para limitar el procesamiento de densidad de placas vectoriales a polígonos de contención.
              </p>
            </div>

            <div className="mt-4">
              <label className="flex items-center justify-between p-4 bg-surface-container-low rounded-lg border border-outline-variant/30 cursor-pointer hover:bg-surface-container-high transition-colors group">
                <div className="flex flex-col pr-4">
                  <span className="text-xs font-semibold text-on-surface">Municipio como máscara</span>
                  <span className="text-[11px] text-on-surface-variant mt-0.5 leading-snug">
                    Recortar resultados de análisis a límites municipales cargados
                  </span>
                </div>
                <div className="relative inline-flex items-center shrink-0">
                  <input
                    type="checkbox"
                    checked={maskEnabled}
                    onChange={(e) => {
                      setMaskEnabled(e.target.checked);
                      addLog(`Máscara de contención municipal ${e.target.checked ? 'ACTIVADA' : 'DESACTIVADA'}`, 'info');
                    }}
                    className="sr-only peer"
                    id="municipio-mascara-toggle"
                  />
                  <div className="w-10 h-5 bg-surface-container-highest peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary-container" />
                </div>
              </label>
            </div>
          </div>
        </section>

        {/* Section C: Capas desde PostGIS */}
        <section className="col-span-12 space-y-md">
          <div className="bg-surface/95 border border-outline-variant rounded-xl p-5 border-t-2 border-t-primary-container/50 shadow-lg relative">
            
            {/* Warning Lock Overlay if disconnected */}
            {!isConnected && (
              <div className="absolute inset-0 bg-[#09090b]/85 backdrop-blur-[1px] rounded-xl flex flex-col items-center justify-center z-10 p-6 text-center">
                <ShieldAlert className="w-10 h-10 text-error mb-2 animate-pulse" />
                <h4 className="text-md font-bold text-primary">PostGIS no Conectado</h4>
                <p className="text-xs text-on-surface-variant max-w-md mt-1 leading-relaxed">
                  Para importar tablas vectoriales espaciales directamente desde su base de datos, debe ir a la pestaña <span className="text-secondary font-semibold">1 · Conexión</span> y pulsar el botón conectar.
                </p>
              </div>
            )}

            <div className="flex items-center gap-2 mb-4">
              <Server className="w-5 h-5 text-primary-container" />
              <div className="flex flex-col">
                <h3 className="text-sm font-bold text-on-surface">Capas desde PostGIS</h3>
                <p className="text-[11px] text-on-surface-variant">Importación directa de geometrías desde la base de datos vinculada</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-md items-end">
              {/* Esquema */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Esquema</label>
                <select
                  value={selectedPostgisSchema}
                  onChange={(e) => setSelectedPostgisSchema(e.target.value)}
                  className="w-full bg-[#09090B] border border-outline-variant text-on-surface rounded-lg px-3 py-2 outline-none font-mono text-xs focus:border-primary-container transition-all cursor-pointer"
                >
                  <option value="public">public</option>
                  <option value="analisis_espacial">analisis_espacial</option>
                  <option value="catastro_nacional">catastro_nacional</option>
                  <option value="infraestructura">infraestructura</option>
                </select>
              </div>

              {/* Tabla */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Tabla Espacial</label>
                <select
                  value={selectedPostgisTable}
                  onChange={(e) => setSelectedPostgisTable(e.target.value)}
                  className="w-full bg-[#09090B] border border-outline-variant text-on-surface rounded-lg px-3 py-2 outline-none font-mono text-xs focus:border-primary-container transition-all cursor-pointer"
                >
                  <option value="">Seleccione una tabla...</option>
                  {postgisTables.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              {/* Button */}
              <div>
                <button
                  onClick={handleAddLayer}
                  className="w-full h-9 bg-secondary-container text-on-secondary-container font-extrabold text-xs rounded-lg flex items-center justify-center gap-1.5 hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer select-none uppercase tracking-wider"
                >
                  <PlusSquare className="w-4 h-4" />
                  Agregar al Proyecto
                </button>
              </div>
            </div>

            {/* Info box */}
            <div className="mt-md p-3 bg-surface-container-low/50 rounded-lg border-l-4 border-l-secondary flex items-start gap-3">
              <Info className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
              <p className="text-xs text-on-surface-variant leading-relaxed">
                Solo se listan y procesan las tablas que contienen una columna de geometría espacial registrada en el catálogo <span className="font-mono text-on-surface">geometry_columns</span> de PostGIS. El sistema detectará automáticamente el SRID de origen y reproyectará al vuelo si es necesario.
              </p>
            </div>
          </div>
        </section>

        {/* Section D: High-tech landscape representation */}
        <section className="col-span-12">
          <div className="relative h-44 rounded-xl overflow-hidden border border-outline-variant bg-surface-container-lowest shadow-lg">
            <div className="absolute inset-0 z-0 opacity-40">
              <div
                className="w-full h-full bg-cover bg-center"
                style={{
                  backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXuA40F36Q_AZcYIID_agriiPbHCKJ-gtm2cCOAr9XmVgV1PgLjia_xfQlpsA3TtGh688JOg9y784zMD4Agw_MNWv5daI3f4Ju0FA9lb0JhcZNKlc_hn1X2iEM3GmBRrT8OKgsd0GvOpMqilmZTIxowbTPt4DyNR0qCV4QPoCDvjXMz_on26TRxawpVYpqqVHP4bL5yPIF-S8mGgZZbsFhCdkGg1IWi6PlanEHOojRsla_iQWI-Zeu_esb77OIleZZGUFXvCOR0jDf--H')`,
                }}
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent z-10" />
            <div className="absolute bottom-4 left-4 z-20">
              <div className="flex items-center gap-1.5 mb-1">
                <div className="w-2.5 h-2.5 rounded-full bg-secondary status-pulse shadow-[0_0_8px_rgba(78,222,163,0.6)]" />
                <span className="text-[10px] font-mono text-secondary uppercase font-bold tracking-wider">
                  Live Spatial Engine Active
                </span>
              </div>
              <h4 className="text-sm font-bold text-white uppercase tracking-wide">
                Previsualización Dinámica del Proyecto Vectorial
              </h4>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
