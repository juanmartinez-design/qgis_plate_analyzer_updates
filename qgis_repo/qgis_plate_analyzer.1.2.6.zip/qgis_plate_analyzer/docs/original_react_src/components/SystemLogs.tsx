import React, { useEffect, useRef } from 'react';
import { Terminal, Trash2, Copy, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { LogEntry } from '../types';

interface SystemLogsProps {
  logs: LogEntry[];
  onClear: () => void;
}

export default function SystemLogs({ logs, onClear }: SystemLogsProps) {
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);

  const copyToClipboard = () => {
    const text = logs.map((log) => `${log.timestamp} ${log.message}`).join('\n');
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="bg-surface-container-lowest border border-outline-variant rounded-xl overflow-hidden shadow-2xl flex flex-col h-full">
      {/* Header */}
      <div className="bg-black/40 px-md py-2.5 border-b border-outline-variant flex items-center justify-between select-none shrink-0">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-on-surface-variant animate-pulse" />
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-on-surface-variant">
            Logs de Sistema / Consola de Salida
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={copyToClipboard}
            className="p-1 rounded hover:bg-surface-container-high text-on-surface-variant hover:text-primary transition-all"
            title="Copiar Logs al Portapapeles"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClear}
            className="p-1 rounded hover:bg-surface-container-high text-on-surface-variant hover:text-error transition-all"
            title="Limpiar Consola"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Terminal View */}
      <div className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-1.5 bg-black/75 scrollbar-thin">
        {logs.length === 0 ? (
          <div className="text-on-surface-variant/40 italic flex items-center justify-center h-full select-none">
            La consola de salida está vacía. Inicie una acción para ver los registros del geoprocesamiento.
          </div>
        ) : (
          logs.map((log, index) => {
            // Pick color based on level
            let textClass = 'text-on-surface-variant/80';
            let icon = null;

            if (log.type === 'success') {
              textClass = 'text-[#4edea3]';
              icon = <CheckCircle className="w-3 h-3 shrink-0 text-[#4edea3]/70" />;
            } else if (log.type === 'error') {
              textClass = 'text-[#ffb4ab] font-semibold';
              icon = <AlertTriangle className="w-3 h-3 shrink-0 text-[#ffb4ab]/70 animate-bounce" />;
            } else if (log.type === 'warning') {
              textClass = 'text-amber-400';
              icon = <AlertTriangle className="w-3 h-3 shrink-0 text-amber-400/70" />;
            } else if (log.type === 'info') {
              textClass = 'text-[#00f5ff]/90';
              icon = <Info className="w-3 h-3 shrink-0 text-[#00f5ff]/70" />;
            }

            return (
              <div key={index} className={`flex items-start gap-2.5 py-0.5 border-b border-white/[0.02] hover:bg-white/[0.01] transition-colors leading-relaxed ${textClass}`}>
                <span className="text-on-surface-variant/40 shrink-0 font-mono text-[11px]">
                  {log.timestamp}
                </span>
                {icon}
                <span className="whitespace-pre-wrap select-text font-mono flex-1">
                  {log.message}
                </span>
              </div>
            );
          })
        )}
        <div ref={terminalEndRef} />
      </div>
    </div>
  );
}
