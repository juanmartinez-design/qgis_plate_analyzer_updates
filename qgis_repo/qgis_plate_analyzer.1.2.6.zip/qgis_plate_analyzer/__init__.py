# -*- coding: utf-8 -*-
"""Entry point required by QGIS for the QGIS Plate Analyzer plugin."""


def classFactory(iface):  # pylint: disable=invalid-name
    """QGIS calls this function to instantiate the plugin."""
    from .qgis_plate_analyzer import QgisPlateAnalyzer
    return QgisPlateAnalyzer(iface)
