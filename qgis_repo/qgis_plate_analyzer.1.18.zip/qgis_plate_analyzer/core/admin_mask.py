﻿"""
admin_mask.py
=============

Construye la máscara espacial de análisis usando capas del schema Administrativo.

La máscara final se define como:

    search_mask = municipio seleccionado ∩ huella_urbana

Donde:
    - municipio seleccionado viene de Administrativo.municipio
    - huella_urbana viene de Administrativo.huella_urbana

Este módulo NO genera grilla.
Este módulo NO hace análisis de densidad.
Solo devuelve el polígono final donde se debe generar la grilla.
"""

import json
from pathlib import Path

import geopandas as gpd
from psycopg2 import sql


BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parents[1]

DEFAULT_MAPPING_PATH = BASE_DIR / "json" / "column_mapping - DEF.json"


# ==========================================================================================================================================================================================================================================
# UTILIDADES
# ==========================================================================================================================================================================================================================================

def resolve_path(path):
    """
    Resuelve rutas relativas buscando en varias ubicaciones comunes.
    """

    path = Path(path)

    if path.is_absolute():
        return path

    candidate_paths = [
        Path.cwd() / path,
        BASE_DIR / path,
        BASE_DIR / "json" / path.name,
        PROJECT_ROOT / path,
        PROJECT_ROOT / "json" / path.name,
    ]

    for candidate in candidate_paths:
        if candidate.exists():
            return candidate

    checked = "\n".join(str(p) for p in candidate_paths)

    raise FileNotFoundError(
        f"No se encontró el archivo: {path}\n\n"
        f"Rutas revisadas:\n{checked}"
    )


def load_column_mapping(mapping_path=DEFAULT_MAPPING_PATH):
    """
    Carga column_mapping - DEF.json.
    """

    mapping_path = resolve_path(mapping_path)

    with open(mapping_path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_db_mapping(dbname, mapping_path=DEFAULT_MAPPING_PATH):
    """
    Obtiene el bloque de configuración de una dbname.
    """

    mapping = load_column_mapping(mapping_path)

    if dbname not in mapping:
        raise KeyError(
            f"No existe configuración para la base '{dbname}' "
            f"en column_mapping - DEF.json."
        )

    return mapping[dbname]


def resolve_admin_config(db_cfg):
    """
    Resuelve la configuración del schema Administrativo.

    Espera una estructura como:

    "administrativo": {
      "schema": "Administrativo",
      "municipio": {
        "table": "municipio",
        "department_column": "nom_dep",
        "city_column": "nom_mun",
        "geom_column": "geom"
      },
      "huella_urbana": {
        "table": "huella_urbana",
        "geom_column": "geom"
      },
      "construcciones": {
        "table": "construcciones",
        "geom_column": "geom"
      }
    }
    """

    if "administrativo" not in db_cfg:
        raise KeyError("Falta el bloque 'administrativo' en column_mapping - DEF.json.")

    admin = db_cfg["administrativo"]

    admin_schema = admin.get("schema", "administrativo")

    municipios = admin.get("municipio") or admin.get("municipios")

    if municipios is None:
        raise KeyError(
            "Falta el bloque administrativo.municipio en column_mapping - DEF.json."
        )

    huella = admin.get("huella_urbana")

    if huella is None:
        raise KeyError(
            "Falta el bloque administrativo.huella_urbana en column_mapping - DEF.json."
        )

    return {
        "schema": admin_schema,

        "municipios_table": municipios.get("table", "municipio"),
        "municipios_geom": municipios.get("geom_column", "geom"),
        "department_column": municipios.get("department_column", "nom_dep"),
        "city_column": municipios.get("city_column", "nom_mun"),

        "huella_schema": huella.get("schema", "zona_cruda"),
        "huella_table": huella.get("table", "huella_urbana"),
        "huella_geom": huella.get("geom_column", "geom"),
    }


# ==========================================================================================================================================================================================================================================
# CONSULTA DE MÁSCARA
# ==========================================================================================================================================================================================================================================

def build_search_mask_query(admin_cfg, target_srid=4326):
    """
    Construye SQL para obtener:

        municipio seleccionado ∩ huella_urbana

    El filtro administrativo usa:
        department_column = nivel_1
        city_column       = nivel_2
    """

    accents_from = "ÁÀÄÂÃÉÈËÊÍÌÏÎÓÒÖÔÕÚÙÜÛÑÇáàäâãéèëêíìïîóòöôõúùüûñç"
    accents_to = "AAAAAEEEEIIIIOOOOOUUUUNCaaaaaeeeeiiiiooooouuuunc"

    query = sql.SQL("""
        WITH municipio AS (
            SELECT
                ST_Union(
                    ST_MakeValid(
                        CASE
                            WHEN ST_SRID(m.{municipios_geom}) = %s
                                THEN m.{municipios_geom}
                            WHEN ST_SRID(m.{municipios_geom}) = 0
                                THEN ST_SetSRID(m.{municipios_geom}, %s)
                            ELSE ST_Transform(m.{municipios_geom}, %s)
                        END
                    )
                ) AS geom
            FROM {admin_schema}.{municipios_table} m
            WHERE TRANSLATE(UPPER(TRIM(m.{department_column}::text)), %s, %s)
                  = TRANSLATE(UPPER(TRIM(%s)), %s, %s)
              AND TRANSLATE(UPPER(TRIM(m.{city_column}::text)), %s, %s)
                  = TRANSLATE(UPPER(TRIM(%s)), %s, %s)
        ),

        huella AS (
            SELECT
                ST_MakeValid(
                    CASE
                        WHEN ST_SRID(h.{huella_geom}) = %s
                            THEN h.{huella_geom}
                        WHEN ST_SRID(h.{huella_geom}) = 0
                            THEN ST_SetSRID(h.{huella_geom}, %s)
                        ELSE ST_Transform(h.{huella_geom}, %s)
                    END
                ) AS geom
            FROM {huella_schema}.{huella_table} h
            JOIN municipio m
              ON ST_Intersects(
                    ST_MakeValid(
                        CASE
                            WHEN ST_SRID(h.{huella_geom}) = %s
                                THEN h.{huella_geom}
                            WHEN ST_SRID(h.{huella_geom}) = 0
                                THEN ST_SetSRID(h.{huella_geom}, %s)
                            ELSE ST_Transform(h.{huella_geom}, %s)
                        END
                    ),
                    m.geom
                 )
            WHERE h.{huella_geom} IS NOT NULL
        ),

        interseccion AS (
            SELECT
                ST_CollectionExtract(
                    ST_MakeValid(
                        ST_Intersection(h.geom, m.geom)
                    ),
                    3
                ) AS geom
            FROM huella h
            CROSS JOIN municipio m
            WHERE m.geom IS NOT NULL
              AND ST_Intersects(h.geom, m.geom)
        ),

        final AS (
            SELECT
                ST_Multi(
                    ST_Union(geom)
                ) AS geom
            FROM interseccion
            WHERE geom IS NOT NULL
              AND NOT ST_IsEmpty(geom)
        )

        SELECT
            1 AS id,
            ST_AsEWKB(geom) AS geom_wkb
        FROM final
        WHERE geom IS NOT NULL
          AND NOT ST_IsEmpty(geom);
    """).format(
        admin_schema=sql.Identifier(admin_cfg["schema"]),

        municipios_table=sql.Identifier(admin_cfg["municipios_table"]),
        municipios_geom=sql.Identifier(admin_cfg["municipios_geom"]),
        department_column=sql.Identifier(admin_cfg["department_column"]),
        city_column=sql.Identifier(admin_cfg["city_column"]),

        huella_table=sql.Identifier(admin_cfg["huella_table"]),
        huella_geom=sql.Identifier(admin_cfg["huella_geom"]),
    )

    return query, accents_from, accents_to
#==========================================================================================================================================================================================
#==========================================================================================================================================================================================

def build_search_mask_diagnostics_query(admin_cfg, target_srid=4326):
    accents_from = "ÁÀÄÂÃÉÈËÊÍÌÏÎÓÒÖÔÕÚÙÜÛÑÇáàäâãéèëêíìïîóòöôõúùüûñç"
    accents_to = "AAAAAEEEEIIIIOOOOOUUUUNCaaaaaeeeeiiiiooooouuuunc"

    query = sql.SQL("""
        WITH municipio AS (
            SELECT
                ST_MakeValid(
                    CASE
                        WHEN ST_SRID(m.{municipios_geom}) = %s
                            THEN m.{municipios_geom}
                        WHEN ST_SRID(m.{municipios_geom}) = 0
                            THEN ST_SetSRID(m.{municipios_geom}, %s)
                        ELSE ST_Transform(m.{municipios_geom}, %s)
                    END
                ) AS geom
            FROM {admin_schema}.{municipios_table} m
            WHERE TRANSLATE(UPPER(TRIM(m.{department_column}::text)), %s, %s)
                  = TRANSLATE(UPPER(TRIM(%s)), %s, %s)
              AND TRANSLATE(UPPER(TRIM(m.{city_column}::text)), %s, %s)
                  = TRANSLATE(UPPER(TRIM(%s)), %s, %s)
              AND m.{municipios_geom} IS NOT NULL
        ),
        huella AS (
            SELECT
                ST_MakeValid(
                    CASE
                        WHEN ST_SRID(h.{huella_geom}) = %s
                            THEN h.{huella_geom}
                        WHEN ST_SRID(h.{huella_geom}) = 0
                            THEN ST_SetSRID(h.{huella_geom}, %s)
                        ELSE ST_Transform(h.{huella_geom}, %s)
                    END
                ) AS geom
            FROM {huella_schema}.{huella_table} h
            WHERE h.{huella_geom} IS NOT NULL
        )
        SELECT
            (SELECT COUNT(*) FROM municipio) AS municipios_encontrados,
            (SELECT COUNT(*) FROM huella) AS huellas_disponibles,
            (
                SELECT COUNT(*)
                FROM municipio m
                JOIN huella h ON ST_Intersects(h.geom, m.geom)
            ) AS intersecciones;
    """).format(
        admin_schema=sql.Identifier(admin_cfg["schema"]),
        huella_schema=sql.Identifier(admin_cfg["huella_schema"]),
        municipios_table=sql.Identifier(admin_cfg["municipios_table"]),
        municipios_geom=sql.Identifier(admin_cfg["municipios_geom"]),
        department_column=sql.Identifier(admin_cfg["department_column"]),
        city_column=sql.Identifier(admin_cfg["city_column"]),
        huella_table=sql.Identifier(admin_cfg["huella_table"]),
        huella_geom=sql.Identifier(admin_cfg["huella_geom"]),
    )

    return query, accents_from, accents_to


def fetch_search_mask_diagnostics(conn, admin_cfg, nivel_1, nivel_2, target_srid=4326):
    query, accents_from, accents_to = build_search_mask_diagnostics_query(
        admin_cfg=admin_cfg,
        target_srid=target_srid,
    )
    params = (
        target_srid,
        target_srid,
        target_srid,
        accents_from,
        accents_to,
        nivel_1,
        accents_from,
        accents_to,
        accents_from,
        accents_to,
        nivel_2,
        accents_from,
        accents_to,
        target_srid,
        target_srid,
        target_srid,
    )
    with conn.cursor() as cur:
        cur.execute(query, params)
        row = cur.fetchone()
    if not row:
        return {}
    return {
        "municipios_encontrados": row[0],
        "huellas_disponibles": row[1],
        "intersecciones": row[2],
    }


def format_search_mask_diagnostics(diagnostics):
    if not diagnostics:
        return "Diagnostico: no fue posible calcular conteos de apoyo."
    return (
        "Diagnostico:\n"
        f"- Municipios encontrados con nivel 1/nivel 2: {diagnostics.get('municipios_encontrados', 0)}\n"
        f"- Geometrias en huella_urbana: {diagnostics.get('huellas_disponibles', 0)}\n"
        f"- Intersecciones municipio/huella_urbana: {diagnostics.get('intersecciones', 0)}"
    )


def normalize_wkb(value):
    """
    Normaliza el WKB recibido desde PostGIS para que Shapely/GeoPandas
    lo pueda leer correctamente.

    PostGIS puede devolver bytea como:
        - memoryview
        - bytes
        - bytearray
        - string hexadecimal con prefijo \\x
    """

    if value is None:
        return None

    if isinstance(value, memoryview):
        value = value.tobytes()

    elif isinstance(value, bytearray):
        value = bytes(value)

    elif isinstance(value, bytes):
        pass

    elif isinstance(value, str):
        value = value.strip()

        if value.startswith("\\x"):
            value = value[2:]

        if value.startswith("0x"):
            value = value[2:]

        value = bytes.fromhex(value)

    else:
        try:
            value = bytes(value)
        except Exception as exc:
            raise TypeError(
                f"No se pudo convertir el valor WKB. "
                f"Tipo recibido: {type(value)}"
            ) from exc

    if len(value) < 5:
        raise ValueError(
            f"WKB demasiado corto o corrupto. Longitud recibida: {len(value)}"
        )

    return value

#==================================================================================================================================================================================================================================================
#==================================================================================================================================================================================================================================================
def fetch_search_mask(
    conn,
    dbname,
    nivel_1,
    nivel_2,
    mapping_path=DEFAULT_MAPPING_PATH,
    target_srid=4326
):
    """
    Obtiene la máscara final de análisis desde PostGIS.

    Parámetros
    ----------
    conn:
        Conexión psycopg2 a la base del país.

    dbname:
        Nombre de la base, por ejemplo:
            Latam_ElSalvador

    nivel_1:
        Departamento / nom_dep.

    nivel_2:
        Municipio / nom_mun.

    mapping_path:
        Ruta al column_mapping - DEF.json.

    target_srid:
        SRID final de trabajo. Por defecto 4326.

    Retorna
    -------
    GeoDataFrame con la máscara:

        municipio ∩ huella_urbana
    """

    db_cfg = get_db_mapping(
        dbname=dbname,
        mapping_path=mapping_path
    )

    admin_cfg = resolve_admin_config(db_cfg)

    query, accents_from, accents_to = build_search_mask_query(
        admin_cfg=admin_cfg,
        target_srid=target_srid
    )

    params = (
        target_srid,
        target_srid,
        target_srid,
        accents_from,
        accents_to,
        nivel_1,
        accents_from,
        accents_to,
        accents_from,
        accents_to,
        nivel_2,
        accents_from,
        accents_to,
        target_srid,
        target_srid,
        target_srid,
        target_srid,
        target_srid,
        target_srid,
    )

    with conn.cursor() as cur:
        cur.execute(query, params)
        rows = cur.fetchall()

    if not rows:
        diagnostics = fetch_search_mask_diagnostics(
            conn=conn,
            admin_cfg=admin_cfg,
            nivel_1=nivel_1,
            nivel_2=nivel_2,
            target_srid=target_srid,
        )
        raise RuntimeError(
            "No se generó search_mask.\n"
            f"Nivel 1: {nivel_1}\n"
            f"Nivel 2: {nivel_2}\n\n"
            f"{format_search_mask_diagnostics(diagnostics)}\n\n"
            "Posibles causas:\n"
            "- No existe el municipio con ese nom_dep / nom_mun.\n"
            "- La huella_urbana no intersecta ese municipio.\n"
            "- El nombre de schema, tabla o columnas está mal en column_mapping - DEF.json."
        )

    records = []
    wkb_values = []

    for row in rows:
        geom_wkb = normalize_wkb(row[1])

        if geom_wkb is None:
            continue

        records.append({
            "id": row[0]
        })

        wkb_values.append(geom_wkb)

    if not records:
        raise RuntimeError(
            "La consulta devolvió filas, pero ninguna geometría WKB válida."
        )

    geometries = gpd.GeoSeries.from_wkb(
        wkb_values,
        crs=f"EPSG:{target_srid}"
    )

    gdf = gpd.GeoDataFrame(
        records,
        geometry=geometries,
        crs=f"EPSG:{target_srid}"
    )

    if gdf.empty:
        raise RuntimeError("La search_mask resultante está vacía.")

    return gdf
