﻿# -*- coding: utf-8 -*-
"""Main dialog for QGIS Plate Analyzer.

This version does NOT require QtWebEngine.  The original ZIP contained a
React/Vite interface, but several QGIS installations do not bundle
QtWebEngine, so rendering HTML inside QGIS fails.  This dialog recreates the
same application shell natively with PyQt widgets: dark sidebar, header, cards,
map preview, system console and status bar.
"""

import math
import html
import json
import os
import random
import re
import shutil
import tempfile
import time
import traceback
from datetime import datetime
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from qgis.PyQt.QtCore import QPointF, QRectF, Qt, QTimer, QUrl
from qgis.PyQt.QtGui import QColor, QDesktopServices, QFont, QLinearGradient, QPainter, QPen, QRadialGradient
from qgis.PyQt.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QProgressBar,
    QScrollArea,
    QSizePolicy,
    QSpacerItem,
    QStackedWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)
from qgis.core import QgsApplication, QgsProject, QgsVectorLayer

from ..core.db_manager import DBConfig, DBManager
from ..core.density_analysis import DensityAnalysis


DEFAULT_UPDATE_DIR = Path(r"C:\Users\jamartinez\Documents\Herramienta analisis de placas")
DEFAULT_UPDATE_VERSION_FILE = DEFAULT_UPDATE_DIR / "version.json"
DEFAULT_UPDATE_ZIP_FILE = DEFAULT_UPDATE_DIR / "qgis_plate_analyzer_importar_qgis.zip"
DEFAULT_GITHUB_TOKEN_ENV = "QGIS_PLATE_ANALYZER_GITHUB_TOKEN"
DEFAULT_GITHUB_TOKEN_FILE = "~/.qgis_plate_analyzer/github_token.txt"
ANALYSIS_BANDWIDTH_M = 30.0
ANALYSIS_SEARCH_RADIUS_M = 30.0
ANALYSIS_KERNEL_TYPE = "epanechnikov"
ANALYSIS_METHOD = "kde"
ANALYSIS_WEIGHT_FIELD = ""


class MapPreviewWidget(QWidget):
    """Small native canvas inspired by the original React canvas map preview."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(280)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.layer_name = "tbl_placas_georef"
        self.points_count = 120
        self.show_heatmap = False
        self.mask_enabled = True
        self.zoom = 1.0
        self.offset_x = 0.0
        self.offset_y = 0.0
        self.scan_line = 0.0
        self.points = self._generate_points(self.points_count)
        self.boundaries = self._generate_boundaries()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(80)

    def _tick(self):
        self.scan_line = (self.scan_line + 3.0) % max(self.height(), 1)
        self.update()

    def set_layer_name(self, name: str):
        self.layer_name = name or "tbl_placas_georef"
        self.update()

    def set_heatmap(self, enabled: bool):
        self.show_heatmap = bool(enabled)
        self.update()

    def set_mask_enabled(self, enabled: bool):
        self.mask_enabled = bool(enabled)
        self.update()

    def _generate_points(self, count: int) -> List[Tuple[float, float, float]]:
        rnd = random.Random(42)
        pts = []
        for _ in range(count):
            angle = rnd.random() * math.pi * 2
            radius = rnd.random() * 155 + 25
            cluster_x = 100 if rnd.random() > 0.63 else (-120 if rnd.random() > 0.5 else 0)
            cluster_y = -80 if rnd.random() > 0.65 else (90 if rnd.random() > 0.5 else 0)
            x = cluster_x + math.cos(angle) * radius
            y = cluster_y + math.sin(angle) * radius
            intensity = 1 + rnd.random() * 8
            pts.append((x, y, intensity))
        return pts

    def _generate_boundaries(self):
        rnd = random.Random(7)
        boundaries = []
        for _ in range(4):
            cx = (rnd.random() - 0.5) * 210
            cy = (rnd.random() - 0.5) * 210
            sides = 5 + int(rnd.random() * 4)
            poly = []
            for s in range(sides):
                theta = (s / sides) * math.pi * 2
                r = 55 + rnd.random() * 44
                poly.append((cx + math.cos(theta) * r, cy + math.sin(theta) * r))
            boundaries.append(poly)
        return boundaries

    def wheelEvent(self, event):  # pragma: no cover - UI event
        delta = event.angleDelta().y()
        self.zoom = max(0.55, min(2.5, self.zoom + (0.1 if delta > 0 else -0.1)))
        self.update()

    def paintEvent(self, event):  # pragma: no cover - visual painting inside QGIS
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        painter.fillRect(self.rect(), QColor("#09090b"))

        cx = w / 2 + self.offset_x
        cy = h / 2 + self.offset_y

        # Grid
        painter.setPen(QPen(QColor(58, 73, 74, 46), 1))
        spacing = max(25, int(40 * self.zoom))
        x = int(self.offset_x) % spacing
        while x < w:
            painter.drawLine(x, 0, x, h)
            x += spacing
        y = int(self.offset_y) % spacing
        while y < h:
            painter.drawLine(0, y, w, y)
            y += spacing

        # Municipal boundaries / mask
        if self.mask_enabled:
            painter.setPen(QPen(QColor(78, 222, 163, 115), 1.5))
            painter.setBrush(QColor(78, 222, 163, 10))
            for poly in self.boundaries:
                pts = [QPointF(cx + px * self.zoom, cy + py * self.zoom) for px, py in poly]
                painter.drawPolygon(pts)

        # Heatmap rings
        if self.show_heatmap:
            for px, py, intensity in self.points:
                sx = cx + px * self.zoom
                sy = cy + py * self.zoom
                rad = intensity * 13 * self.zoom
                grad = QRadialGradient(QPointF(sx, sy), rad)
                grad.setColorAt(0.0, QColor(0, 245, 255, 95))
                grad.setColorAt(0.35, QColor(0, 245, 255, 34))
                grad.setColorAt(1.0, QColor(0, 245, 255, 0))
                painter.setBrush(grad)
                painter.setPen(Qt.NoPen)
                painter.drawEllipse(QPointF(sx, sy), rad, rad)

        # Vector connection effect
        painter.setPen(QPen(QColor(0, 245, 255, 18), 1))
        for i in range(0, len(self.points) - 1, 5):
            x1, y1, _ = self.points[i]
            x2, y2, _ = self.points[i + 1]
            painter.drawLine(QPointF(cx + x1 * self.zoom, cy + y1 * self.zoom), QPointF(cx + x2 * self.zoom, cy + y2 * self.zoom))

        # Points
        painter.setPen(Qt.NoPen)
        for px, py, intensity in self.points:
            sx = cx + px * self.zoom
            sy = cy + py * self.zoom
            if sx < -30 or sx > w + 30 or sy < -30 or sy > h + 30:
                continue
            if intensity > 7:
                painter.setBrush(QColor(0, 245, 255, 55))
                painter.drawEllipse(QPointF(sx, sy), 6 * self.zoom, 6 * self.zoom)
                painter.setBrush(QColor("#00f5ff"))
            elif intensity > 4:
                painter.setBrush(QColor("#4edea3"))
            else:
                painter.setBrush(QColor("#3a494a"))
            r = (2.4 + intensity * 0.16) * self.zoom
            painter.drawEllipse(QPointF(sx, sy), r, r)

        # Scanner line
        painter.setPen(QPen(QColor(0, 245, 255, 45), 1))
        painter.drawLine(0, int(self.scan_line), w, int(self.scan_line))

        # Corner frames
        painter.setPen(QPen(QColor(132, 148, 149, 90), 1.5))
        pad, ln = 12, 12
        painter.drawLine(pad, pad, pad + ln, pad)
        painter.drawLine(pad, pad, pad, pad + ln)
        painter.drawLine(w - pad, pad, w - pad - ln, pad)
        painter.drawLine(w - pad, pad, w - pad, pad + ln)
        painter.drawLine(pad, h - pad, pad + ln, h - pad)
        painter.drawLine(pad, h - pad, pad, h - pad - ln)
        painter.drawLine(w - pad, h - pad, w - pad - ln, h - pad)
        painter.drawLine(w - pad, h - pad, w - pad, h - pad - ln)

        # Overlay labels
        painter.setPen(QColor(185, 202, 202, 190))
        painter.setFont(QFont("Consolas", 8, QFont.Bold))
        painter.drawText(16, 26, f"LAYER: {self.layer_name}")
        painter.drawText(16, 44, f"POINTS: {len(self.points)}  |  ZOOM: {self.zoom:.1f}x")
        painter.setPen(QColor(0, 245, 255, 155))
        painter.drawText(w - 140, 26, "EPSG:4326")


class MainDialog(QDialog):
    """Native PyQt version of the QGIS Plate Analyzer interface."""

    CITIES: Dict[str, List[str]] = {
        "Colombia": ["Bogota D.C.", "Medellin", "Cali", "Barranquilla", "Bucaramanga", "Cartagena", "Neiva"],
        "Mexico": ["Ciudad de Mexico", "Guadalajara", "Monterrey", "Puebla", "Tijuana"],
        "Espana": ["Madrid", "Barcelona", "Valencia", "Sevilla", "Zaragoza"],
        "Chile": ["Santiago", "Valparaiso", "Concepcion", "La Serena"],
        "Argentina": ["Buenos Aires", "Cordoba", "Rosario", "Mendoza"],
    }

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.db = DBManager()
        self.is_connected = False
        self.active_tab = 0
        self.nav_buttons: List[QPushButton] = []
        self.layer_id_by_label: Dict[str, str] = {}
        self.confirmed_analysis_layer_id = ""
        self.confirmed_analysis_layer_name = ""
        self.last_analysis_result: Optional[Dict[str, Any]] = None
        self.last_report_path: Optional[Path] = None
        self.table_meta_by_label: Dict[str, Dict[str, object]] = {}
        self.last_log_message = "Esperando acciones..."
        self.show_heatmap = False
        self.mask_enabled = True
        self.plugin_root = Path(__file__).resolve().parents[1]
        self.json_dir = self.plugin_root / "core" / "json"
        self.runtime_config: Dict[str, object] = {}
        self.column_mapping: Dict[str, object] = {}
        self.cities_cache: Dict[str, object] = {}
        self.run_by_country: Dict[str, Dict[str, object]] = {}
        self.city_entries_by_country: Dict[str, List[Dict[str, str]]] = {}
        self.admin_entries_source_by_country: Dict[str, str] = {}

        self.setWindowTitle("QGIS Plate Analyzer")
        self.setWindowFlags(
            self.windowFlags()
            | Qt.Window
            | Qt.WindowMinimizeButtonHint
            | Qt.WindowMaximizeButtonHint
            | Qt.WindowCloseButtonHint
        )
        self.setSizeGripEnabled(True)
        self.resize(1220, 820)
        self.setMinimumSize(980, 680)
        self.setObjectName("mainDialog")
        self._load_json_configuration()
        self._apply_styles()
        self._build()
        self._refresh_qgis_layers()
        self.add_log("Inicializando plugin de QGIS 'Analisis de Placas'...", "info")
        self.add_log("Interfaz nativa cargada sin QtWebEngine.", "success")
        self.add_log("Esperando conexion a base de datos externa de PostGIS...", "warning")

    # ------------------------------------------------------------------
    # UI construction helpers
    # ------------------------------------------------------------------
    def _read_json_file(self, filename: str) -> Dict[str, object]:
        path = self.json_dir / filename
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)

    def _cache_entries_for_dbname(self, dbname: str) -> List[Dict[str, str]]:
        if not isinstance(self.cities_cache, dict):
            return []

        cached = self.cities_cache.get(dbname, {})
        raw_entries = []

        if isinstance(cached, dict):
            for key in ("cities", "municipios", "municipalities", "items", "data"):
                value = cached.get(key)
                if isinstance(value, list):
                    raw_entries = value
                    break
        elif isinstance(cached, list):
            raw_entries = cached

        normalized_entries: List[Dict[str, str]] = []
        seen = set()

        for entry in raw_entries:
            if isinstance(entry, dict):
                city = str(
                    entry.get("ciudad")
                    or entry.get("municipio")
                    or entry.get("nivel_2")
                    or entry.get("city")
                    or entry.get("name")
                    or ""
                ).strip()
                dep = str(
                    entry.get("dep")
                    or entry.get("departamento")
                    or entry.get("nivel_1")
                    or entry.get("department")
                    or entry.get("state")
                    or ""
                ).strip()
            else:
                city = str(entry or "").strip()
                dep = ""

            if not city:
                continue

            key = (city.upper(), dep.upper())
            if key in seen:
                continue

            seen.add(key)
            normalized_entries.append({"ciudad": city, "dep": dep})

        normalized_entries.sort(key=lambda item: (item["dep"], item["ciudad"]))
        return normalized_entries

    def _load_json_configuration(self):
        try:
            self.runtime_config = self._read_json_file("config_Sincontra.json")
            self.column_mapping = self._read_json_file("column_mapping - DEF.json")
            self.cities_cache = self._read_json_file("cities_cache.json")
        except Exception:
            self.runtime_config = {}
            self.column_mapping = {}
            self.cities_cache = {}
            self.run_by_country = {}
            self.city_entries_by_country = {}
            self.admin_entries_source_by_country = {}
            return

        self.run_by_country = {}
        for run in self.runtime_config.get("runs", []):
            if not isinstance(run, dict):
                continue
            country = str(run.get("country") or "").strip()
            dbname = str(run.get("dbname") or "").strip()
            if country and dbname and country not in self.run_by_country:
                self.run_by_country[country] = run

        self.city_entries_by_country = {}
        self.admin_entries_source_by_country = {}
        for country, run in self.run_by_country.items():
            dbname = str(run.get("dbname") or "").strip()
            self.city_entries_by_country[country] = self._cache_entries_for_dbname(dbname)
            self.admin_entries_source_by_country[country] = "cities_cache.json"

    def _apply_styles(self):
        self.setStyleSheet(
            """
            QDialog#mainDialog { background: #0e0e10; color: #e5e1e4; font-family: Segoe UI, Inter, Arial; }
            QFrame#sidebar { background: #1c1b1d; border-right: 1px solid #3a494a; }
            QFrame#brand { border-bottom: 1px solid rgba(58,73,74,80); }
            QLabel#brandTitle { color: white; font-size: 14px; font-weight: 900; letter-spacing: 1px; }
            QLabel#brandVersion { color: rgba(185,202,202,170); font-family: Consolas; font-size: 10px; }
            QPushButton#navButton { background: transparent; color: #b9caca; border: none; border-right: 2px solid transparent; padding: 13px 20px; text-align: left; font-size: 12px; font-weight: 700; }
            QPushButton#navButton:hover { background: rgba(42,42,44,150); color: #e9feff; }
            QPushButton#navButton[active="true"] { background: rgba(0,165,114,28); color: #4edea3; border-right: 2px solid #4edea3; }
            QPushButton#connectShortcut { border: none; border-radius: 10px; padding: 10px 12px; font-weight: 900; font-size: 10px; color: #051313; background: #00f5ff; }
            QPushButton#connectShortcut[connected="true"] { color: white; background: #dc2626; }
            QPushButton#sideLink { text-align: left; background: transparent; color: #b9caca; border: none; border-radius: 8px; padding: 8px 10px; font-size: 12px; font-weight: 650; }
            QPushButton#sideLink:hover { background: rgba(42,42,44,110); color: #e9feff; }
            QFrame#workspace { background: #070708; }
            QFrame#topbar { background: rgba(19,19,21,230); border-bottom: 1px solid rgba(58,73,74,95); }
            QLabel#topTitle { color: #00f5ff; font-size: 13px; font-weight: 900; letter-spacing: 2px; text-transform: uppercase; }
            QLabel#topSubtitle { color: #b9caca; font-size: 12px; font-weight: 650; }
            QFrame#card { background: #131315; border: 1px solid #3a494a; border-radius: 14px; }
            QFrame#cardAccent { background: #131315; border: 1px solid #3a494a; border-radius: 14px; border-left: 5px solid rgba(0,245,255,145); }
            QScrollArea#cardScroll { background: transparent; border: none; }
            QScrollArea#cardScroll > QWidget > QWidget { background: transparent; }
            QScrollBar:vertical { background: rgba(42,42,44,120); width: 10px; margin: 2px; border-radius: 5px; }
            QScrollBar::handle:vertical { background: rgba(78,222,163,150); border-radius: 5px; min-height: 26px; }
            QScrollBar::handle:vertical:hover { background: #4edea3; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; border: none; background: transparent; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
            QLabel#cardTitle { color: #e9feff; font-size: 17px; font-weight: 800; }
            QLabel#fieldLabel { color: #b9caca; font-size: 11px; font-weight: 750; letter-spacing: .8px; text-transform: uppercase; }
            QLabel#hint { color: rgba(185,202,202,150); font-size: 11px; }
            QLabel#metric { color: #4edea3; font-family: Consolas; font-weight: 800; }
            QLineEdit, QComboBox, QDoubleSpinBox { background: #0e0e10; border: 1px solid #3a494a; border-radius: 8px; padding: 7px 9px; color: #e5e1e4; font-family: Consolas; font-size: 12px; }
            QLineEdit:focus, QComboBox:focus, QDoubleSpinBox:focus { border: 1px solid #00f5ff; }
            QComboBox::drop-down { border: none; width: 24px; }
            QComboBox QAbstractItemView { background: #201f22; color: #e5e1e4; border: 1px solid #3a494a; selection-background-color: #00a572; }
            QPushButton#primaryButton { background: #00f5ff; color: #062224; border: none; border-radius: 10px; padding: 10px 14px; font-weight: 900; }
            QPushButton#primaryButton:hover { background: #52fbff; }
            QPushButton#secondaryButton { background: rgba(78,222,163,40); color: #4edea3; border: 1px solid rgba(78,222,163,130); border-radius: 10px; padding: 9px 12px; font-weight: 800; }
            QPushButton#secondaryButton:hover { background: rgba(78,222,163,70); }
            QPushButton#ghostButton { background: rgba(42,42,44,120); color: #b9caca; border: 1px solid rgba(58,73,74,180); border-radius: 8px; padding: 7px 10px; font-weight: 700; }
            QPushButton#ghostButton:hover { color: #e9feff; border-color: #00f5ff; }
            QPushButton#dangerGhost { background: transparent; color: #ffb4ab; border: 1px solid rgba(255,180,171,90); border-radius: 8px; padding: 6px 10px; font-weight: 700; }
            QPushButton#dangerButton { background: #dc2626; color: #fff7f7; border: none; border-radius: 10px; padding: 10px 14px; font-weight: 900; }
            QPushButton#dangerButton:hover { background: #ef4444; }
            QPushButton#dangerButton:disabled { background: rgba(127,29,29,120); color: rgba(255,255,255,120); }
            QTextEdit#logs { background: rgba(0,0,0,190); color: #b9caca; border: none; font-family: Consolas; font-size: 12px; }
            QFrame#logsPanel { background: #0b0b0c; border-top: 1px solid rgba(58,73,74,95); }
            QFrame#logsHeader { background: rgba(0,0,0,110); border-bottom: 1px solid rgba(58,73,74,120); }
            QFrame#statusbar { background: #0e0e10; border-top: 1px solid #3a494a; }
            QLabel#statusText { font-family: Consolas; font-size: 11px; font-weight: 800; }
            QLabel#tiny { color: #b9caca; font-size: 11px; }
            QProgressBar { background: #2a2a2c; border: 1px solid rgba(58,73,74,120); border-radius: 5px; height: 8px; text-align: center; color: white; font-size: 9px; }
            QProgressBar::chunk { background: #00f5ff; border-radius: 4px; }
            QCheckBox { color: #b9caca; font-size: 12px; spacing: 8px; }
            QCheckBox::indicator { width: 15px; height: 15px; border-radius: 4px; border: 1px solid #3a494a; background: #0e0e10; }
            QCheckBox::indicator:checked { background: #4edea3; border: 1px solid #4edea3; }
            """
        )

    def _build(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_sidebar())
        root.addWidget(self._build_workspace(), 1)

    def _build_sidebar(self) -> QWidget:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(256)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        brand = QFrame()
        brand.setObjectName("brand")
        brand_layout = QVBoxLayout(brand)
        brand_layout.setContentsMargins(24, 22, 24, 22)
        title = QLabel("QGIS PLATE ANALYZER")
        title.setObjectName("brandTitle")
        version = QLabel("v1.9-native")
        version.setObjectName("brandVersion")
        brand_layout.addWidget(title)
        brand_layout.addWidget(version)
        layout.addWidget(brand)

        nav = QVBoxLayout()
        nav.setContentsMargins(0, 24, 0, 0)
        nav.setSpacing(6)
        items = [("1 - Conexion", 0), ("2 - Capas", 1), ("3 - Analisis", 2)]
        for label, index in items:
            btn = QPushButton(label)
            btn.setObjectName("navButton")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _checked=False, idx=index: self.set_tab(idx))
            self.nav_buttons.append(btn)
            nav.addWidget(btn)
        nav.addStretch(1)
        layout.addLayout(nav, 1)

        footer = QFrame()
        footer_layout = QVBoxLayout(footer)
        footer_layout.setContentsMargins(16, 14, 16, 16)
        footer_layout.setSpacing(8)
        self.sidebar_connect_btn = QPushButton("CONNECT DATABASE")
        self.sidebar_connect_btn.setObjectName("connectShortcut")
        self.sidebar_connect_btn.setCursor(Qt.PointingHandCursor)
        self.sidebar_connect_btn.clicked.connect(self._sidebar_connect_clicked)
        footer_layout.addWidget(self.sidebar_connect_btn)

        cfg = QPushButton("Configuracion")
        cfg.setObjectName("sideLink")
        cfg.clicked.connect(lambda: self.set_tab(0))
        update_btn = QPushButton("Buscar actualizaciones")
        update_btn.setObjectName("sideLink")
        update_btn.clicked.connect(self._check_for_updates)
        help_btn = QPushButton("?   Ayuda")
        help_btn.setObjectName("sideLink")
        help_btn.clicked.connect(lambda: self.add_log("Ayuda: revise README.md del complemento o la documentacion oficial de QGIS.", "info"))
        theory_btn = QPushButton("DOC Fundamento teorico")
        theory_btn.setObjectName("sideLink")
        theory_btn.clicked.connect(self._open_theory_html)
        footer_layout.addWidget(cfg)
        footer_layout.addWidget(update_btn)
        footer_layout.addWidget(theory_btn)
        footer_layout.addWidget(help_btn)
        layout.addWidget(footer)
        return sidebar

    def _build_workspace(self) -> QWidget:
        workspace = QFrame()
        workspace.setObjectName("workspace")
        layout = QVBoxLayout(workspace)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(self._build_topbar())
        self.stack = QStackedWidget()
        self.stack.addWidget(self._page_connection())
        self.stack.addWidget(self._page_layers())
        self.stack.addWidget(self._page_analysis())
        layout.addWidget(self.stack, 1)
        layout.addWidget(self._build_logs(), 0)
        layout.addWidget(self._build_statusbar())
        self.set_tab(0)
        return workspace

    def _build_topbar(self) -> QWidget:
        top = QFrame()
        top.setObjectName("topbar")
        top.setFixedHeight(56)
        layout = QHBoxLayout(top)
        layout.setContentsMargins(24, 0, 20, 0)
        self.top_title = QLabel("ANALISIS DE PLACAS")
        self.top_title.setObjectName("topTitle")
        self.top_subtitle = QLabel("Conexion y seleccion")
        self.top_subtitle.setObjectName("topSubtitle")
        layout.addWidget(self.top_title)
        sep = QFrame()
        sep.setFixedWidth(1)
        sep.setFixedHeight(20)
        sep.setStyleSheet("background: rgba(58,73,74,120);")
        layout.addWidget(sep)
        layout.addWidget(self.top_subtitle)
        layout.addStretch(1)
        db_btn = QPushButton("DB")
        db_btn.setObjectName("ghostButton")
        db_btn.clicked.connect(lambda: self.set_tab(0))
        settings_btn = QPushButton("Config")
        settings_btn.setObjectName("ghostButton")
        settings_btn.clicked.connect(lambda: self.add_log("Preferencias todavia no implementadas.", "warning"))
        layout.addWidget(db_btn)
        layout.addWidget(settings_btn)
        return top

    def _build_logs(self) -> QWidget:
        panel = QFrame()
        panel.setObjectName("logsPanel")
        panel.setFixedHeight(145)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        header = QFrame()
        header.setObjectName("logsHeader")
        h = QHBoxLayout(header)
        h.setContentsMargins(16, 7, 16, 7)
        label = QLabel("Logs de sistema / consola de salida")
        label.setObjectName("tiny")
        label.setStyleSheet("font-family: Consolas; font-weight: 800; letter-spacing: 1px;")
        h.addWidget(label)
        h.addStretch(1)
        copy_btn = QPushButton("Copiar")
        copy_btn.setObjectName("ghostButton")
        copy_btn.clicked.connect(self._copy_logs)
        clear_btn = QPushButton("Limpiar")
        clear_btn.setObjectName("dangerGhost")
        clear_btn.clicked.connect(self._clear_logs)
        h.addWidget(copy_btn)
        h.addWidget(clear_btn)
        layout.addWidget(header)
        self.logs_text = QTextEdit()
        self.logs_text.setObjectName("logs")
        self.logs_text.setReadOnly(True)
        layout.addWidget(self.logs_text, 1)
        return panel

    def _build_statusbar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("statusbar")
        bar.setFixedHeight(40)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(14)
        self.status_dot = QLabel("*")
        self.status_dot.setStyleSheet("color: #ffb4ab; font-size: 15px;")
        self.status_text = QLabel("Base de datos: Desconectado")
        self.status_text.setObjectName("statusText")
        self.status_text.setStyleSheet("color: #ffb4ab;")
        layout.addWidget(self.status_dot)
        layout.addWidget(self.status_text)
        self.epsg_label = QLabel("EPSG:4326 (WGS 84)")
        self.epsg_label.setObjectName("tiny")
        layout.addWidget(self.epsg_label)
        layout.addStretch(1)
        self.progress = QProgressBar()
        self.progress.setFixedWidth(250)
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        layout.addWidget(self.progress)
        self.last_log = QLabel("LOG: Esperando acciones...")
        self.last_log.setObjectName("tiny")
        self.last_log.setMinimumWidth(260)
        layout.addWidget(self.last_log)
        self.memory_label = QLabel("Mem: 41.8 MB")
        self.memory_label.setObjectName("tiny")
        layout.addWidget(self.memory_label)
        return bar

    def _card(self, title: str, accent: bool = False) -> Tuple[QFrame, QVBoxLayout]:
        card = QFrame()
        card.setObjectName("cardAccent" if accent else "card")
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(12)
        t = QLabel(title)
        t.setObjectName("cardTitle")
        layout.addWidget(t)
        return card, layout

    def _scroll_card(self, card: QWidget, min_height: int = 180) -> QScrollArea:
        scroll = QScrollArea()
        scroll.setObjectName("cardScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setMinimumHeight(min_height)
        scroll.setWidget(card)
        scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        return scroll

    def _label(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("fieldLabel")
        return label

    def _line(self, text: str = "", password: bool = False) -> QLineEdit:
        edit = QLineEdit(text)
        if password:
            edit.setEchoMode(QLineEdit.Password)
        return edit

    def _primary(self, text: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setObjectName("primaryButton")
        btn.setCursor(Qt.PointingHandCursor)
        return btn

    def _secondary(self, text: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setObjectName("secondaryButton")
        btn.setCursor(Qt.PointingHandCursor)
        return btn

    def _ghost(self, text: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setObjectName("ghostButton")
        btn.setCursor(Qt.PointingHandCursor)
        return btn

    def _page_wrapper(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(18)
        page.main_layout = layout  # type: ignore[attr-defined]
        return page

    # ------------------------------------------------------------------
    # Pages
    # ------------------------------------------------------------------
    def _page_connection(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        db_card, db = self._card("â–£ ConfiguraciÃ³n de Base de Datos", True)
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(11)
        self.host_edit = self._line("localhost")
        self.port_edit = self._line("5432")
        self.database_edit = self._line("gis_db")
        self.user_edit = self._line("postgres")
        self.password_edit = self._line("********", password=True)
        fields = [
            ("Host", self.host_edit),
            ("Puerto", self.port_edit),
            ("Base de datos", self.database_edit),
            ("Usuario", self.user_edit),
            ("ContraseÃ±a", self.password_edit),
        ]
        for r, (name, widget) in enumerate(fields):
            grid.addWidget(self._label(name), r, 0)
            grid.addWidget(widget, r, 1)
        db.addLayout(grid)
        self.connection_status_label = QLabel("Estado: sin conexiÃ³n activa")
        self.connection_status_label.setObjectName("hint")
        db.addWidget(self.connection_status_label)
        btn_row = QHBoxLayout()
        self.connect_btn = self._primary("Conectar")
        self.connect_btn.clicked.connect(self._toggle_connection)
        btn_row.addWidget(self.connect_btn)
        btn_row.addStretch(1)
        db.addLayout(btn_row)

        geo_card, geo = self._card("âŒ– Filtro GeogrÃ¡fico / Municipio", True)
        geo_grid = QGridLayout()
        geo_grid.setHorizontalSpacing(14)
        geo_grid.setVerticalSpacing(11)
        self.schema_combo = QComboBox()
        self.schema_combo.setEditable(True)
        self.schema_combo.addItems(["public", "analisis_espacial", "catastro_nacional", "infraestructura"])
        self.country_combo = QComboBox()
        self.country_combo.addItems(list(self.CITIES.keys()))
        self.country_combo.currentTextChanged.connect(self._update_cities)
        self.city_combo = QComboBox()
        self.city_combo.setEditable(True)
        self._update_cities("Colombia")
        self.municipality_table_edit = self._line("municipios")
        self.municipality_geom_edit = self._line("geom")
        self.municipality_filter_edit = self._line("nombre")
        geo_fields = [
            ("Esquema", self.schema_combo),
            ("PaÃ­s", self.country_combo),
            ("Ciudad / municipio", self.city_combo),
            ("Tabla lÃ­mite", self.municipality_table_edit),
            ("Geom", self.municipality_geom_edit),
            ("Campo filtro", self.municipality_filter_edit),
        ]
        for r, (name, widget) in enumerate(geo_fields):
            geo_grid.addWidget(self._label(name), r, 0)
            geo_grid.addWidget(widget, r, 1)
        geo.addLayout(geo_grid)
        hint = QLabel("Carga el lÃ­mite municipal como mÃ¡scara de anÃ¡lisis en el proyecto QGIS.")
        hint.setObjectName("hint")
        geo.addWidget(hint)
        self.load_municipality_btn = self._secondary("Cargar municipio")
        self.load_municipality_btn.clicked.connect(self._load_municipality)
        geo.addWidget(self.load_municipality_btn)

        row.addWidget(db_card, 1)
        row.addWidget(geo_card, 1)
        layout.addLayout(row)

        info_card, info = self._card("Resumen del flujo", False)
        bullets = QLabel(
            "1. Configura la conexiÃ³n PostGIS.\n"
            "2. Carga el municipio o mÃ¡scara de trabajo.\n"
            "3. Agrega capas desde QGIS o desde PostGIS.\n"
            "4. Ejecuta el modelo de densidad en la pestaÃ±a AnÃ¡lisis."
        )
        bullets.setObjectName("hint")
        info.addWidget(bullets)
        theory_row = QHBoxLayout()
        self.theory_btn = self._secondary("Consultar fundamento teorico")
        self.theory_btn.clicked.connect(self._open_theory_html)
        theory_row.addWidget(self.theory_btn)
        theory_row.addStretch(1)
        info.addLayout(theory_row)
        layout.addWidget(info_card)
        layout.addStretch(1)
        return page

    def _page_connection(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        db_defaults = self.runtime_config.get("db", {}) if isinstance(self.runtime_config, dict) else {}
        countries_with_cache = sorted(
            country for country, entries in self.city_entries_by_country.items() if entries
        )
        countries_without_cache = sorted(
            country for country in self.run_by_country.keys() if country not in countries_with_cache
        )
        countries = countries_with_cache + countries_without_cache or sorted(self.CITIES.keys())

        selector_card, selector = self._card("Area de analisis", True)
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(11)

        self.country_combo = QComboBox()
        self.country_combo.addItems(countries)
        self.country_combo.currentTextChanged.connect(self._update_cities)
        self.department_combo = QComboBox()
        self.department_combo.setEditable(False)
        self.department_combo.currentIndexChanged.connect(lambda _index: self._update_municipalities())
        self.city_combo = QComboBox()
        self.city_combo.setEditable(False)
        self.city_combo.currentIndexChanged.connect(lambda _index: (self._update_resolved_config_label(), self._update_analysis_summary()))
        self.user_edit = self._line(str(db_defaults.get("user") or "postgres"))
        self.password_edit = self._line("", password=True)
        self.password_edit.setPlaceholderText("Contrasena PostgreSQL")

        fields = [
            ("Pais", self.country_combo),
            ("Departamento / nivel 1", self.department_combo),
            ("Municipio / nivel 2", self.city_combo),
            ("Usuario", self.user_edit),
            ("Contrasena", self.password_edit),
        ]
        for r, (name, widget) in enumerate(fields):
            grid.addWidget(self._label(name), r, 0)
            grid.addWidget(widget, r, 1)
        selector.addLayout(grid)

        self.host_edit = self._line(str(db_defaults.get("host") or "localhost"))
        self.port_edit = self._line(str(db_defaults.get("port") or "5432"))
        self.database_edit = self._line("")
        self.schema_combo = QComboBox()
        self.pg_schema_combo = QComboBox()
        self.pg_table_combo = QComboBox()
        self.pg_geom_edit = self._line("geom")
        self.municipality_table_edit = self._line("municipio")
        self.municipality_geom_edit = self._line("geom")
        self.municipality_filter_edit = self._line("nom_mun")

        self.connection_status_label = QLabel("Estado: sin conexion activa")
        self.connection_status_label.setObjectName("hint")
        selector.addWidget(self.connection_status_label)
        btn_row = QHBoxLayout()
        self.connect_btn = self._primary("Conectar con seleccion")
        self.connect_btn.clicked.connect(self._toggle_connection)
        btn_row.addWidget(self.connect_btn)
        self.load_municipality_btn = self._secondary("Cargar municipio")
        self.load_municipality_btn.clicked.connect(self._load_municipality)
        btn_row.addWidget(self.load_municipality_btn)
        btn_row.addStretch(1)
        selector.addLayout(btn_row)

        resolver_card, resolver = self._card("Configuracion automatica", False)
        self.resolved_config_label = QLabel("")
        self.resolved_config_label.setObjectName("hint")
        self.resolved_config_label.setWordWrap(True)
        resolver.addWidget(self.resolved_config_label)
        hint = QLabel("La base de datos y las tablas administrativas se resuelven desde core/json.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        resolver.addWidget(hint)

        row.addWidget(self._scroll_card(selector_card), 1)
        row.addWidget(self._scroll_card(resolver_card), 1)
        layout.addLayout(row)

        info_card, info = self._card("Resumen del flujo", False)
        bullets = QLabel(
            "1. Selecciona pais, departamento y municipio desde cities_cache.json.\n"
            "2. Ingresa usuario y contrasena del servidor PostgreSQL.\n"
            "3. Los JSON resuelven la base, schemas, tablas y columnas del flujo.\n"
            "4. Ejecuta el analisis de densidad con la seleccion administrativa del cache."
        )
        bullets.setObjectName("hint")
        info.addWidget(bullets)
        theory_row = QHBoxLayout()
        self.theory_btn = self._secondary("Consultar fundamento teorico")
        self.theory_btn.clicked.connect(self._open_theory_html)
        theory_row.addWidget(self.theory_btn)
        theory_row.addStretch(1)
        info.addLayout(theory_row)
        layout.addWidget(self._scroll_card(info_card, 140))
        layout.addStretch(1)

        if countries:
            self._update_cities(countries[0])
        return page

    def _page_layers(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        left_card, left = self._card("â–£ Capas activas en QGIS", True)
        qgis_grid = QGridLayout()
        qgis_grid.setVerticalSpacing(11)
        self.qgis_layer_combo = QComboBox()
        self.qgis_layer_combo.currentTextChanged.connect(self._on_qgis_layer_changed)
        self.refresh_layers_btn = self._ghost("Actualizar lista")
        self.refresh_layers_btn.clicked.connect(self._refresh_qgis_layers)
        self.confirm_analysis_layer_btn = self._secondary("Confirmar capa a analizar")
        self.confirm_analysis_layer_btn.clicked.connect(self._confirm_analysis_layer_from_layers_panel)
        qgis_grid.addWidget(self._label("Capa vectorial"), 0, 0)
        qgis_grid.addWidget(self.qgis_layer_combo, 0, 1)
        qgis_grid.addWidget(self.refresh_layers_btn, 1, 1)
        left.addLayout(qgis_grid)
        left.addWidget(self.confirm_analysis_layer_btn)
        self.layer_info_label = QLabel("Sin capa seleccionada")
        self.layer_info_label.setObjectName("hint")
        left.addWidget(self.layer_info_label)
        self.confirmed_layer_label = QLabel("Capa confirmada para analisis: ninguna")
        self.confirmed_layer_label.setObjectName("hint")
        self.confirmed_layer_label.setWordWrap(True)
        left.addWidget(self.confirmed_layer_label)
        self.mask_checkbox = QCheckBox("Usar mÃ¡scara municipal para recortar el anÃ¡lisis")
        self.mask_checkbox.setChecked(True)
        self.mask_checkbox.stateChanged.connect(lambda state: self._set_mask_enabled(state == Qt.Checked))
        left.addWidget(self.mask_checkbox)

        postgis_card, pg = self._card("â–£ Cargar capa desde PostGIS", True)
        pg_grid = QGridLayout()
        pg_grid.setVerticalSpacing(11)
        self.pg_schema_combo = QComboBox()
        self.pg_schema_combo.setEditable(True)
        self.pg_schema_combo.addItems(["public", "analisis_espacial", "catastro_nacional"])
        self.pg_schema_combo.currentTextChanged.connect(self._schema_changed)
        self.pg_table_combo = QComboBox()
        self.pg_table_combo.setEditable(True)
        self.pg_table_combo.addItems(["tbl_placas_georef", "manzanas_catastrales_v1", "sitios_interes"])
        self.pg_geom_edit = self._line("geom")
        pg_grid.addWidget(self._label("Esquema"), 0, 0)
        pg_grid.addWidget(self.pg_schema_combo, 0, 1)
        pg_grid.addWidget(self._label("Tabla"), 1, 0)
        pg_grid.addWidget(self.pg_table_combo, 1, 1)
        pg_grid.addWidget(self._label("Geom"), 2, 0)
        pg_grid.addWidget(self.pg_geom_edit, 2, 1)
        pg.addLayout(pg_grid)
        self.add_pg_layer_btn = self._secondary("Agregar al proyecto QGIS")
        self.add_pg_layer_btn.clicked.connect(self._add_postgis_layer)
        pg.addWidget(self.add_pg_layer_btn)
        self.pg_hint = QLabel("Al conectar la base de datos, esta lista se actualiza con geometry_columns.")
        self.pg_hint.setObjectName("hint")
        pg.addWidget(self.pg_hint)

        row.addWidget(left_card, 1)
        row.addWidget(postgis_card, 1)
        layout.addLayout(row)

        map_card, map_layout = self._card("â–£ Vista previa GIS", False)
        self.map_preview = MapPreviewWidget()
        map_layout.addWidget(self.map_preview, 1)
        map_footer = QHBoxLayout()
        self.heatmap_toggle_btn = self._ghost("Alternar heatmap")
        self.heatmap_toggle_btn.clicked.connect(self._toggle_heatmap)
        map_footer.addWidget(self.heatmap_toggle_btn)
        map_footer.addStretch(1)
        map_footer.addWidget(QLabel("Grid â€¢ MÃ¡scara â€¢ Puntos â€¢ Kernel preview"))
        map_layout.addLayout(map_footer)
        layout.addWidget(map_card, 1)
        return page

    def _page_layers(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        left_card, left = self._card("Capas activas en QGIS", True)
        qgis_grid = QGridLayout()
        qgis_grid.setVerticalSpacing(11)
        self.qgis_layer_combo = QComboBox()
        self.qgis_layer_combo.currentTextChanged.connect(self._on_qgis_layer_changed)
        self.refresh_layers_btn = self._ghost("Actualizar lista")
        self.refresh_layers_btn.clicked.connect(self._refresh_qgis_layers)
        self.confirm_analysis_layer_btn = self._primary("Confirmar capa a analizar")
        self.confirm_analysis_layer_btn.clicked.connect(self._confirm_analysis_layer_from_layers_panel)
        qgis_grid.addWidget(self._label("Capa vectorial"), 0, 0)
        qgis_grid.addWidget(self.qgis_layer_combo, 0, 1)
        qgis_grid.addWidget(self.refresh_layers_btn, 1, 1)
        left.addLayout(qgis_grid)
        left.addWidget(self.confirm_analysis_layer_btn)
        self.layer_info_label = QLabel("Sin capa seleccionada")
        self.layer_info_label.setObjectName("hint")
        left.addWidget(self.layer_info_label)
        self.confirmed_layer_label = QLabel("Capa confirmada para analisis: ninguna")
        self.confirmed_layer_label.setObjectName("hint")
        self.confirmed_layer_label.setWordWrap(True)
        left.addWidget(self.confirmed_layer_label)
        self.mask_checkbox = QCheckBox("Usar ciudad seleccionada como mascara de analisis")
        self.mask_checkbox.setChecked(True)
        self.mask_checkbox.stateChanged.connect(lambda state: self._set_mask_enabled(state == Qt.Checked))
        left.addWidget(self.mask_checkbox)

        auto_card, auto = self._card("Carga automatica", False)
        self.auto_layer_hint = QLabel("El analisis usara la capa vectorial de puntos seleccionada en el panel de analisis.")
        self.auto_layer_hint.setObjectName("hint")
        self.auto_layer_hint.setWordWrap(True)
        auto.addWidget(self.auto_layer_hint)
        self.auto_load_city_btn = self._secondary("Cargar municipio seleccionado")
        self.auto_load_city_btn.clicked.connect(self._load_municipality)
        auto.addWidget(self.auto_load_city_btn)

        row.addWidget(self._scroll_card(left_card), 1)
        row.addWidget(self._scroll_card(auto_card), 1)
        layout.addLayout(row)

        map_card, map_layout = self._card("Vista previa GIS", False)
        self.map_preview = MapPreviewWidget()
        map_layout.addWidget(self.map_preview, 1)
        map_footer = QHBoxLayout()
        self.heatmap_toggle_btn = self._ghost("Alternar heatmap")
        self.heatmap_toggle_btn.clicked.connect(self._toggle_heatmap)
        map_footer.addWidget(self.heatmap_toggle_btn)
        map_footer.addStretch(1)
        map_footer.addWidget(QLabel("Grid - Mascara - Puntos - Kernel preview"))
        map_layout.addLayout(map_footer)
        layout.addWidget(self._scroll_card(map_card, 260), 1)
        return page

    def _page_analysis(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        config_card, config = self._card("â–£ ParÃ¡metros del Modelo", True)
        grid = QGridLayout()
        grid.setVerticalSpacing(11)
        self.analysis_layer_combo = QComboBox()
        self.analysis_layer_combo.currentTextChanged.connect(
            lambda text: (self._on_qgis_layer_changed(text), self._update_analysis_summary())
        )
        self.analysis_method_combo = QComboBox()
        self.analysis_method_combo.addItems([
            "kde Â· Kernel Density",
            "dbscan Â· Cluster DBSCAN",
            "nearest_neighbor Â· Vecino mÃ¡s cercano",
            "getis_ord Â· Hot Spots Getis-Ord",
        ])
        self.radius_spin = QDoubleSpinBox()
        self.radius_spin.setRange(1, 999999)
        self.radius_spin.setValue(500)
        self.radius_spin.setSuffix(" m")
        self.pixel_spin = QDoubleSpinBox()
        self.pixel_spin.setRange(1, 999999)
        self.pixel_spin.setValue(50)
        self.pixel_spin.setSuffix(" m")
        self.weight_edit = self._line("")
        rows = [
            ("Capa de entrada", self.analysis_layer_combo),
            ("MÃ©todo", self.analysis_method_combo),
            ("Radio", self.radius_spin),
            ("TamaÃ±o pixel", self.pixel_spin),
            ("Campo peso", self.weight_edit),
        ]
        for r, (name, widget) in enumerate(rows):
            grid.addWidget(self._label(name), r, 0)
            grid.addWidget(widget, r, 1)
        config.addLayout(grid)
        self.run_analysis_btn = self._primary("Ejecutar AnÃ¡lisis")
        self.run_analysis_btn.clicked.connect(self._run_analysis)
        config.addWidget(self.run_analysis_btn)
        self.analysis_hint = QLabel("El KDE nativo se ejecuta si QGIS Processing lo tiene disponible; si no, se genera una capa resumen segura.")
        self.analysis_hint.setObjectName("hint")
        self.analysis_hint.setWordWrap(True)
        config.addWidget(self.analysis_hint)

        preview_card, preview = self._card("â–£ Modelo de Densidad Kernel", False)
        self.analysis_preview = MapPreviewWidget()
        self.analysis_preview.set_heatmap(True)
        preview.addWidget(self.analysis_preview, 1)
        metrics = QHBoxLayout()
        self.metric_method = QLabel("METHOD: KDE")
        self.metric_method.setObjectName("metric")
        self.metric_radius = QLabel("RADIUS: 500 m")
        self.metric_radius.setObjectName("metric")
        self.metric_pixel = QLabel("PIXEL: 50 m")
        self.metric_pixel.setObjectName("metric")
        metrics.addWidget(self.metric_method)
        metrics.addWidget(self.metric_radius)
        metrics.addWidget(self.metric_pixel)
        metrics.addStretch(1)
        preview.addLayout(metrics)

        row.addWidget(self._scroll_card(config_card), 1)
        row.addWidget(self._scroll_card(preview_card), 1)
        layout.addLayout(row, 1)
        return page

    # ------------------------------------------------------------------
    # UI state
    # ------------------------------------------------------------------
    def set_tab(self, index: int):
        self.active_tab = index
        self.stack.setCurrentIndex(index)
        subtitles = ["Conexion y seleccion", "Capas", "Analisis de densidad"]
        self.top_subtitle.setText(subtitles[index])
        for i, btn in enumerate(self.nav_buttons):
            btn.setProperty("active", "true" if i == index else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
        if index in (1, 2):
            self._refresh_qgis_layers(silent=True)

    def _set_connection_state(self, connected: bool):
        self.is_connected = connected
        self.connect_btn.setText("Desconectar" if connected else "Conectar")
        self.sidebar_connect_btn.setText("DISCONNECT DATABASE" if connected else "CONNECT DATABASE")
        self.sidebar_connect_btn.setProperty("connected", "true" if connected else "false")
        self.sidebar_connect_btn.style().unpolish(self.sidebar_connect_btn)
        self.sidebar_connect_btn.style().polish(self.sidebar_connect_btn)
        self.status_dot.setStyleSheet(f"color: {'#4edea3' if connected else '#ffb4ab'}; font-size: 15px;")
        self.status_text.setText(f"Base de datos: {'Conectado' if connected else 'Desconectado'}")
        self.status_text.setStyleSheet(f"color: {'#4edea3' if connected else '#ffb4ab'};")
        self.connection_status_label.setText("Estado: conexion activa" if connected else "Estado: sin conexion activa")

    def _set_processing_state(self, processing: bool, percent: int = 0):
        if processing:
            self.status_dot.setStyleSheet("color: #fbbf24; font-size: 15px;")
            self.status_text.setText("Engine: Processing")
            self.status_text.setStyleSheet("color: #fbbf24;")
        else:
            self._set_connection_state(self.is_connected)
        self.progress.setValue(percent)

    def _update_cities(self, country: str):
        if not hasattr(self, "city_combo"):
            return
        entries = self.city_entries_by_country.get(country, [])
        if hasattr(self, "department_combo"):
            self.department_combo.blockSignals(True)
            self.department_combo.clear()
            if entries:
                departments = sorted({entry.get("dep", "").strip() for entry in entries if entry.get("dep", "").strip()})
                self.department_combo.addItems(departments or [""])
            else:
                self.department_combo.addItem("Sin datos en cities_cache")
            self.department_combo.blockSignals(False)
        self._update_municipalities()
        self._update_resolved_config_label()
        self._update_analysis_summary()

    def _update_municipalities(self):
        if not hasattr(self, "city_combo"):
            return
        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        selected_dep = self.department_combo.currentText().strip() if hasattr(self, "department_combo") else ""
        self.city_combo.clear()
        entries = self.city_entries_by_country.get(country, [])
        if entries:
            for entry in entries:
                city = entry.get("ciudad", "")
                dep = entry.get("dep", "")
                if selected_dep and dep != selected_dep:
                    continue
                self.city_combo.addItem(city, entry)
        else:
            fallback_cities = self.CITIES.get(country, [])
            if fallback_cities:
                self.city_combo.addItems(fallback_cities)
            else:
                self.city_combo.addItem("Sin municipios en cities_cache")
        self._update_resolved_config_label()
        self._update_analysis_summary()

    def _selected_city_entry(self) -> Dict[str, str]:
        if not hasattr(self, "city_combo"):
            return {}
        data = self.city_combo.currentData()
        if isinstance(data, dict):
            return data
        return {"ciudad": self.city_combo.currentText().strip(), "dep": ""}

    def _selected_city_name(self) -> str:
        city = self._selected_city_entry().get("ciudad", "").strip()
        if city == "Sin municipios en cities_cache":
            return ""
        return city

    def _selected_department_name(self) -> str:
        dep = self._selected_city_entry().get("dep", "").strip()
        if dep:
            return dep
        if hasattr(self, "department_combo"):
            current = self.department_combo.currentText().strip()
            if current != "Sin datos en cities_cache":
                return current
        return ""

    def _selected_run(self) -> Dict[str, object]:
        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        return self.run_by_country.get(country, {})

    def _selected_dbname(self) -> str:
        return str(self._selected_run().get("dbname") or "").strip()

    def _has_valid_admin_selection(self) -> bool:
        return bool(self._selected_department_name() and self._selected_city_name())

    def _selected_mapping(self) -> Dict[str, object]:
        dbname = self._selected_dbname()
        mapping = self.column_mapping.get(dbname, {}) if isinstance(self.column_mapping, dict) else {}
        return mapping if isinstance(mapping, dict) else {}

    def _admin_municipality_config(self) -> Tuple[str, str, str, str, str]:
        mapping = self._selected_mapping()
        admin = mapping.get("administrativo", {}) if isinstance(mapping, dict) else {}
        municipio = admin.get("municipio", {}) if isinstance(admin, dict) else {}
        if not isinstance(municipio, dict):
            municipio = {}
        schema = str(admin.get("schema") or "administrativo")
        table = str(municipio.get("table") or "municipio")
        geom = str(municipio.get("geom_column") or "geom")
        city_col = str(municipio.get("city_column") or "nom_mun")
        dep_col = str(municipio.get("department_column") or "nom_dep")
        return schema, table, geom, city_col, dep_col

    def _update_resolved_config_label(self):
        if not hasattr(self, "resolved_config_label"):
            return
        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        city = self._selected_city_name()
        dep = self._selected_department_name()
        dbname = self._selected_dbname() or "sin configurar"
        run = self._selected_run()
        cell_size = run.get("cell_size", "sin configurar") if isinstance(run, dict) else "sin configurar"
        admin_schema, admin_table, admin_geom, city_col, dep_col = self._admin_municipality_config()
        self.resolved_config_label.setText(
            f"Pais: {country or 'sin seleccionar'}\n"
            f"Departamento / nivel 1: {dep or 'sin seleccionar'}\n"
            f"Municipio / nivel 2: {city or 'sin seleccionar'}\n"
            f"Base: {dbname}\n"
            f"Fuente niveles administrativos: {self.admin_entries_source_by_country.get(country, 'sin cargar')}\n"
            f"Administrativo: {admin_schema}.{admin_table} ({admin_geom}, {city_col}, {dep_col})\n"
            f"Tamano de celda: {cell_size} m"
        )

    def _set_mask_enabled(self, enabled: bool):
        self.mask_enabled = enabled
        if hasattr(self, "map_preview"):
            self.map_preview.set_mask_enabled(enabled)
        if hasattr(self, "analysis_preview"):
            self.analysis_preview.set_mask_enabled(enabled)
        self.add_log(f"Mascara municipal {'activada' if enabled else 'desactivada'}.", "info")

    def _toggle_heatmap(self):
        self.show_heatmap = not self.show_heatmap
        self.map_preview.set_heatmap(self.show_heatmap)
        self.add_log(f"Vista heatmap {'activada' if self.show_heatmap else 'desactivada'} en preview.", "info")

    def _open_theory_html(self):
        html_path = (
            Path(__file__).resolve().parents[1]
            / "docs"
            / "fundamentos_teoricos_planchas_dinamico.html"
        )

        if not html_path.exists():
            self.add_log(f"No se encontro el fundamento teorico: {html_path}", "error")
            return

        opened = QDesktopServices.openUrl(QUrl.fromLocalFile(str(html_path)))
        if opened:
            self.add_log("Fundamento teorico abierto en el navegador.", "success")
        else:
            self.add_log(f"No fue posible abrir el HTML: {html_path}", "error")

    def _plugin_version(self) -> str:
        metadata_path = self.plugin_root / "metadata.txt"
        try:
            for line in metadata_path.read_text(encoding="utf-8").splitlines():
                if line.strip().startswith("version="):
                    return line.split("=", 1)[1].strip()
        except Exception:
            pass
        return "0.0.0"

    def _plugin_metadata_value(self, key: str, default: str = "") -> str:
        metadata_path = self.plugin_root / "metadata.txt"
        prefix = f"{key}="
        try:
            for line in metadata_path.read_text(encoding="utf-8").splitlines():
                if line.strip().startswith(prefix):
                    return line.split("=", 1)[1].strip()
        except Exception:
            pass
        return default

    def _update_channel_label(self) -> str:
        try:
            config = self._read_update_config()
        except Exception:
            return "sin canal"
        for key in ("version_url", "zip_url"):
            value = str(config.get(key) or "").replace("\\", "/").strip("/")
            if "/qgis_repo_colombia/" in value:
                return "qgis_repo_colombia"
            if "/qgis_repo/" in value:
                return "qgis_repo"
        return str(config.get("provider") or "local")

    def _version_tuple(self, value: str) -> Tuple[int, ...]:
        parts = []
        for raw_part in str(value).replace("-", ".").split("."):
            digits = "".join(ch for ch in raw_part if ch.isdigit())
            parts.append(int(digits or 0))
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts[:4])

    def _read_update_config(self) -> Dict[str, Any]:
        config_path = self.json_dir / "update_config.json"
        config: Dict[str, Any] = {}

        if config_path.exists():
            try:
                config = json.loads(config_path.read_text(encoding="utf-8-sig"))
            except Exception as exc:
                raise RuntimeError(f"No se pudo leer update_config.json: {exc}")

        config.setdefault("provider", "local")
        return config

    def _github_token(self, config: Dict[str, Any]) -> str:
        token_env = str(config.get("token_env") or DEFAULT_GITHUB_TOKEN_ENV)
        token = str(os.environ.get(token_env, "")).strip()
        if token:
            return token

        token_file = Path(str(config.get("token_file") or DEFAULT_GITHUB_TOKEN_FILE)).expanduser()
        if token_file.exists():
            return token_file.read_text(encoding="utf-8-sig").strip()

        raise RuntimeError(
            "No se encontro token de GitHub. Configure la variable "
            f"{token_env} o cree el archivo {token_file} con el token en texto plano."
        )

    def _github_contents_url(self, config: Dict[str, Any], repo_path: str) -> str:
        repository = str(config.get("repository") or "").strip()
        branch = str(config.get("branch") or "main").strip()
        if not repository:
            raise RuntimeError("update_config.json no tiene el campo repository.")
        encoded_path = quote(str(repo_path).strip().replace("\\", "/"), safe="/")
        encoded_ref = quote(branch, safe="")
        return f"https://api.github.com/repos/{repository}/contents/{encoded_path}?ref={encoded_ref}"

    def _github_read_bytes(self, config: Dict[str, Any], repo_path: str) -> bytes:
        token = self._github_token(config)
        request = Request(
            self._github_contents_url(config, repo_path),
            headers={
                "Accept": "application/vnd.github.raw",
                "Authorization": f"Bearer {token}",
                "User-Agent": "qgis-plate-analyzer",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        try:
            with urlopen(request, timeout=30) as response:
                return response.read()
        except HTTPError as exc:
            if exc.code == 401:
                raise RuntimeError("GitHub rechazo el token. Revise que sea valido y tenga acceso al repo privado.")
            if exc.code == 403:
                raise RuntimeError("GitHub rechazo la descarga. Revise permisos del token o limite de API.")
            if exc.code == 404:
                raise RuntimeError(f"GitHub no encontro la ruta {repo_path} en el repo configurado.")
            raise RuntimeError(f"GitHub respondio HTTP {exc.code} al leer {repo_path}.")
        except URLError as exc:
            raise RuntimeError(f"No fue posible conectar con GitHub: {exc.reason}")

    def _version_from_metadata_text(self, text: str) -> str:
        for line in str(text).splitlines():
            if line.strip().startswith("version="):
                return line.split("=", 1)[1].strip()
        return ""

    def _load_local_update_manifest(self, config: Dict[str, Any]) -> Tuple[str, str, Dict[str, Any]]:
        version_file = Path(str(config.get("version_file") or DEFAULT_UPDATE_VERSION_FILE))
        zip_file = Path(str(config.get("zip_file") or DEFAULT_UPDATE_ZIP_FILE))
        if not version_file.exists():
            raise RuntimeError(
                "No existe el manifiesto de actualizacion: "
                f"{version_file}. Publique primero el ZIP con scripts/build_plugin.py."
            )

        try:
            manifest = json.loads(version_file.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            raise RuntimeError(f"No se pudo leer el manifiesto {version_file}: {exc}")

        latest_version = str(manifest.get("version") or "").strip()
        if not latest_version:
            raise RuntimeError(f"El manifiesto {version_file} no tiene el campo version.")

        zip_path = Path(str(manifest.get("zip_path") or manifest.get("zip_file") or zip_file))
        return latest_version, str(version_file), {"provider": "local", "zip_path": zip_path}

    def _load_github_update_manifest(self, config: Dict[str, Any]) -> Tuple[str, str, Dict[str, Any]]:
        metadata_path = str(
            config.get("metadata_path")
            or "Complemento-QGIS Ejecutable/qgis_plate_analyzer/metadata.txt"
        )
        zip_repo_path = str(
            config.get("zip_path")
            or "Complemento-QGIS Ejecutable/qgis_plate_analyzer_importar_qgis.zip"
        )
        metadata_text = self._github_read_bytes(config, metadata_path).decode("utf-8", errors="replace")
        latest_version = self._version_from_metadata_text(metadata_text)
        if not latest_version:
            raise RuntimeError(f"No se encontro version= en {metadata_path}.")
        return latest_version, metadata_path, {
            "provider": "github",
            "config": config,
            "zip_repo_path": zip_repo_path,
        }

    def _read_public_url_bytes(self, url: str) -> bytes:
        if not url:
            raise RuntimeError("No se configuro la URL publica de actualizacion.")
        request = Request(
            url,
            headers={
                "User-Agent": "qgis-plate-analyzer",
                "Accept": "application/vnd.github.raw, application/json, */*",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
            },
        )
        try:
            with urlopen(request, timeout=30) as response:
                return response.read()
        except HTTPError as exc:
            if exc.code == 404:
                raise RuntimeError(f"No se encontro la ruta publica: {url}")
            raise RuntimeError(f"El servidor respondio HTTP {exc.code} al leer {url}.")
        except URLError as exc:
            raise RuntimeError(f"No fue posible conectar con la URL publica: {exc.reason}")

    def _load_http_update_manifest(self, config: Dict[str, Any]) -> Tuple[str, str, Dict[str, Any]]:
        version_url = str(config.get("version_url") or "").strip()
        if not version_url:
            raise RuntimeError("update_config.json no tiene el campo version_url.")
        fetch_url = version_url
        separator = "&" if "?" in fetch_url else "?"
        fetch_url = f"{fetch_url}{separator}_qgis_plate_analyzer_ts={int(time.time())}"
        try:
            manifest = json.loads(self._read_public_url_bytes(fetch_url).decode("utf-8-sig"))
        except Exception as exc:
            raise RuntimeError(f"No se pudo leer el manifiesto publico {version_url}: {exc}")

        latest_version = str(manifest.get("version") or "").strip()
        if not latest_version:
            raise RuntimeError(f"El manifiesto publico {version_url} no tiene el campo version.")

        zip_url = str(
            manifest.get("versioned_zip_url")
            or manifest.get("download_url")
            or manifest.get("zip_url")
            or config.get("zip_url")
            or ""
        ).strip()
        if not zip_url:
            raise RuntimeError(f"El manifiesto publico {version_url} no tiene URL de ZIP.")

        plugins_url = str(manifest.get("repository_url") or "").strip()
        if not plugins_url and version_url.endswith("/version.json"):
            plugins_url = version_url.rsplit("/", 1)[0] + "/plugins.xml"
        if plugins_url:
            try:
                xml_fetch_url = plugins_url
                xml_separator = "&" if "?" in xml_fetch_url else "?"
                xml_fetch_url = (
                    f"{xml_fetch_url}{xml_separator}"
                    f"_qgis_plate_analyzer_xml_ts={int(time.time())}"
                )
                plugins_xml = self._read_public_url_bytes(xml_fetch_url).decode(
                    "utf-8-sig", errors="replace"
                )
                xml_version_match = re.search(
                    r'<pyqgis_plugin\b[^>]*\bversion="([^"]+)"',
                    plugins_xml,
                    flags=re.IGNORECASE,
                )
                xml_download_match = re.search(
                    r"<download_url>\s*([^<]+?)\s*</download_url>",
                    plugins_xml,
                    flags=re.IGNORECASE,
                )
                xml_version = xml_version_match.group(1).strip() if xml_version_match else ""
                xml_zip_url = xml_download_match.group(1).strip() if xml_download_match else ""
                if xml_version and self._version_tuple(xml_version) > self._version_tuple(latest_version):
                    latest_version = xml_version
                    if xml_zip_url:
                        zip_url = xml_zip_url
                    version_url = plugins_url
            except Exception as exc:
                self.add_log(
                    "No se pudo validar plugins.xml como respaldo: " + str(exc),
                    "warning",
                )

        return latest_version, version_url, {
            "provider": "http",
            "zip_url": zip_url,
        }

    def _fetch_latest_version(self) -> Tuple[str, str, Dict[str, Any]]:
        config = self._read_update_config()
        provider = str(config.get("provider") or "local").strip().lower()
        if provider == "github":
            return self._load_github_update_manifest(config)
        if provider in {"http", "pages", "github_pages"}:
            return self._load_http_update_manifest(config)
        if provider == "local":
            return self._load_local_update_manifest(config)
        raise RuntimeError(f"Proveedor de actualizacion no soportado: {provider}")

    def _update_download_dir(self) -> Path:
        try:
            qgis_settings_dir = Path(QgsApplication.qgisSettingsDirPath())
            if qgis_settings_dir.exists():
                return qgis_settings_dir / "qgis_plate_analyzer_updates"
        except Exception:
            pass
        return Path(tempfile.gettempdir()) / "qgis_plate_analyzer_updates"

    def _download_update_zip(self, latest_version: str, update_info: Dict[str, Any]) -> Path:
        target_dir = self._update_download_dir()
        target_dir.mkdir(parents=True, exist_ok=True)
        target_path = target_dir / f"qgis_plate_analyzer_update_{latest_version}.zip"

        provider = str(update_info.get("provider") or "local")
        if provider == "github":
            zip_bytes = self._github_read_bytes(update_info["config"], update_info["zip_repo_path"])
            target_path.write_bytes(zip_bytes)
            return target_path
        if provider in {"http", "pages", "github_pages"}:
            zip_url = str(update_info.get("zip_url") or "")
            separator = "&" if "?" in zip_url else "?"
            zip_url = f"{zip_url}{separator}_qgis_plate_analyzer_zip_ts={int(time.time())}"
            zip_bytes = self._read_public_url_bytes(zip_url)
            target_path.write_bytes(zip_bytes)
            return target_path

        zip_path = Path(str(update_info.get("zip_path") or DEFAULT_UPDATE_ZIP_FILE))
        if not zip_path.exists():
            raise RuntimeError(f"No existe el ZIP de actualizacion: {zip_path}")
        shutil.copy2(zip_path, target_path)
        return target_path

    def _install_update_zip(self, zip_path: Path) -> None:
        try:
            import pyplugin_installer
        except Exception as exc:
            raise RuntimeError(f"No se pudo cargar el instalador interno de QGIS: {exc}")

        installer = pyplugin_installer.instance()
        if installer is None or not hasattr(installer, "installFromZipFile"):
            raise RuntimeError("El instalador interno de QGIS no esta disponible.")

        installer.installFromZipFile(str(zip_path))

    def _check_for_updates(self):
        current_version = self._plugin_version()
        plugin_name = self._plugin_metadata_value("name", "Complemento QGIS")
        channel = self._update_channel_label()
        self.add_log(
            f"Buscando actualizaciones para {plugin_name}. Version instalada: {current_version}. Canal: {channel}.",
            "info",
        )
        QApplication.processEvents()

        try:
            latest_version, source, update_info = self._fetch_latest_version()
        except Exception as exc:
            self.add_log("Error revisando actualizaciones: " + str(exc), "error")
            return

        if not latest_version:
            self.add_log("No se encontro version publicada.", "warning")
            return

        self.add_log(f"Version publicada detectada: v{latest_version}", "info")

        if self._version_tuple(latest_version) > self._version_tuple(current_version):
            self.add_log("Nueva actualizacion disponible", "success")
            try:
                target_path = self._download_update_zip(latest_version, update_info)
            except Exception as exc:
                self.add_log("No fue posible descargar el ZIP de actualizacion: " + str(exc), "error")
                return
            QApplication.processEvents()
            try:
                self._install_update_zip(target_path)
            except Exception as exc:
                self.add_log("No fue posible instalar automaticamente la actualizacion: " + str(exc), "error")
                self.add_log(
                    f"ZIP temporal disponible para diagnostico: {target_path}",
                    "warning",
                )
                return
            self.add_log(
                f"Actualizacion v{latest_version} instalada. Reinicie QGIS para asegurar que todos los modulos queden recargados.",
                "success",
            )
        elif self._version_tuple(latest_version) == self._version_tuple(current_version):
            self.add_log(f"El complemento esta actualizado: v{current_version}.", "success")
        else:
            self.add_log(
                f"La version instalada v{current_version} es mas reciente que la publicada v{latest_version}.",
                "warning",
            )

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------
    def add_log(self, message: str, kind: str = "info"):
        timestamp = time.strftime("[%H:%M:%S]")
        color = {
            "info": "#00f5ff",
            "success": "#4edea3",
            "warning": "#fbbf24",
            "error": "#ffb4ab",
        }.get(kind, "#b9caca")
        icon = {
            "info": "i",
            "success": "OK",
            "warning": "!",
            "error": "x",
        }.get(kind, "-")
        safe = str(message).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        self.logs_text.append(
            f'<span style="color:rgba(185,202,202,.55);">{timestamp}</span> '
            f'<span style="color:{color}; font-weight:700;">{icon}</span> '
            f'<span style="color:{color};">{safe}</span>'
        )
        self.last_log_message = message
        self.last_log.setText("LOG: " + (message[:72] + "..." if len(message) > 72 else message))
        self.logs_text.verticalScrollBar().setValue(self.logs_text.verticalScrollBar().maximum())

    def _clear_logs(self):
        self.logs_text.clear()
        self.last_log.setText("LOG: Consola limpia")

    def _copy_logs(self):
        QApplication.clipboard().setText(self.logs_text.toPlainText())
        self.add_log("Logs copiados al portapapeles.", "success")

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def _sidebar_connect_clicked(self):
        if self.is_connected:
            self._toggle_connection()
        else:
            self.set_tab(0)
            self.add_log('Verifique credenciales y pulse "Conectar".', "info")

    def _toggle_connection(self):
        if self.is_connected:
            self.add_log("Cerrando conexion con la base de datos...", "info")
            self._set_connection_state(False)
            self.add_log("Conexion cerrada. Base de datos desconectada.", "warning")
            return

        db_defaults = self.runtime_config.get("db", {}) if isinstance(self.runtime_config, dict) else {}
        country = self.country_combo.currentText().strip()
        dbname = self._selected_dbname()
        if not dbname:
            self.add_log(f"No existe base configurada para el pais seleccionado: {country}", "error")
            return

        password = self.password_edit.text()
        config = DBConfig(
            host=str(db_defaults.get("host") or "localhost"),
            port=str(db_defaults.get("port") or "5432"),
            database=dbname,
            user=self.user_edit.text().strip() or "postgres",
            password=password,
        )
        self.db.update_config(config)
        self.database_edit.setText(dbname)
        self.add_log(f"Intentando conectar a {config.user}@{config.host}:{config.port}/{config.database}...", "info")
        self._set_processing_state(True, 15)
        QApplication.processEvents()
        try:
            ok, msg = self.db.test_connection()
            self.progress.setValue(75)
            QApplication.processEvents()
            if ok:
                self._set_connection_state(True)
                self.progress.setValue(0)
                self.add_log("Conexion establecida con exito. Base de datos en linea.", "success")
                self.add_log("PostgreSQL responde: " + str(msg)[:120], "success")
                self.add_log("Niveles administrativos tomados desde cities_cache.json.", "success")
                self._update_resolved_config_label()
            else:
                self._set_processing_state(False, 0)
                self.add_log("No fue posible conectar: " + str(msg), "error")
        except Exception as exc:
            self._set_processing_state(False, 0)
            self.add_log("Error inesperado al conectar: " + str(exc), "error")
            self.add_log(traceback.format_exc(), "error")

    def _populate_schemas_and_tables(self):
        try:
            schemas = self.db.list_schemas()
            if schemas:
                for combo in (self.schema_combo, self.pg_schema_combo):
                    current = combo.currentText()
                    combo.clear()
                    combo.addItems(schemas)
                    if current in schemas:
                        combo.setCurrentText(current)
                self.add_log(f"Esquemas detectados: {', '.join(schemas[:6])}", "success")
        except Exception as exc:
            self.add_log("No se pudieron listar esquemas: " + str(exc), "warning")
        self._schema_changed(self.pg_schema_combo.currentText())

    def _schema_changed(self, schema: str):
        if not self.is_connected:
            return
        try:
            tables = self.db.list_spatial_tables(schema or "public")
            self.table_meta_by_label.clear()
            self.pg_table_combo.clear()
            for t in tables:
                label = str(t.get("table") or t.get("name") or "")
                if not label:
                    continue
                self.table_meta_by_label[label] = t
                self.pg_table_combo.addItem(label)
            if tables:
                first = tables[0]
                geom = str(first.get("geometry_column") or first.get("geom") or "geom")
                self.pg_geom_edit.setText(geom)
                self.add_log(f"{len(tables)} tablas espaciales detectadas en el esquema {schema}.", "success")
        except Exception as exc:
            self.add_log("No se pudieron listar tablas espaciales: " + str(exc), "warning")

    def _load_municipality(self):
        if not self.is_connected:
            self.add_log("Primero conecte con las credenciales PostgreSQL.", "error")
            return

        schema, table, geom, city_col, dep_col = self._admin_municipality_config()
        city = self._selected_city_name()
        dep = self._selected_department_name()
        if not dep or not city:
            self.add_log("Seleccione un departamento y municipio validos desde la lista administrativa.", "error")
            return
        sql_filter = ""
        if city:
            safe_city = city.replace("'", "''")
            safe_city_col = city_col.replace('"', '""')
            sql_filter = f'"{safe_city_col}" ILIKE \'%{safe_city}%\''
            if dep:
                safe_dep = dep.replace("'", "''")
                safe_dep_col = dep_col.replace('"', '""')
                sql_filter += f' AND "{safe_dep_col}" ILIKE \'%{safe_dep}%\''
        self.add_log(f"Cargando geometria administrativa del municipio: {dep} / {city}...", "info")
        try:
            ok, msg, layer = self.db.load_postgis_layer(schema, table, geom, f"{city or table}_limite", sql_filter)
            if ok:
                self.add_log(msg, "success")
                self._refresh_qgis_layers(silent=True)
                self.set_tab(1)
            else:
                self.add_log(msg, "error")
        except Exception as exc:
            self.add_log("Error cargando municipio: " + str(exc), "error")

    def _add_postgis_layer(self):
        schema = self.pg_schema_combo.currentText().strip() or "public"
        table = self.pg_table_combo.currentText().strip()
        geom = self.pg_geom_edit.text().strip() or "geom"
        if not table:
            self.add_log("Seleccione una tabla PostGIS.", "error")
            return
        self.add_log(f"Conectando al catÃ¡logo PostGIS. Leyendo tabla: {schema}.{table}...", "info")
        try:
            ok, msg, layer = self.db.load_postgis_layer(schema, table, geom, f"{schema}.{table}")
            if ok:
                self.add_log("Detectando columnas de geometrÃ­a... OK", "success")
                self.add_log(msg, "success")
                self._refresh_qgis_layers(silent=True)
            else:
                self.add_log(msg, "error")
        except Exception as exc:
            self.add_log("Error cargando capa PostGIS: " + str(exc), "error")

    def _refresh_qgis_layers(self, silent: bool = False):
        self.layer_id_by_label.clear()
        current_qgis_id = self.qgis_layer_combo.currentData() if hasattr(self, "qgis_layer_combo") else ""
        current_analysis_id = self.analysis_layer_combo.currentData() if hasattr(self, "analysis_layer_combo") else ""
        active_layer = self.iface.activeLayer() if self.iface is not None else None
        active_layer_id = (
            active_layer.id()
            if isinstance(active_layer, QgsVectorLayer) and active_layer.isValid() and active_layer.geometryType() == 0
            else ""
        )
        items: List[Tuple[str, str]] = []
        for layer in QgsProject.instance().mapLayers().values():
            if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
                continue
            if layer.geometryType() != 0:
                continue
            geom = "Point"
            crs = layer.crs().authid() if layer.crs().isValid() else "Sin CRS"
            label = f"{layer.name()}  -  {geom}  -  {crs}  -  {layer.featureCount()} feat"
            self.layer_id_by_label[label] = layer.id()
            items.append((label, layer.id()))
        if hasattr(self, "qgis_layer_combo"):
            self.qgis_layer_combo.blockSignals(True)
            self.qgis_layer_combo.clear()
            if items:
                for label, layer_id in items:
                    self.qgis_layer_combo.addItem(label, layer_id)
                self._set_combo_by_layer_id(
                    self.qgis_layer_combo,
                    str(current_qgis_id or self.confirmed_analysis_layer_id or active_layer_id or ""),
                )
            else:
                self.qgis_layer_combo.addItem("No hay capas vectoriales de puntos activas", "")
            self.qgis_layer_combo.blockSignals(False)
        if hasattr(self, "analysis_layer_combo"):
            self.analysis_layer_combo.blockSignals(True)
            self.analysis_layer_combo.clear()
            if items:
                for label, layer_id in items:
                    self.analysis_layer_combo.addItem(label, layer_id)
                self._set_combo_by_layer_id(
                    self.analysis_layer_combo,
                    str(self.confirmed_analysis_layer_id or current_analysis_id or active_layer_id or ""),
                )
            else:
                self.analysis_layer_combo.addItem("No hay capas vectoriales de puntos activas", "")
            self.analysis_layer_combo.blockSignals(False)
        if hasattr(self, "analysis_layer_combo"):
            self._on_analysis_layer_changed(self.analysis_layer_combo.currentText())
        elif hasattr(self, "qgis_layer_combo"):
            self._on_qgis_layer_changed(self.qgis_layer_combo.currentText())
        if not silent:
            self.add_log(f"Lista de capas QGIS actualizada: {len(items)} capa(s) de puntos.", "info")

    def _set_combo_by_layer_id(self, combo: QComboBox, layer_id: str) -> bool:
        if not layer_id:
            return False
        for index in range(combo.count()):
            if str(combo.itemData(index) or "") == layer_id:
                combo.setCurrentIndex(index)
                return True
        return False

    def _layer_from_combo(self, combo: QComboBox):
        layer_id = str(combo.currentData() or "")
        if not layer_id:
            layer_id = self.layer_id_by_label.get(combo.currentText().strip(), "")
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None
        if isinstance(layer, QgsVectorLayer) and layer.isValid():
            return layer
        return None

    def _layer_from_id(self, layer_id: str):
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None
        if isinstance(layer, QgsVectorLayer) and layer.isValid():
            return layer
        return None

    def _confirm_analysis_layer_from_layers_panel(self):
        if not hasattr(self, "qgis_layer_combo"):
            self.add_log("No esta disponible la lista de capas activas.", "error")
            return

        layer = self._layer_from_combo(self.qgis_layer_combo)
        if layer is None:
            self.add_log("No se pudo confirmar la capa seleccionada.", "error")
            return
        if layer.geometryType() != 0:
            self.add_log("Solo se puede confirmar una capa vectorial de puntos para el analisis.", "error")
            return

        self.confirmed_analysis_layer_id = layer.id()
        self.confirmed_analysis_layer_name = layer.name()

        if hasattr(self, "analysis_layer_combo"):
            self._set_combo_by_layer_id(self.analysis_layer_combo, layer.id())
        if hasattr(self, "analysis_preview"):
            self.analysis_preview.set_layer_name(layer.name())
        if hasattr(self, "confirmed_layer_label"):
            self.confirmed_layer_label.setText(f"Capa confirmada para analisis: {layer.name()}")

        geom = {0: "puntos", 1: "lineas", 2: "poligonos"}.get(layer.geometryType(), "geometria")
        self.add_log(f"Capa confirmada para analisis: {layer.name()} ({geom}).", "success")
        self._update_analysis_summary()

    def _on_analysis_layer_changed(self, label: str):
        self._on_qgis_layer_changed(label)
        layer = self._layer_from_combo(self.analysis_layer_combo) if hasattr(self, "analysis_layer_combo") else None
        if isinstance(layer, QgsVectorLayer):
            geom = {0: "puntos", 1: "lineas", 2: "poligonos"}.get(layer.geometryType(), "geometria")
            self.add_log(f"Capa seleccionada para analisis: {layer.name()} ({geom}).", "info")

    def _on_qgis_layer_changed(self, label: str):
        layer_id = self.layer_id_by_label.get(label)
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None
        if layer is None and hasattr(self, "analysis_layer_combo") and self.analysis_layer_combo.currentText() == label:
            layer = self._layer_from_combo(self.analysis_layer_combo)
        if layer is None and hasattr(self, "qgis_layer_combo") and self.qgis_layer_combo.currentText() == label:
            layer = self._layer_from_combo(self.qgis_layer_combo)
        if isinstance(layer, QgsVectorLayer):
            geom = {0: "Point", 1: "LineString", 2: "Polygon"}.get(layer.geometryType(), "Geometry")
            crs = layer.crs().authid() if layer.crs().isValid() else "Sin CRS"
            self.layer_info_label.setText(
                f"Nombre: {layer.name()}\nTipo: Vectorial / {geom}\nCRS: {crs}\nEntidades: {layer.featureCount()}\nExtent: {layer.extent().toString()}"
            )
            if hasattr(self, "map_preview"):
                self.map_preview.set_layer_name(layer.name())
            if hasattr(self, "analysis_preview"):
                self.analysis_preview.set_layer_name(layer.name())
        else:
            if hasattr(self, "layer_info_label"):
                self.layer_info_label.setText("Sin capa vectorial seleccionada.")

    def _selected_analysis_layer(self):
        confirmed_layer = self._layer_from_id(self.confirmed_analysis_layer_id)
        if confirmed_layer is not None:
            return confirmed_layer
        if hasattr(self, "analysis_layer_combo"):
            return self._layer_from_combo(self.analysis_layer_combo)
        return None

    def _safe_metric_gdf(self, gdf):
        if gdf is None or getattr(gdf, "empty", True):
            return gdf
        if getattr(gdf, "crs", None) is None:
            return gdf
        try:
            if gdf.crs.is_geographic:
                metric_crs = gdf.estimate_utm_crs()
                if metric_crs is not None:
                    return gdf.to_crs(metric_crs)
                return gdf.to_crs(epsg=3857)
        except Exception:
            try:
                return gdf.to_crs(epsg=3857)
            except Exception:
                return gdf
        return gdf

    def _geometry_area_m2(self, gdf) -> float:
        if gdf is None or getattr(gdf, "empty", True):
            return 0.0
        try:
            metric = self._safe_metric_gdf(gdf)
            union = metric.geometry.unary_union
            return float(union.area)
        except Exception:
            try:
                return float(self._safe_metric_gdf(gdf).geometry.area.sum())
            except Exception:
                return 0.0

    def _format_area(self, area_m2: float) -> str:
        area_m2 = float(area_m2 or 0.0)
        return f"{area_m2 / 1_000_000:,.3f} km2 ({area_m2:,.0f} m2)"

    def _report_value(self, value: object) -> str:
        return html.escape(str(value if value is not None else ""))

    def _svg_pie_chart(self, items: List[Tuple[str, float, str]], title: str) -> str:
        valid_items = [(label, float(value or 0.0), color) for label, value, color in items if float(value or 0.0) > 0]
        total = sum(value for _, value, _ in valid_items)
        if total <= 0:
            return '<p class="muted">No hay datos suficientes para graficar.</p>'

        cx = cy = 90.0
        radius = 72.0
        start_angle = -90.0
        paths = []
        legend = []

        for label, value, color in valid_items:
            angle = (value / total) * 360.0
            end_angle = start_angle + angle
            if angle >= 359.999:
                path = f'<circle cx="{cx}" cy="{cy}" r="{radius}" fill="{color}" />'
            else:
                start_rad = math.radians(start_angle)
                end_rad = math.radians(end_angle)
                x1 = cx + radius * math.cos(start_rad)
                y1 = cy + radius * math.sin(start_rad)
                x2 = cx + radius * math.cos(end_rad)
                y2 = cy + radius * math.sin(end_rad)
                large_arc = 1 if angle > 180.0 else 0
                path = (
                    f'<path d="M {cx:.3f} {cy:.3f} L {x1:.3f} {y1:.3f} '
                    f'A {radius:.3f} {radius:.3f} 0 {large_arc} 1 {x2:.3f} {y2:.3f} Z" '
                    f'fill="{color}" />'
                )
            pct = (value / total * 100.0) if total > 0 else 0.0
            paths.append(path)
            legend.append(
                '<div class="legend-item">'
                f'<span class="swatch" style="background:{color}"></span>'
                f'<span>{self._report_value(label)}</span>'
                f'<strong>{pct:,.1f}%</strong>'
                '</div>'
            )
            start_angle = end_angle

        return (
            '<div class="chart-card">'
            f'<h3>{self._report_value(title)}</h3>'
            '<div class="chart-layout">'
            '<svg class="pie-chart" viewBox="0 0 180 180" role="img">'
            + "".join(paths)
            + '<circle cx="90" cy="90" r="34" fill="#ffffff" />'
            + '</svg>'
            + '<div class="legend">'
            + "".join(legend)
            + '</div></div></div>'
        )

    def _svg_bar_chart(self, items: List[Tuple[str, float, str, str]], title: str) -> str:
        valid_items = [(label, float(value or 0.0), color, detail) for label, value, color, detail in items]
        max_value = max([value for _, value, _, _ in valid_items] or [0.0])
        if max_value <= 0:
            return '<p class="muted">No hay datos suficientes para graficar.</p>'

        plot_width = 360.0
        plot_height = 230.0
        baseline = 185.0
        top = 24.0
        bar_width = 64.0
        gap = 52.0
        left = 46.0
        max_bar_height = baseline - top
        bars = []
        details = []

        for idx, (label, value, color, detail) in enumerate(valid_items):
            x = left + idx * (bar_width + gap)
            height = max(3.0, (value / max_value) * max_bar_height)
            y = baseline - height
            value_km2 = value / 1_000_000.0
            bars.append(
                f'<rect x="{x:.1f}" y="{y:.1f}" width="{bar_width:.1f}" height="{height:.1f}" '
                f'rx="4" fill="{color}" />'
                f'<text x="{x + bar_width / 2:.1f}" y="{max(14.0, y - 8.0):.1f}" '
                f'class="bar-svg-value" text-anchor="middle">{value_km2:,.2f} km2</text>'
                f'<text x="{x + bar_width / 2:.1f}" y="212" '
                f'class="bar-svg-label" text-anchor="middle">{self._report_value(label)}</text>'
            )
            details.append(
                '<div class="legend-item">'
                f'<span class="swatch" style="background:{color}"></span>'
                f'<span>{self._report_value(label)}</span>'
                f'<strong>{self._report_value(detail)}</strong>'
                '</div>'
            )

        return (
            '<div class="chart-card">'
            f'<h3>{self._report_value(title)}</h3>'
            '<svg class="vertical-bar-chart" viewBox="0 0 360 230" role="img">'
            '<line x1="28" y1="185" x2="338" y2="185" class="axis-line" />'
            '<line x1="28" y1="24" x2="28" y2="185" class="axis-line muted-axis" />'
            + "".join(bars)
            + '</svg>'
            '<div class="legend compact">'
            + "".join(details)
            + '</div></div>'
        )

    def _generate_density_report(self):
        result = self.last_analysis_result
        if not result:
            self.add_log("Ejecute primero un analisis de densidad para generar el informe.", "error")
            return

        mask = result.get("mask")
        analysis_polygons = result.get("density_zones")
        if analysis_polygons is None:
            analysis_polygons = result.get("voronoi")
        points = result.get("points")
        kde_surface = result.get("kde_surface")
        params = result.get("parameters") or {}

        if analysis_polygons is None or getattr(analysis_polygons, "empty", True):
            self.add_log("No hay capa poligonal de analisis disponible para generar el informe.", "error")
            return

        if "cobertura" in analysis_polygons.columns:
            coverage = analysis_polygons["cobertura"].astype(str).str.lower()
            uncovered_mask = coverage == "no cubierto"
            covered_mask = coverage == "cubierto"
            no_construction_mask = coverage == "sin construcciones"
        elif "prioridad_sin_placas" in analysis_polygons.columns:
            priority = analysis_polygons["prioridad_sin_placas"].astype(str).str.lower()
            uncovered_mask = priority == "alta"
            covered_mask = priority == "baja"
            no_construction_mask = priority == "sin_construcciones"
        else:
            self.add_log("El resultado no contiene el campo cobertura.", "error")
            return

        total_area_m2 = self._geometry_area_m2(mask)
        if total_area_m2 <= 0:
            total_area_m2 = self._geometry_area_m2(analysis_polygons)

        uncovered = analysis_polygons[uncovered_mask].copy()
        covered = analysis_polygons[covered_mask].copy()
        no_construction = analysis_polygons[no_construction_mask].copy()
        uncovered_area_m2 = self._geometry_area_m2(uncovered)
        covered_area_m2 = self._geometry_area_m2(covered)
        no_construction_area_m2 = self._geometry_area_m2(no_construction)
        high_area_m2 = uncovered_area_m2
        high_pct = (uncovered_area_m2 / total_area_m2 * 100.0) if total_area_m2 > 0 else 0.0
        low_pct = (covered_area_m2 / total_area_m2 * 100.0) if total_area_m2 > 0 else 0.0
        no_construction_pct = (
            no_construction_area_m2 / total_area_m2 * 100.0
            if total_area_m2 > 0
            else 0.0
        )
        total_count = int(len(analysis_polygons))
        points_count = int(len(points)) if points is not None and not getattr(points, "empty", True) else 0
        samples_count = int(len(kde_surface)) if kde_surface is not None and not getattr(kde_surface, "empty", True) else 0

        coverage_chart = self._svg_pie_chart(
            [
                ("No cubierto", uncovered_area_m2, "#c94c4c"),
                ("Cubierto", covered_area_m2, "#2ebaae"),
                ("Sin construcciones", no_construction_area_m2, "#8f8f8f"),
            ],
            "Distribucion por cobertura",
        )

        category_source = kde_surface if kde_surface is not None and not getattr(kde_surface, "empty", True) else analysis_polygons
        category_items = []
        category_palette = {
            "Bajo": "#2ebaae",
            "Medio": "#d48927",
            "Alto": "#c94c4c",
        }
        if category_source is not None and "categoria_busqueda" in category_source.columns:
            for category in ["Bajo", "Medio", "Alto"]:
                subset = category_source[
                    category_source["categoria_busqueda"].astype(str).str.lower() == category.lower()
                ].copy()
                area_m2 = self._geometry_area_m2(subset)
                count = int(len(subset))
                pct = (area_m2 / total_area_m2 * 100.0) if total_area_m2 > 0 else 0.0
                detail = f"{self._format_area(area_m2)} | {pct:,.1f}% | {count:,} hex"
                category_items.append((category, area_m2, category_palette[category], detail))
        category_chart = self._svg_bar_chart(category_items, "Area por categoria de busqueda")

        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        dep = self._selected_department_name()
        city = self._selected_city_name()
        layer_name = self.confirmed_analysis_layer_name or (
            self._selected_analysis_layer().name() if self._selected_analysis_layer() else ""
        )
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        slug_base = "_".join(part for part in [country, dep, city] if part).replace(" ", "_")
        safe_slug = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in slug_base) or "analisis"
        report_dir = self.plugin_root / "reports"
        report_dir.mkdir(parents=True, exist_ok=True)
        report_path = report_dir / f"informe_cobertura_placas_{safe_slug}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"

        document = f"""<!DOCTYPE HTML>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
  <title>Informe de cobertura de placas</title>
  <style>
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      background: #f4f4f4;
      color: #3c3b3b;
      font-family: "Raleway", "Segoe UI", Arial, sans-serif;
      font-size: 15px;
      line-height: 1.75;
    }}
    a {{ color: inherit; text-decoration: none; }}
    #wrapper {{ min-height: 100vh; }}
    #header {{
      align-items: center;
      background: #ffffff;
      border-bottom: solid 1px rgba(160, 160, 160, 0.3);
      display: flex;
      height: 3.5em;
      left: 0;
      line-height: 3.5em;
      position: sticky;
      top: 0;
      z-index: 10;
    }}
    #header h1 {{
      border-right: solid 1px rgba(160, 160, 160, 0.3);
      font-size: 0.8em;
      font-weight: 800;
      letter-spacing: 0.25em;
      margin: 0;
      padding: 0 1.5em;
      text-transform: uppercase;
      white-space: nowrap;
    }}
    #header nav {{ flex: 1; overflow: hidden; }}
    #header nav ul {{
      display: flex;
      gap: 1.5em;
      list-style: none;
      margin: 0;
      padding: 0 1.5em;
    }}
    #header nav a {{
      color: #646464;
      font-size: 0.68em;
      font-weight: 400;
      letter-spacing: 0.25em;
      text-transform: uppercase;
    }}
    #main {{
      display: grid;
      gap: 3em;
      grid-template-columns: minmax(0, 1fr) 21em;
      margin: 0 auto;
      max-width: 1280px;
      padding: 3em 2em;
    }}
    .post {{
      background: #ffffff;
      border: solid 1px rgba(160, 160, 160, 0.3);
      margin: 0 0 3em 0;
    }}
    .post > header {{
      border-bottom: solid 1px rgba(160, 160, 160, 0.3);
      display: grid;
      grid-template-columns: minmax(0, 1fr) 18em;
    }}
    .post > header .title {{ padding: 3em; }}
    .post > header .meta {{
      align-items: center;
      border-left: solid 1px rgba(160, 160, 160, 0.3);
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 3em;
      text-align: right;
    }}
    h1, h2, h3 {{
      color: #3c3b3b;
      font-weight: 800;
      letter-spacing: 0.16em;
      line-height: 1.4;
      margin: 0 0 1em 0;
      text-transform: uppercase;
    }}
    h1 {{ font-size: 1.45em; }}
    h2 {{ font-size: 1.15em; }}
    h3 {{ font-size: 0.9em; }}
    .published, .label {{
      color: #8f8f8f;
      display: block;
      font-size: 0.72em;
      letter-spacing: 0.18em;
      text-transform: uppercase;
    }}
    .content {{ padding: 3em; }}
    .featured {{
      background: linear-gradient(135deg, #2ebaae, #3c3b3b);
      color: #ffffff;
      min-height: 13em;
      padding: 3em;
    }}
    .featured strong {{ color: #ffffff; }}
    .stats-grid {{
      display: grid;
      gap: 1em;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      margin: 1.5em 0 0;
    }}
    .metric-card {{
      border: solid 1px rgba(160, 160, 160, 0.3);
      padding: 1.25em;
    }}
    .metric {{
      color: #2ebaae;
      font-size: 1.55em;
      font-weight: 800;
      line-height: 1.25;
    }}
    .ok {{ color: #2ebaae; }}
    .warn {{ color: #d48927; }}
    .danger {{ color: #c94c4c; }}
    .chart-grid {{
      display: grid;
      gap: 1.5em;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      margin-top: 1.5em;
    }}
    .chart-card {{
      border: solid 1px rgba(160, 160, 160, 0.3);
      background: #ffffff;
      padding: 1.5em;
    }}
    .chart-layout {{
      align-items: center;
      display: grid;
      gap: 1.5em;
      grid-template-columns: 190px minmax(0, 1fr);
    }}
    .pie-chart {{
      display: block;
      height: 190px;
      width: 190px;
    }}
    .legend {{
      display: grid;
      gap: 0.75em;
    }}
    .legend.compact {{
      gap: 0.5em;
      margin-top: 1.25em;
    }}
    .legend-item {{
      align-items: center;
      display: grid;
      gap: 0.75em;
      grid-template-columns: 1em minmax(0, 1fr) auto;
    }}
    .swatch {{
      border-radius: 50%;
      display: inline-block;
      height: 0.85em;
      width: 0.85em;
    }}
    .vertical-bar-chart {{
      background: linear-gradient(180deg, rgba(46,186,174,0.06), rgba(255,255,255,0));
      display: block;
      margin: 0.5em auto 0;
      max-width: 100%;
      width: 100%;
    }}
    .axis-line {{
      stroke: rgba(60, 59, 59, 0.28);
      stroke-width: 1;
    }}
    .muted-axis {{
      stroke: rgba(60, 59, 59, 0.14);
    }}
    .bar-svg-value {{
      fill: #3c3b3b;
      font-size: 11px;
      font-weight: 800;
    }}
    .bar-svg-label {{
      fill: #646464;
      font-size: 12px;
      font-weight: 800;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }}
    .formula {{
      background: #2a2f3a;
      color: #f4f4f4;
      display: block;
      font-family: Consolas, "Courier New", monospace;
      margin: 1.25em 0;
      overflow-x: auto;
      padding: 1.25em;
      white-space: pre-wrap;
    }}
    table {{
      border-collapse: collapse;
      margin: 1.5em 0;
      width: 100%;
    }}
    th, td {{
      border: solid 1px rgba(160, 160, 160, 0.3);
      padding: 0.85em 1em;
      text-align: left;
      vertical-align: top;
    }}
    th {{
      background: rgba(160, 160, 160, 0.075);
      color: #3c3b3b;
      font-size: 0.75em;
      letter-spacing: 0.14em;
      text-transform: uppercase;
    }}
    #sidebar {{
      border-left: solid 1px rgba(160, 160, 160, 0.3);
      padding-left: 3em;
    }}
    .mini-post {{
      background: #ffffff;
      border: solid 1px rgba(160, 160, 160, 0.3);
      margin: 0 0 2em 0;
      padding: 1.5em;
    }}
    .mini-post .metric {{ font-size: 1.25em; }}
    .blurb {{
      border-top: solid 1px rgba(160, 160, 160, 0.3);
      margin-top: 2em;
      padding-top: 2em;
    }}
    .muted {{ color: #8f8f8f; }}
    @media (max-width: 1100px) {{
      #main {{ grid-template-columns: 1fr; }}
      #sidebar {{ border-left: 0; padding-left: 0; }}
    }}
    @media (max-width: 760px) {{
      #header nav {{ display: none; }}
      #main {{ padding: 1.5em 1em; }}
      .post > header {{ grid-template-columns: 1fr; }}
      .post > header .meta {{ border-left: 0; border-top: solid 1px rgba(160, 160, 160, 0.3); text-align: left; }}
      .post > header .title, .post > header .meta, .content, .featured {{ padding: 1.5em; }}
      .stats-grid {{ grid-template-columns: 1fr 1fr; }}
    }}
  </style>
</head>
<body>
  <div id="wrapper">
    <header id="header">
      <h1><a href="#">QGIS Plate Analyzer</a></h1>
      <nav class="links">
        <ul>
          <li><a href="#conclusion">Conclusion</a></li>
          <li><a href="#graficos">Graficos</a></li>
          <li><a href="#referencia">Area</a></li>
          <li><a href="#criterio">Criterio KDE</a></li>
          <li><a href="#parametros">Parametros</a></li>
        </ul>
      </nav>
    </header>

    <div id="main">
      <section id="content">
        <article class="post" id="conclusion">
          <header>
            <div class="title">
              <h1>Informe de cobertura de placas</h1>
              <p>Analisis kernel sobre superficie urbana seleccionada</p>
            </div>
            <div class="meta">
              <time class="published">{self._report_value(now)}</time>
              <span class="label">Territorio</span>
              <strong>{self._report_value(country)} / {self._report_value(dep)} / {self._report_value(city)}</strong>
            </div>
          </header>
          <div class="featured">
            <p>
              El analisis identifica <strong>{self._format_area(high_area_m2)}</strong> como area no cubierta.
              Esta area representa aproximadamente <strong>{high_pct:,.2f}%</strong> del area total de la mascara
              de busqueda y corresponde a zonas que hacen falta por mapear o revisar porque presentan baja densidad
              de placas en relacion con la intensidad construida existente. Las zonas sin construcciones se reportan
              como una clase independiente y no se suman como area cubierta.
            </p>
          </div>
          <div class="content">
            <div class="stats-grid">
              <div class="metric-card"><div class="metric danger">{self._format_area(high_area_m2)}</div><span class="label">Area no cubierta</span></div>
              <div class="metric-card"><div class="metric danger">{high_pct:,.2f}%</div><span class="label">Proporcion sobre search_mask</span></div>
              <div class="metric-card"><div class="metric ok">{self._format_area(covered_area_m2)}</div><span class="label">Area cubierta</span></div>
              <div class="metric-card"><div class="metric ok">{low_pct:,.2f}%</div><span class="label">Cobertura relativa</span></div>
              <div class="metric-card"><div class="metric">{self._format_area(no_construction_area_m2)}</div><span class="label">Area sin construcciones</span></div>
              <div class="metric-card"><div class="metric">{no_construction_pct:,.2f}%</div><span class="label">Proporcion sin construcciones</span></div>
            </div>
          </div>
        </article>

        <article class="post" id="graficos">
          <header>
            <div class="title">
              <h2>Graficos de salida</h2>
              <p>Resumen visual de los campos principales del analisis.</p>
            </div>
            <div class="meta">
              <span class="label">Campos</span>
              <strong>cobertura / categoria_busqueda</strong>
            </div>
          </header>
          <div class="content">
            <div class="chart-grid">
              {coverage_chart}
              {category_chart}
            </div>
          </div>
        </article>

        <article class="post" id="referencia">
          <header>
            <div class="title">
              <h2>Area total de referencia</h2>
              <p>Lectura comparativa frente a la mascara administrativa de busqueda.</p>
            </div>
            <div class="meta">
              <span class="label">Capa analizada</span>
              <strong>{self._report_value(layer_name)}</strong>
            </div>
          </header>
          <div class="content">
            <p>La proporcion se calcula contra el area total de la mascara de busqueda administrativa seleccionada.</p>
            <div class="stats-grid">
              <div class="metric-card"><div class="metric">{self._format_area(total_area_m2)}</div><span class="label">Area total search_mask</span></div>
              <div class="metric-card"><div class="metric">{total_count:,}</div><span class="label">Zonas KDE discretizadas</span></div>
              <div class="metric-card"><div class="metric">{points_count:,}</div><span class="label">Puntos analizados</span></div>
              <div class="metric-card"><div class="metric">{samples_count:,}</div><span class="label">Muestras KDE evaluadas</span></div>
            </div>
          </div>
        </article>

        <article class="post" id="criterio">
          <header>
            <div class="title">
              <h2>Criterio de clasificacion</h2>
              <p>Separacion entre No cubierto, Cubierto y Sin construcciones.</p>
            </div>
            <div class="meta">
              <span class="label">Regla</span>
              <strong>ratio bajo</strong>
            </div>
          </header>
          <div class="content">
            <p>La categoria No cubierto se asigna cuando la relacion entre KDE de placas y KDE de construcciones ponderado por area es significativamente baja. La categoria Sin construcciones se asigna antes del umbral cuando no existe contexto construido o este es practicamente cero.</p>
            <div class="formula">ratio_kde_puntos_construcciones = KDE_placas / KDE_construcciones_ponderado_area
umbral_ratio_bajo = max(0, mediana(ratio_kde_puntos_construcciones) - desviacion_estandar(ratio_kde_puntos_construcciones))
coverage = Sin construcciones si KDE_construcciones_ponderado_area es cero o casi cero
cobertura = No cubierto si ratio_kde_puntos_construcciones &lt;= umbral_ratio_bajo
cobertura = Cubierto para los demas casos</div>
            <p class="muted">El umbral se usa como regla interna de clasificacion. El informe evita reportar extremos numericos poco informativos cuando la distribucion contiene muchos ceros o empates.</p>
          </div>
        </article>

        <article class="post" id="parametros">
          <header>
            <div class="title">
              <h2>Parametros del modelo</h2>
              <p>Configuracion usada durante la corrida del analisis kernel.</p>
            </div>
            <div class="meta">
              <span class="label">Modelo</span>
              <strong>{self._report_value(params.get("kernel_type"))}</strong>
            </div>
          </header>
          <div class="content">
            <table>
              <tbody>
                <tr><th>Parametro</th><th>Valor</th></tr>
                <tr><td>Base de datos</td><td>{self._report_value(params.get("dbname"))}</td></tr>
                <tr><td>SRID de analisis</td><td>{self._report_value(params.get("analysis_srid"))}</td></tr>
                <tr><td>Ancho de banda</td><td>{self._report_value(params.get("bandwidth_m"))} m</td></tr>
                <tr><td>Radio de busqueda</td><td>{self._report_value(params.get("search_radius_m"))} m</td></tr>
                <tr><td>Funcion kernel</td><td>{self._report_value(params.get("kernel_type"))}</td></tr>
                <tr><td>Asignacion KDE</td><td>{self._report_value(params.get("kde_assignment"))}</td></tr>
              </tbody>
            </table>
          </div>
        </article>

      </section>

      <section id="sidebar">
        <section class="mini-post">
          <h2>Resumen</h2>
          <p class="muted">El informe cuantifica cuanto falta por mapear, cuanto queda cubierto por densidad normal o alta de placas, y cuanto corresponde a zonas sin construcciones.</p>
        </section>
        <section class="mini-post">
          <span class="label">Falta por mapear</span>
          <div class="metric danger">{high_pct:,.2f}%</div>
          <p>{self._format_area(high_area_m2)}</p>
        </section>
        <section class="blurb">
          <h3>Lectura operativa</h3>
          <p>No cubierto significa baja presencia relativa de placas frente al KDE de construcciones ponderado por area. Cubierto agrupa zonas donde la relacion placas/construcciones no cae dentro del rango critico bajo. Sin construcciones identifica areas sin base construida suficiente para evaluar cobertura de placas.</p>
        </section>
      </section>
    </div>
  </div>
</body>
</html>
"""
        report_path.write_text(document, encoding="utf-8")
        self.last_report_path = report_path
        self.add_log(f"Informe HTML generado: {report_path}", "success")
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(report_path)))

    def _run_analysis(self):
        if not self.confirmed_analysis_layer_id:
            self.add_log("Primero confirme la capa a analizar en el panel 2 - Capas.", "error")
            return

        layer = self._selected_analysis_layer()

        if layer is None or not isinstance(layer, QgsVectorLayer):
            self.add_log(
                "La capa confirmada ya no esta disponible. Actualice la lista y confirmela de nuevo.",
                "error",
            )
            return

        if layer.geometryType() != 0:
            self.add_log("La capa seleccionada para analisis debe ser una capa de puntos.", "error")
            return

        if not self._has_valid_admin_selection():
            self.add_log("Seleccione departamento / nivel 1 y municipio / nivel 2 validos.", "error")
            return

        method = ANALYSIS_METHOD
        radius = float(ANALYSIS_BANDWIDTH_M)
        search_radius = float(ANALYSIS_SEARCH_RADIUS_M)
        kernel_type = ANALYSIS_KERNEL_TYPE
        weight = ANALYSIS_WEIGHT_FIELD
        self.metric_method.setText(f"METHOD: {method.upper()}")
        self.metric_radius.setText(f"BANDWIDTH: {radius:g} m")
        self.metric_kernel.setText(f"KERNEL: {kernel_type}")
        self.analysis_preview.set_layer_name(layer.name())
        self.analysis_preview.set_heatmap(True)
        self.last_analysis_result = None
        if hasattr(self, "generate_report_btn"):
            self.generate_report_btn.setEnabled(False)

        self.add_log(f"Ejecutando analisis {method} sobre capa '{layer.name()}'...", "info")
        self._set_processing_state(True, 12)
        QApplication.processEvents()
        try:
            self.progress.setValue(45)
            QApplication.processEvents()
            analysis = DensityAnalysis(
                feedback=lambda msg: self.add_log(msg, "info"),
                db_manager=self.db,
            )
            ok, msg, result = analysis.run(
                layer,
                method=method,
                radius=radius,
                pixel_size=radius,
                weight_field=weight,
                country=self.country_combo.currentText().strip(),
                nivel_1=self._selected_department_name(),
                nivel_2=self._selected_city_name(),
                dbname=self._selected_dbname(),
                config_path=str(self.json_dir / "config_Sincontra.json"),
                mapping_path=str(self.json_dir / "column_mapping - DEF.json"),
                search_radius_m=search_radius,
                kernel_type=kernel_type,
            )
            self.progress.setValue(100)
            QApplication.processEvents()
            if ok:
                self.last_analysis_result = result
                if hasattr(self, "generate_report_btn"):
                    self.generate_report_btn.setEnabled(True)
                self.add_log(msg, "success")
                self.add_log("Renderizando resultado y refrescando capas del proyecto...", "info")
                self._refresh_qgis_layers(silent=True)
                self.map_preview.set_heatmap(True)
            else:
                self.add_log(msg, "error")
        except Exception as exc:
            self.add_log("Error ejecutando analisis: " + str(exc), "error")
            self.add_log(traceback.format_exc(), "error")
        finally:
            QTimer.singleShot(650, lambda: self._set_processing_state(False, 0))

    def _page_analysis(self) -> QWidget:
        page = self._page_wrapper()
        layout: QVBoxLayout = page.main_layout  # type: ignore[attr-defined]
        row = QHBoxLayout()
        row.setSpacing(18)

        config_card, config = self._card("Analisis de densidad", True)
        self.analysis_layer_combo = QComboBox()
        self.analysis_layer_combo.currentTextChanged.connect(
            lambda text: (self._on_analysis_layer_changed(text), self._update_analysis_summary())
        )
        self.analysis_method_value = QLabel("kde - Densidad Kernel")
        self.analysis_method_value.setObjectName("hint")
        self.radius_value = QLabel(f"{ANALYSIS_BANDWIDTH_M:g} m")
        self.radius_value.setObjectName("hint")
        self.search_radius_value = QLabel(f"{ANALYSIS_SEARCH_RADIUS_M:g} m")
        self.search_radius_value.setObjectName("hint")
        self.kernel_value = QLabel(ANALYSIS_KERNEL_TYPE)
        self.kernel_value.setObjectName("hint")

        self.analysis_hint = QLabel(
            "El complemento usara el departamento y municipio seleccionados, la base del pais, "
            "la capa de puntos seleccionada en esta lista y los parametros KDE fijos definidos en los modulos Python."
        )
        self.analysis_hint.setObjectName("hint")
        self.analysis_hint.setWordWrap(True)
        config.addWidget(self.analysis_hint)

        params_grid = QGridLayout()
        params_grid.setHorizontalSpacing(14)
        params_grid.setVerticalSpacing(11)
        params = [
            ("Metodo", self.analysis_method_value),
            ("Ancho de banda KDE", self.radius_value),
            ("Radio de busqueda", self.search_radius_value),
            ("Funcion kernel", self.kernel_value),
        ]
        for row_idx, (label, widget) in enumerate(params):
            params_grid.addWidget(self._label(label), row_idx, 0)
            params_grid.addWidget(widget, row_idx, 1)
        config.addLayout(params_grid)

        self.run_analysis_btn = self._primary("Ejecutar analisis de densidad")
        self.run_analysis_btn.clicked.connect(self._run_analysis)
        config.addWidget(self.run_analysis_btn)
        self.auto_analysis_summary = QLabel("")
        self.auto_analysis_summary.setObjectName("hint")
        self.auto_analysis_summary.setWordWrap(True)
        config.addWidget(self.auto_analysis_summary)

        preview_card, preview = self._card("Modelo de Densidad Kernel", False)
        self.generate_report_btn = QPushButton("Generar informe HTML")
        self.generate_report_btn.setObjectName("dangerButton")
        self.generate_report_btn.setCursor(Qt.PointingHandCursor)
        self.generate_report_btn.setEnabled(False)
        self.generate_report_btn.clicked.connect(self._generate_density_report)
        preview.addWidget(self.generate_report_btn)
        self.analysis_preview = MapPreviewWidget()
        self.analysis_preview.set_heatmap(True)
        preview.addWidget(self.analysis_preview, 1)
        metrics = QHBoxLayout()
        self.metric_method = QLabel("METHOD: KDE")
        self.metric_method.setObjectName("metric")
        self.metric_radius = QLabel(f"BANDWIDTH: {ANALYSIS_BANDWIDTH_M:g} m")
        self.metric_radius.setObjectName("metric")
        self.metric_kernel = QLabel(f"KERNEL: {ANALYSIS_KERNEL_TYPE}")
        self.metric_kernel.setObjectName("metric")
        metrics.addWidget(self.metric_method)
        metrics.addWidget(self.metric_radius)
        metrics.addWidget(self.metric_kernel)
        metrics.addStretch(1)
        preview.addLayout(metrics)

        row.addWidget(self._scroll_card(config_card), 1)
        row.addWidget(self._scroll_card(preview_card), 1)
        layout.addLayout(row, 1)
        self._update_analysis_summary()
        return page

    def _update_analysis_summary(self):
        if not hasattr(self, "auto_analysis_summary"):
            return
        country = self.country_combo.currentText().strip() if hasattr(self, "country_combo") else ""
        city = self._selected_city_name()
        dep = self._selected_department_name()
        dbname = self._selected_dbname()
        run = self._selected_run()
        selected_layer = self._selected_analysis_layer()
        selected_name = selected_layer.name() if isinstance(selected_layer, QgsVectorLayer) else "sin capa seleccionada"
        confirmation_state = "confirmada" if self.confirmed_analysis_layer_id else "pendiente de confirmar en panel 2 - Capas"
        self.auto_analysis_summary.setText(
            f"Pais: {country}\n"
            f"Departamento / nivel 1: {dep}\n"
            f"Municipio / nivel 2: {city}\n"
            f"Base: {dbname}\n"
            f"Capa que se ejecutara: {selected_name}\n"
            f"Estado de capa: {confirmation_state}\n"
            f"Ancho de banda: {ANALYSIS_BANDWIDTH_M:g} m\n"
            f"Radio de busqueda: {ANALYSIS_SEARCH_RADIUS_M:g} m\n"
            f"Kernel: {ANALYSIS_KERNEL_TYPE}\n"
            "Parametros: fijos, configurables solo desde los modulos Python"
        )
