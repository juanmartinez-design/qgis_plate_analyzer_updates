# -*- coding: utf-8 -*-
"""PostGIS connection and layer loading utilities.

The module is safe to import even when psycopg2 is not available. QGIS can load
PostGIS layers through its native provider, while catalog queries require
psycopg2. This avoids import failures when the plugin is enabled.
"""

import os
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

from qgis.core import QgsDataSourceUri, QgsProject, QgsVectorLayer


@dataclass
class DBConfig:
    host: str = "localhost"
    port: str = "5432"
    database: str = "gis_db"
    user: str = "postgres"
    password: str = ""


class DBManager:
    """Small PostGIS helper used by the dialog."""

    def __init__(self, config: Optional[DBConfig] = None):
        self.config = config or DBConfig()

    def update_config(self, config: DBConfig):
        self.config = config

    def _psycopg2(self):
        try:
            import psycopg2  # type: ignore
            return psycopg2, None
        except Exception as exc:  # pragma: no cover - depends on QGIS env
            return None, str(exc)

    def _connect(self):
        psycopg2, import_error = self._psycopg2()
        if psycopg2 is None:
            raise RuntimeError(
                "No se pudo importar psycopg2 en el Python de QGIS. "
                "Instálalo en el entorno de QGIS o carga capas PostGIS con el proveedor nativo. "
                f"Detalle: {import_error}"
            )

        return psycopg2.connect(
            host=self.config.host,
            port=self.config.port,
            dbname=self.config.database,
            user=self.config.user,
            password=self.config.password,
            connect_timeout=6,
        )

    def test_connection(self) -> Tuple[bool, str]:
        """Return a connection status without raising to the UI."""
        try:
            with self._connect() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT version();")
                    version = cur.fetchone()[0]
            return True, version
        except Exception as exc:
            return False, str(exc)

    @staticmethod
    def _safe_error_message(exc: Exception) -> str:
        if isinstance(exc, UnicodeDecodeError):
            return (
                "PostgreSQL devolvio un mensaje en una codificacion distinta "
                "a UTF-8. Revise usuario, contrasena, host/base y permisos."
            )
        try:
            return str(exc)
        except UnicodeDecodeError:
            return repr(exc)

    def _connect_with_encoding(self, encoding: Optional[str] = None):
        psycopg2, import_error = self._psycopg2()
        if psycopg2 is None:
            raise RuntimeError(
                "No se pudo importar psycopg2 en el Python de QGIS. "
                "Instalalo en el entorno de QGIS o carga capas PostGIS con el proveedor nativo. "
                f"Detalle: {import_error}"
            )

        previous_encoding = os.environ.get("PGCLIENTENCODING")
        try:
            if encoding:
                os.environ["PGCLIENTENCODING"] = encoding
            conn = psycopg2.connect(
                host=self.config.host,
                port=self.config.port,
                dbname=self.config.database,
                user=self.config.user,
                password=self.config.password,
                connect_timeout=6,
            )
            if encoding:
                try:
                    conn.set_client_encoding(encoding)
                except Exception:
                    pass
            return conn
        finally:
            if encoding:
                if previous_encoding is None:
                    os.environ.pop("PGCLIENTENCODING", None)
                else:
                    os.environ["PGCLIENTENCODING"] = previous_encoding

    def _connect(self):
        try:
            return self._connect_with_encoding()
        except UnicodeDecodeError:
            return self._connect_with_encoding("LATIN1")

    def test_connection(self) -> Tuple[bool, str]:
        """Return a connection status without raising to the UI."""
        try:
            with self._connect() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT version();")
                    version = cur.fetchone()[0]
            return True, version
        except Exception as exc:
            return False, self._safe_error_message(exc)

    def fetch_rows(self, sql: str, params: Optional[Iterable] = None) -> List[Tuple]:
        """Execute a read-only query and return rows."""
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, tuple(params or ()))
                return list(cur.fetchall())

    def list_schemas(self) -> List[str]:
        rows = self.fetch_rows(
            """
            SELECT schema_name
            FROM information_schema.schemata
            WHERE schema_name NOT IN ('pg_catalog', 'information_schema')
            ORDER BY schema_name;
            """
        )
        return [r[0] for r in rows]

    def list_spatial_tables(self, schema: str = "public") -> List[Dict[str, object]]:
        """Return spatial tables from geometry_columns for a schema."""
        rows = self.fetch_rows(
            """
            SELECT f_table_schema, f_table_name, f_geometry_column, srid, type
            FROM public.geometry_columns
            WHERE f_table_schema = %s
            ORDER BY f_table_name, f_geometry_column;
            """,
            (schema,),
        )
        return [
            {
                "schema": r[0],
                "table": r[1],
                "geometry_column": r[2],
                "srid": int(r[3]) if r[3] is not None else 0,
                "geometry_type": r[4],
            }
            for r in rows
        ]

    def list_columns(self, schema: str, table: str) -> List[str]:
        rows = self.fetch_rows(
            """
            SELECT column_name
            FROM information_schema.columns
            WHERE table_schema = %s AND table_name = %s
            ORDER BY ordinal_position;
            """,
            (schema, table),
        )
        return [r[0] for r in rows]

    def list_distinct_values(self, schema: str, table: str, column: str, limit: int = 200) -> List[str]:
        """List distinct values using a safely quoted identifier pattern."""
        # Identifier quoting is handled with basic double-quote escaping because
        # psycopg2.sql may not be available in all bundled environments.
        def q(identifier: str) -> str:
            return '"' + identifier.replace('"', '""') + '"'

        sql = f"SELECT DISTINCT {q(column)} FROM {q(schema)}.{q(table)} WHERE {q(column)} IS NOT NULL ORDER BY 1 LIMIT %s;"
        rows = self.fetch_rows(sql, (limit,))
        return [str(r[0]) for r in rows]

    def build_uri(
        self,
        schema: str,
        table: str,
        geom_col: str,
        sql_filter: str = "",
        key_col: str = "",
    ) -> QgsDataSourceUri:
        uri = QgsDataSourceUri()
        uri.setConnection(
            self.config.host,
            str(self.config.port),
            self.config.database,
            self.config.user,
            self.config.password,
        )
        uri.setDataSource(schema, table, geom_col, sql_filter, key_col)
        return uri

    def load_postgis_layer(
        self,
        schema: str,
        table: str,
        geom_col: str,
        layer_name: Optional[str] = None,
        sql_filter: str = "",
        key_col: str = "",
    ) -> Tuple[bool, str, Optional[QgsVectorLayer]]:
        """Load a PostGIS table into the current QGIS project."""
        layer_name = layer_name or f"{schema}.{table}"
        uri = self.build_uri(schema, table, geom_col, sql_filter, key_col)
        layer = QgsVectorLayer(uri.uri(False), layer_name, "postgres")

        if not layer.isValid():
            return False, layer.error().message() if layer.error() else "La capa no es válida.", None

        QgsProject.instance().addMapLayer(layer)
        return True, f"Capa '{layer_name}' agregada al proyecto.", layer
